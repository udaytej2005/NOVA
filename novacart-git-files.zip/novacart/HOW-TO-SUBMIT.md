# How to submit NOVA SURE

Three things go to the judges. Everything needed for all three is in this folder.

| # | What they asked for | What you hand over |
|---|---|---|
| 1 | The written deliverables (Problem Diagnosis, Prompt Journey, Solution Explanation, Business Impact) | **`NOVA-SURE-submission.docx`** — one document, ~12,300 words, 35 tables, all six sections plus the generated evidence appendix. (`SUBMISSION.md` links to the same content in markdown if you prefer.) |
| 2 | Functional prototype + source code | **`novacart/` folder, or the repo link, or `novacart-submission.zip`** — the app is `index.html`; the submitted source is `src/`; `demo.html` is the scripted walkthrough |
| 3 | Demo / live link | A **live URL** (see below) and the **3-minute backup walkthrough** `demo.html` |

---

## Step 1 — download the bundle

Everything is zipped at **`novacart-submission.zip`** (in the workspace, one level above the project folder). Unzipped it looks like this:

```
novacart/
├── NOVA-SURE-submission.docx   ← upload this as the written submission
├── index.html                  ← the working app (open it; no install, no server, no keys)
├── demo.html                   ← 3-minute scripted walkthrough (press play)
├── README.md                   ← run / test / build in three commands
├── SUBMISSION.md               ← the seven deliverables, indexed
├── EVIDENCE.md                 ← every figure, generated from the engine
├── DEPLOY.md                   ← publishing instructions
├── docs/01..06                 ← diagnosis · prompt journey · solution · demo · impact · source
├── src/  tools/  tests/        ← modular source, build script, five test suites
└── .gitignore
```

## Step 2 — get a live link (about 2 minutes, free)

The app is a single static file with no server, no build step, no environment variables and no API key, so any host works. Full commands are in **`DEPLOY.md`**; the short version:

**GitHub Pages**
```bash
cd novacart
git init -b main && git add . && git commit -m "NOVA SURE — NOVA CART submission"
git remote add origin https://github.com/<your-user>/<your-repo>.git
git push -u origin main
# then: repo → Settings → Pages → Source: Deploy from a branch → main / root → Save
```
Live at `https://<your-user>.github.io/<your-repo>/` — app at `index.html`, walkthrough at `/demo.html`.

**Vercel:** `cd novacart && vercel --prod` → framework preset *Other*, build command *none*, output directory `.`.

**Quick and dirty for the demo:** `python3 -m http.server 8080` inside the folder and open `http://localhost:8080/index.html` (that is exactly what the workspace preview is doing right now).

## Step 3 — pre-flight check before you send it

```bash
node tests/smoke_ui.js      # 120 checks — every screen, state, escaping, cache, perf
node tests/demo_path.js     #  33 checks — walks the demo script, asserts each screen
node tests/smoke_demo.js    #  55 checks — every scene of the backup walkthrough
node tests/check_docs.js    # 181 checks — every figure in the docs against the engine
node tests/run_engine.js    # model invariants + hygiene (no keys, no network, engine has no DOM)
python3 tools/build.py      # regenerates index.html and demo.html from src/
```
All five exit non-zero on failure. Then click through the 3-minute path once yourself: **Store app → verify 4 items → Customer app → the promise → Decision Room → the gap.**

## Step 4 — what to say when you submit

- **Diagnosis in one line:** growth converted into churn because the app promises availability and speed that no partner store has verified — repeat 41% → 27%, cancels 6% → 11%, 13% late, ₹10.03L/month of direct leak (modelled).
- **Solution in one line:** NOVA SURE — an availability-and-promise layer: a customer honest-promise with an availability gate, a 15-second partner stock check, and an Ops Trust Console with a one-tap intervention queue.
- **Impact in one line:** the gap between continuing the current plan (**−₹67.74L** over twelve months) and running NOVA SURE (**+₹10.33L**) is **₹78.07L**; payback month 10 at 55% rollout, month 5 once the console is used.
- **If they ask about the ROAS figure:** 0.57× is Δrevenue ÷ Δspend; the ₹68-vs-₹103 comparison is shown in the app as the *most generous reading* (0.66×). All three definitions are below 1 — stated up front, deliberately.

## Notes

- **Nothing secret is in the repo** — no API keys, no `.env`, no credentials; the copilot is deterministic and the app makes no network calls. `.gitignore` covers the usual junk.
- **Do not edit `index.html` or `demo.html` by hand** — they are build outputs; edit `src/` and run `python3 tools/build.py`.
- **If the portal asks for a video:** record `demo.html` while pressing play; the narration for each scene is printed under it, scene by scene, and the same beats are scripted in `docs/04-demo-script.md`.
