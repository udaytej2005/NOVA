# NOVA SURE — submission pack

*Submitted by the AI-powered Business Innovation Team. Built for the NOVA CART challenge.*

**NOVA SURE is an availability-and-promise layer that makes NOVA CART's orders keep the promise its app already makes.**
Verification over prediction; an honest promise instead of a fast one; one-tap operations instead of dashboards; a deterministic copilot instead of a black box.

---

## The seven required deliverables, and where each one lives

| # | Deliverable | File | What it contains |
|---|---|---|---|
| 1 | **Problem Diagnosis** | [`docs/01-problem-diagnosis.md`](docs/01-problem-diagnosis.md) | The underlying problem, the evidence chain built only from the case pack, external validation, what the diagnosis rules out, and what would falsify it |
| 2 | **Prompt Journey** | [`docs/02-prompt-journey.md`](docs/02-prompt-journey.md) | The 16 prompts that actually changed the analysis, the decision or the product — each with what it changed |
| 3 | **Solution Explanation** | [`docs/03-solution-explanation.md`](docs/03-solution-explanation.md) | What was built, for whom, why it addresses the diagnosis, how the ₹25L is spent, what we deliberately did **not** build |
| 4 | **Functional Prototype** | [`index.html`](index.html) | The working application — one self-contained file, six surfaces, input → logic → action/output |
| 5 | **Source Code** | [`README.md`](README.md) · [`src/`](src) · [`tools/`](tools) · [`tests/`](tests) | Repository layout, how to run, how to verify; no dependencies, no network calls |
| 6 | **Demo** | [`docs/04-demo-script.md`](docs/04-demo-script.md) · [`demo.html`](demo.html) | The primary user journey click by click with the exact numbers each step shows — plus a **self-playing backup demo**: open `demo.html`, press play, and the same engine walks all eleven scenes in three minutes |
| 7 | **Business Impact** | [`docs/05-business-impact.md`](docs/05-business-impact.md) | The measurable value: revenue, retention, conversion, cost, time, satisfaction, productivity, accuracy, operational efficiency — plus how to verify it in production |

**Supporting evidence:** [`EVIDENCE.md`](EVIDENCE.md) — every figure quoted anywhere in this pack, generated directly from the engine that runs the application (`node tools/dump_numbers.js`). Nothing in the written submission is typed by hand, so the report and the prototype cannot disagree.

---

## One page of the whole thing

**Read-this-first on definitions.** One ROAS definition is used everywhere: **extra revenue ÷ extra spend = 0.57×**. The alternative most generous to marketing — today's *average* revenue per order (₹68) divided by the marginal promo cost of an extra order (₹103) — is **0.66×**; a blended figure is 1.54×. All three are below 1, so the diagnosis does not depend on which is chosen. Repeat buyers are reported on all three possible bases: registered × rate (−1,220), orders × rate (−2,397), MAU × rate (−3,570); **every base falls**. Full assumptions and the sensitivity test are in a box in the app (Diagnosis and Decision Room) and in `EVIDENCE.md` §11.

**Diagnosis.** NOVA CART grew volume and lost customers. Over six months orders rose 23.4% (31,200 → 38,500) while promotional spend rose 78.9% (₹9.5L → ₹17L) — every *incremental* order cost **₹103** in promotions and added **₹59** of platform revenue (₹4.30L ÷ ₹7.50L = **0.57×** marginal ROAS; ₹68 is today's *average* revenue per order and is not the right comparator). In the same window the repeat rate collapsed 41% → 27%: **1,220 fewer repeat buyers than six months ago** — defined as registered users × repeat rate, the most conservative of the three possible bases (MAU × rate falls 3,570; orders × rate falls 2,397; every basis falls). Cancellations doubled 6% → 11%, a third of them because a product was not actually available; 13% of delivered orders arrived more than 15 minutes late; tickets per 100 orders went 9.9 → 15.3 with a 9.2-hour resolution time. 61% of churned customers had rated NOVA CART 4★ or better — they did not leave because they disliked the product. They left because the order failed, and then they were made to chase the refund.

The chain is one mechanism, not six problems: **NOVA CART promises availability and speed it cannot verify.** The promise is made at checkout before any partner store has confirmed the shelf. Availability mismatch becomes cancellation (35% of cancels) or substitution (8% of orders), which becomes a ticket (15.3 per 100 orders), which becomes a refund the customer has to chase (29% of all tickets are refund status), which becomes churn — at a rate that erases everything the acquisition spend bought.

**Diagnosis in money:** ₹10.03L/month of direct reliability leak (₹1.20cr a year) — cancellations ₹2.87L, failure-driven support ₹3.19L, refunds/compensation ₹0.97L, rider minutes burnt ₹1.70L, substitution friction ₹1.29L — plus ₹1.09L/month of lifetime revenue lost from each new cohort. ₹11.12L/month, ≈38% of monthly revenue for the direct part alone.

**Solution.** Three surfaces on one spine, all built and running in the prototype:

1. **Customer app** — an *availability gate* at checkout: SKUs a store has not verified are shown as what they are, and the promise engine quotes a time derived from that store's own reliability, catalogue age and prep time — not a flat 10-minute slogan. On a real basket at Sri Balaji Kirana (Nizamabad), today's flat promise is 28 minutes with a 13.7% chance of being >15 minutes late; NOVA SURE says 32 minutes and cuts that miss rate to 1.3%, while the ±5-minute hit rate rises from 44% to 68%.
2. **Partner store app** — a 15-second stock sync (plenty / few / out) twice a day, plus pre-peak stock nudges and an accept-or-decline capacity cap, because 39% of partners already say catalogue upkeep costs too much and 18% are considering leaving.
3. **Ops Trust Console + Decision Room + Copilot** — the leak map as arithmetic an operator can argue with, an intervention queue ranked by ₹/month with one-tap apply and auto-heal, and a deterministic copilot that answers the six questions management is actually arguing about.

**Impact, measured on the model, in deltas against today** (all figures from `EVIDENCE.md`):

| | Plan C — do nothing | Plan A — +30% marketing (what the case pack's own numbers show happening now) | Plan B — NOVA SURE |
|---|---|---|---|
| Orders, month 12 | 36,309 | 40,731 | 40,644 |
| Revenue, month 12 | ₹24.62L | ₹26.53L | **₹27.85L** |
| Repeat rate, month 12 | 27.0% | 27.0% | **31.6%** |
| 12-month cumulative Δ contribution | −₹10.10L | −₹67.74L | **+₹10.33L** |
| Cash payback | — | never | **month 10** (month 5 if the ops console is actually used) |

**The number to argue with is the gap, not the payback.** Continuing what NOVA CART is already doing (Plan A: another +30% of marketing, the last six months extrapolated) ends twelve months **−₹67.74L** against today. Doing nothing ends **−₹10.10L**. NOVA SURE ends **+₹10.33L** — a **₹78.07L gap** between the plan being run and the plan that could be run, and at month 12 Plan B is ahead of Plan A by ₹9.27L/month while spending ₹5.10L/month less on promotions. Payback is the second-order fact underneath: month 10 at 55% rollout, month 5 at full rollout (cumulative Δ ₹49.21L). LTV:CAC moves 1.35:1 → 1.46:1.

**What we are not claiming.** No absolute profit figures: rider base pay, commission structure and technology costs are not disclosed, so every number here is a delta against the current month. Soft assumptions (₹42 per refund/substitution event, ₹34 per late order, ₹75 per ticket, programme phasing) are listed in full in `EVIDENCE.md` §11, and the conclusions survive halving them — the leak is still ₹8.05L/month.

---

## Running the prototype

Open `index.html` in any browser — no server, no install, no network, no API keys. It is a single 178 KB file with the data, the engine and the UI inlined (built from `src/` by `python3 tools/build.py`).

```bash
node tests/smoke_ui.js        # 120 checks — every view, state, escaping, cache, perf, debounce
node tests/demo_path.js       # 33 checks — walks the demo script and asserts each screen
node tests/smoke_demo.js      # 55 checks — every scene of demo.html
node tests/check_docs.js      # 181 checks — every figure in this pack against the engine
node tests/run_engine.js      # model invariants + code hygiene (no DOM in the engine, no keys)
node tools/dump_numbers.js    # regenerates EVIDENCE.md from the engine
python3 tools/build.py        # rebuilds index.html and demo.html from src/
```
