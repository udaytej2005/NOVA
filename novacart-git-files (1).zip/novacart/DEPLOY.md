# Deploy

Two outputs ship. Both are single self-contained HTML files with **no build step at deploy time, no server, no environment variables and no API keys** — so any static host works, including free tiers.

| File | What it is |
|---|---|
| `index.html` | the interactive app (six surfaces, all decisions clickable) |
| `demo.html` | the scripted 3-minute walkthrough — press **play** and it runs itself |

## Option 1 — GitHub Pages (free, ~2 minutes)

```bash
git init -b main
git add .
git commit -m "NOVA SURE — availability-and-promise layer for NOVA CART"
git remote add origin https://github.com/<your-user>/<your-repo>.git
git push -u origin main
```

Then in the repository: **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `root` → Save**.
Live in about a minute at `https://<your-user>.github.io/<your-repo>/` (the app loads at `index.html`; the demo is at `/demo.html`).

## Option 2 — Vercel (free)

```bash
npm i -g vercel        # or use the web UI and drag the folder in
cd novacart
vercel --prod
```

Framework preset: **Other**. Build command: **none**. Output directory: **`.`** (the repo root). No environment variables are needed — there is nothing to configure, which is the point.

## Option 3 — anywhere else

Any static host (Netlify drop, Cloudflare Pages, S3, an nginx folder, a USB stick) works by copying `index.html` and `demo.html`. Both open correctly straight from `file://` as well — no server required.

## What must never be added to this repo

- **API keys of any kind.** The copilot is deterministic and computes its answers from the case pack and the model in `src/engine.js`. There is no LLM call, no network request, and nothing to configure. If a future version ever calls an external service, the key must be read from an environment variable (`process.env`) at runtime and never committed — `.gitignore` already excludes `.env*`, `*.pem` and `*.key`.
- **Anything generated** (`node_modules/`, `__pycache__/`, `*.log`). `.gitignore` covers these.

## Verifying a deployment

```bash
node tests/smoke_ui.js      # 120 checks — every view, state, escaping, cache, perf, debounce
node tests/demo_path.js     # 33 checks — walks the demo script and asserts what each screen shows
node tests/smoke_demo.js    # 55 checks — every scene of demo.html
node tests/check_docs.js    # 181 checks — every figure in the docs against the engine
node tests/run_engine.js    # model invariants + code hygiene (no DOM in the engine, no keys, no external URLs)
```

All five exit non-zero on failure. `python3 tools/build.py` regenerates both HTML files from `src/` and prints their sizes.
