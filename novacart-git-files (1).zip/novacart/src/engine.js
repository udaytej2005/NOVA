/* ============================================================================
   NOVA CART — NOVA SURE
   engine.js : THE MODEL. Pure computation — no DOM, no I/O, no framework.
   ui.js renders it; shell.html drives it; tests measure it.

   MODEL ASSUMPTIONS (short form — full list with sources in EVIDENCE.md §11)
     Delta frame   : NC.baselineMonth is the month we are standing in. Every
                     projection is a CHANGE against it. Absolute profit is never
                     claimed because rider base pay, commissions and tech cost
                     are not disclosed.
     Units         : money in ₹/month unless suffixed; rates are fractions
                     (0.11 = 11%); times in minutes; coverage = share of ORDER
                     VOLUME on the verified stack (not share of stores).
     Calibration   : monthlyRetention 0.9470 and freqReturning 1.5265 are set so
                     today's disclosed 38,500 orders fall exactly out of today's
                     inflow. The disclosed funnel rates (54% first order, 31%
                     second order in 30 days, 72% monthly repeat at 3+ orders)
                     then enter as MARGINAL effects via OUTCOME_MULT, which is
                     normalised so today's failure mix reproduces 31% exactly.
     Churn model   : each failure type carries a multiplier on the 30-day second
                     order probability — clean x1.15, late x0.72, substituted
                     x0.86, cancelled x0.45, compensated x0.58.
     Leak map      : five lines, each traceable to a disclosed rate plus at most
                     one stated cost (₹75 ticket, ₹42 refund/substitution,
                     ₹34 late-order rider minutes). Halving the soft costs still
                     leaves ₹8.05L/month — see EVIDENCE.md §2.
     Attribution   : reliabilityShare (default 0.60) is the share of base churn
                     attributed to reliability rather than acquisition mix. It is
                     a slider in the Decision Room, not a buried constant.
     Determinism   : seeded RNG only (seed in data.js). No clock, no network,
                     no storage, no credentials. Same input -> same output.
     Performance   : simulate/scenarios/sensitivity are memoised (below) and the
                     Monte Carlo is hard-bounded at 200k iterations per call, so
                     a UI re-render is cheap and can never hang the page.
   ========================================================================== */
(function (global) {
  'use strict';
  var NC = global.NC = global.NC || {};

  /* ============================ formatting ============================== */
  var F = {};
  F.num = function (n, d) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    d = d === undefined ? 0 : d;
    return Number(n).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });
  };
  F.pct = function (x, d) { return (x * 100).toFixed(d === undefined ? 1 : d) + '%'; };
  F.signed = function (x, d) { return (x >= 0 ? '+' : '') + F.pct(x, d); };
  F.inr = function (n) { return '₹' + F.num(Math.round(n)); };
  F.lakh = function (n, d) { return '₹' + (n / 100000).toFixed(d === undefined ? 2 : d) + 'L'; };
  F.cr = function (n) { return '₹' + (n / 10000000).toFixed(2) + 'cr'; };
  F.compact = function (n) {
    if (Math.abs(n) >= 10000000) return F.cr(n);
    if (Math.abs(n) >= 100000) return F.lakh(n);
    if (Math.abs(n) >= 1000) return '₹' + (n / 1000).toFixed(1) + 'K';
    return F.inr(n);
  };
  NC.F = F;
  NC.clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };

  /* ========================== distributions ============================= */
  function normCdf(z) {
    var t = 1 / (1 + 0.2316419 * Math.abs(z));
    var d = 0.3989423 * Math.exp(-z * z / 2);
    var p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
    return z > 0 ? 1 - p : p;
  }
  NC.normCdf = normCdf;

  /* ======================= 1. AVAILABILITY SCORE ========================= */
  var BANDS = [
    { id: 'verified',   label: 'Verified',     min: 82, colour: '#0f9d58', action: 'Sell as normal',            promiseSafe: true },
    { id: 'likely',     label: 'Likely',       min: 62, colour: '#7cb518', action: 'Sell — picker re-checks',    promiseSafe: true },
    { id: 'risky',      label: 'Risky',        min: 42, colour: '#e8a33d', action: 'Confirm with store first',   promiseSafe: false },
    { id: 'unverified', label: 'Unverified',   min: 20, colour: '#e2683c', action: 'Offer a verified swap',      promiseSafe: false },
    { id: 'paused',     label: 'Not sellable', min: 0,  colour: '#c0392b', action: 'Show nearest alternative',   promiseSafe: false }
  ];
  NC.BANDS = BANDS;
  NC.bandOf = function (score) {
    for (var i = 0; i < BANDS.length; i++) if (score >= BANDS[i].min) return BANDS[i];
    return BANDS[BANDS.length - 1];
  };

  /* probability that a line promised at a given score actually fails */
  NC.pMiss = function (score) { return NC.clamp(0.015 + 1.15 * Math.exp(-score / 21), 0, 1); };

  NC.itemFailHistory = function (storeId, skuId) {
    var n = 0, f = 0;
    NC.ORDER_LOG.forEach(function (o) {
      if (o.storeId === storeId && o.skuId === skuId) { n++; if (o.status === 'CANCELLED' || o.substituted) f++; }
    });
    return { n: n, fails: f, rate: n ? f / n : 0 };
  };

  NC.storeScoreAdj = function (store) {
    var stale = store.syncHours <= 2 ? 0 : store.syncHours <= 6 ? 6 : store.syncHours <= 12 ? 12 : store.syncHours <= 24 ? 20 : store.syncHours <= 36 ? 28 : 36;
    var live = Math.min(5, (store.syncPerDay || 1) * 1.2);
    return -(stale
      + Math.min(18, store.cancelRate * 100 * 0.9)
      + Math.min(9, store.subRate * 100 * 0.6)) + live;
  };

  /* a store verifying an item upgrades it from an estimate to a fact */
  NC.VERIFIED = {};
  NC.storeSync = function (storeId, skuId, state) {
    var s = NC.storeById(storeId);
    if (!s) return null;
    NC.VERIFIED[storeId + '|' + skuId] = true;
    NC.SHELF[storeId][skuId] = state === 'in' ? 8 : state === 'low' ? 2 : 0;
    s.syncHours = 0.5;
    s.syncPerDay = Math.max(s.syncPerDay, 4);
    /* a fresh, honest catalogue measurably reduces real failures */
    s.cancelRate = Math.max(0.03, s.cancelRate * 0.90);
    s.subRate = Math.max(0.02, s.subRate * 0.90);
    s.touched = true;
    s.reliability = NC.clamp(NC.reliabilityOf(s) + 4, 12, 97);
    return s;
  };

  NC.availability = function (store, sku) {
    var verifiedNow = !!NC.VERIFIED[store.id + '|' + sku.id];
    var qty = (global.NC.SHELF[store.id] || {})[sku.id] || 0;
    if (qty <= 0) {
      return { score: 0, band: NC.bandOf(0), qty: 0, drivers: [['No quantity on record', 0]],
        freshness: 'unknown', confidence: 'None',
        evidence: 'No stock recorded for this item · catalogue ' + (store.syncHours <= 2 ? 'live' : store.syncHours + 'h old') };
    }
    var adj = NC.storeScoreAdj(store);
    var s = 100 + adj;
    var drivers = [];
    var thin = qty <= 2 ? 12 : qty <= 5 ? 6 : 0;
    if (thin) { s -= thin; drivers.push(['Thin stock (only ' + qty + ' on record)', -thin]); }
    var h = NC.itemFailHistory(store.id, sku.id);
    var pen = (h.n >= 2) ? Math.min(16, Math.round(h.rate * 100 * 0.4)) : (h.n === 1 && h.fails ? 6 : 0);
    if (pen) { s -= pen; drivers.push(['Failed on ' + h.fails + ' of ' + h.n + ' past orders here', -pen]); }
    drivers.push(['Catalogue ' + (store.syncHours <= 2 ? 'live (0–2h)' : (store.syncHours <= 24 ? store.syncHours + 'h old' : Math.round(store.syncHours / 24) + '–' + Math.ceil(store.syncHours / 24) + ' days old')) + ' · store cancels ' + F.pct(store.cancelRate), Math.round(adj)]);
    s = Math.max(3, Math.min(97, Math.round(s)));
    if (verifiedNow) { s = Math.min(97, s + 6); drivers.unshift(['Verified by the store just now', 6]); }
    var band = NC.bandOf(s);
    return {
      score: s, band: band, qty: qty, drivers: drivers, adj: adj, verifiedNow: verifiedNow,
      confidence: s >= 82 ? 'High' : s >= 62 ? 'Medium' : s >= 42 ? 'Low' : 'Very low',
      freshness: verifiedNow ? 'verified now' : store.syncHours <= 2 ? 'live' : store.syncHours <= 6 ? 'today' : store.syncHours <= 26 ? '1–3 days old' : '3+ days old',
      evidence: (verifiedNow ? 'Verified by the store moments ago · ' : '') + 'Qty ' + qty + ' · catalogue ' + (store.syncHours <= 2 ? 'live' : store.syncHours + 'h old') +
        ' · store cancel rate ' + F.pct(store.cancelRate) + ' · item failed ' + h.fails + '/' + Math.max(h.n, 1) + ' times here'
    };
  };

  /* ========================= 2. SUBSTITUTE ENGINE ======================== */
  NC.substitutes = function (skuId, city) {
    var sku = NC.skuById(skuId), out = [];
    NC.STORES.filter(function (s) { return s.city === city; }).forEach(function (s) {
      NC.SKUS.forEach(function (alt) {
        if (alt.id === skuId || alt.cat !== sku.cat) return;
        var ratio = alt.price / sku.price;
        if (ratio < 0.55 || ratio > 1.8) return;
        var av = NC.availability(s, alt);
        if (av.score < 70) return;
        out.push({
          skuId: alt.id, name: alt.name, price: alt.price,
          storeId: s.id, storeName: s.name, score: av.score,
          similarity: Math.round(100 - Math.abs(alt.price - sku.price) / sku.price * 45),
          priceDelta: alt.price - sku.price, sameStore: s.id !== undefined
        });
      });
    });
    out.sort(function (a, b) { return (b.score + b.similarity) - (a.score + a.similarity); });
    return out.slice(0, 4);
  };

  /* ============= 3. BASKET ROUTING — the checkout decision =============== */
  NC.routeBasket = function (cart, city, opts) {
    opts = opts || {};
    var world = NC.STORES.filter(function (s) { return s.city === city; });
    if (!world.length) world = NC.STORES;
    var primary = opts.primaryStoreId ? NC.storeById(opts.primaryStoreId)
      : world.slice().sort(function (a, b) { return (b.reliability + b.rating) - (a.reliability + a.rating); })[0];

    var lines = cart.map(function (l) {
      var sku = NC.skuById(l.skuId);
      var av = NC.availability(primary, sku);
      var line = {
        skuId: sku.id, name: sku.name, price: sku.price, qty: l.qty,
        storeId: primary.id, store: primary.name,
        score: av.score, band: av.band, evidence: av.evidence, drivers: av.drivers,
        action: 'sell', fixedScore: av.score, etaDelta: 0
      };
      if (av.score < 62) {
        var best = null;
        world.forEach(function (s) {
          if (s.id === primary.id) return;
          var a2 = NC.availability(s, sku);
          if (!best || a2.score > best.score) best = { store: s, score: a2.score, evidence: a2.evidence };
        });
        if (best && best.score >= 62) {
          line.action = 'reroute';
          line.actionLabel = 'Re-route to ' + best.store.name;
          line.fixedScore = best.score;
          line.reroute = { storeId: best.store.id, storeName: best.store.name, score: best.score, evidence: best.evidence };
          line.etaDelta = Math.max(2, Math.abs(best.store.travelMin - primary.travelMin) * 0.6 + 3);
          line.fixedEvidence = best.evidence;
        } else {
          var subs = NC.substitutes(sku.id, city);
          if (subs.length) {
            line.action = 'substitute';
            line.actionLabel = 'Offer ' + subs[0].name + ' instead (verified in ' + subs[0].storeName + ')';
            line.substitute = subs[0];
            line.fixedScore = subs[0].score;
            line.fixedEvidence = 'Verified at ' + subs[0].storeName + ' · score ' + subs[0].score;
          } else {
            line.action = 'pause';
            line.actionLabel = 'Cannot promise this item today — show nearest store';
            line.fixedScore = av.score;
          }
        }
      } else { line.actionLabel = av.band.action; }
      return line;
    });

    function basketRisk(scores) {
      return 1 - scores.reduce(function (a, s) { return a * (1 - NC.pMiss(s)); }, 1);
    }
    var before = lines.map(function (l) { return l.score; });
    var after = lines.map(function (l) { return l.fixedScore; });
    var dest = {}, stops = 1;
    lines.forEach(function (l) { if (l.reroute) { if (!dest[l.reroute.storeId]) { dest[l.reroute.storeId] = l.etaDelta; stops++; } } });
    var extraMin = Object.keys(dest).reduce(function (a, k) { return a + dest[k]; }, 0);
    return {
      city: city, primaryStore: primary.name, primaryStoreId: primary.id, primaryStoreObj: primary,
      lines: lines,
      basketValue: cart.reduce(function (a, l) { return a + NC.skuById(l.skuId).price * l.qty; }, 0),
      stops: stops,
      riskBefore: basketRisk(before),
      riskAfter: basketRisk(after),
      extraMin: extraMin,
      fixed: lines.filter(function (l) { return l.action !== 'sell'; }).length,
      empty: lines.length === 0,
      avgScoreBefore: before.length ? before.reduce(function (a, b) { return a + b; }, 0) / before.length : 0,
      avgScoreAfter: after.length ? after.reduce(function (a, b) { return a + b; }, 0) / after.length : 0
    };
  };

  /* ======================= 4. THE HONEST PROMISE ENGINE ================== */
  /* Today the app advertises the hero number and the store's real process
     decides reality. We publish the real central estimate and the risk.
     Late-by->15-min is the tail probability of a normal delivery-time
     distribution around that estimate.                                   */
  NC.promise = function (store, cart, opts) {
    opts = opts || {};
    var P = Object.assign({}, NC.DEFAULTS, opts.params || {});
    var extraMin = opts.extraMin || 0;
    var items = cart.reduce(function (a, l) { return a + l.qty; }, 0);
    var value = cart.reduce(function (a, l) { return a + NC.skuById(l.skuId).price * l.qty; }, 0);
    var prep = store.prepMin + items * 0.45 + (value > 900 ? 2.5 : 0);
    var central = prep + store.travelMin + extraMin;
    var sigma = P.sigmaBase + (store.syncHours > 12 ? 1.4 : 0);
    var legacyPromise = Math.max(12, Math.round(central - 6));
    var smartPromise = Math.max(14, Math.round(central + P.promiseOffset));
    var sigSmart = sigma * 0.72;
    function tail(promise, sig) { return 1 - normCdf((promise + 15 - central) / sig); }
    function kept(promise, sig) { return normCdf((promise + 5 - central) / sig); }
    return {
      items: items, value: value, central: Math.round(central), sigma: +sigma.toFixed(1), extraMin: Math.round(extraMin),
      legacy: { promise: legacyPromise, late15: tail(legacyPromise, sigma), kept: kept(legacyPromise, sigma) },
      smart: { promise: smartPromise, sigma: +sigSmart.toFixed(1), late15: tail(smartPromise, sigSmart), kept: kept(smartPromise, sigSmart) },
      store: store.name, storeId: store.id
    };
  };

  /* ============= 5. RELIABILITY UNIT ECONOMICS (Monte Carlo) ============= */
  /* We do not assume "better service lifts retention". We simulate the
     disclosed funnel order by order and let the experience mix decide the
     repeat rate. The LEVEL of the funnel is anchored to the disclosed
     numbers (54% / 31% / 72%); only the effect of a bad experience comes
     from the multipliers below, which are normalised so that today's mix
     reproduces today's 31% exactly.                                       */
  NC.FREQ = { m1: 1.0, m2: 1.30, m3: 1.60, m3plus: 1.64 };
  NC.OUTCOME_MULT = { clean: 1.15, late: 0.72, substituted: 0.86, cancelled: 0.45, compensated: 0.58 };
  NC.BASE_MIX = { cancel: 0.11, late15: 0.13, sub: 0.08, ticket: 0.153 };

  function mixMean(mix) {
    var M = NC.OUTCOME_MULT;
    var clean = Math.max(0, 1 - mix.cancel - mix.late15 - mix.sub - mix.ticket);
    return clean * M.clean + mix.cancel * M.cancelled + mix.late15 * M.late + mix.sub * M.substituted + mix.ticket * M.compensated;
  }
  NC.mixMean = mixMean;
  /* tickets are caused by failures, so the ticket rate is a function of them.
     Fitted so that the baseline rates reproduce the disclosed 5,900 tickets. */
  NC.worldTicketRate = function (m) { return 0.06 + 0.35 * m.cancel + 0.30 * m.late15 + 0.20 * m.sub; };
  NC.mixWithTicket = function (m) {
    var o = { cancel: m.cancel, late15: m.late15, sub: m.sub };
    o.ticket = NC.worldTicketRate(o);
    return o;
  };
  var NORM = 1 / mixMean(NC.BASE_MIX);   /* fixed anchor — never re-normalised per scenario */

  /* ==================== memo cache (keeps the UI responsive) ==============
     The whole app re-renders on every click and slide. The heavy parts are the
     Monte Carlo (n=15,000-40,000 draws) and the scenario/sensitivity grids, so
     each is memoised on a normalised key. Repeat renders with unchanged inputs
     therefore cost nothing. Cache is per-session, in memory only, and bounded. */
  NC._cache = { simulate: {}, scenarios: {}, sensitivity: {}, hits: 0, misses: 0 };
  function memo(bucket, key, fn) {
    var c = NC._cache[bucket];
    if (Object.prototype.hasOwnProperty.call(c, key)) { NC._cache.hits++; return c[key]; }
    if (Object.keys(c).length > 240) { NC._cache[bucket] = c = {}; }   // bounded memory
    NC._cache.misses++;
    return (c[key] = fn());
  }
  NC.cacheStats = function () {
    return {
      hits: NC._cache.hits, misses: NC._cache.misses,
      sizes: { simulate: Object.keys(NC._cache.simulate).length,
               scenarios: Object.keys(NC._cache.scenarios).length,
               sensitivity: Object.keys(NC._cache.sensitivity).length }
    };
  };
  NC.resetCache = function () { NC._cache = { simulate: {}, scenarios: {}, sensitivity: {}, hits: 0, misses: 0 }; };

  /* Trailing-edge debounce: used by the shell for slider drags, so a 12-month
     re-projection runs once when the user settles, not on every pixel. */
  NC.debounce = function (fn, ms) {
    var t = null;
    return function () {
      var self = this, args = arguments;
      if (t) { clearTimeout(t); }
      t = setTimeout(function () { t = null; fn.apply(self, args); }, ms === undefined ? 110 : ms);
    };
  };

  /* normalised keys — rounding makes floats that print the same memoise the same */
  function r6(x) { return Math.round((+x || 0) * 1e6) / 1e6; }
  function paramsKey(P) {
    return ['monthlyRetention', 'retentionResponse', 'loyaltyMonths', 'secondOrder30d',
      'thirdOrderRepeat', 'firstOrderConv', 'aov', 'takeRate', 'reliabilityShare',
      'sigmaBase', 'promiseOffset']
      .map(function (k) { return k + '=' + r6(P[k]); }).join(',');
  }

  function simulateRaw(opts) {
    var o = opts || {};
    var n = o.n || 30000;
    if (n > 200000) { n = 200000; }        // hard bound: a render can never hang the page
    var mix = o.mix || NC.BASE_MIX;
    var p2base = o.p2 || NC.DEFAULTS.secondOrder30d;
    var p3base = o.p3 || NC.DEFAULTS.thirdOrderRepeat;
    var L0 = o.loyaltyMonths || NC.DEFAULTS.loyaltyMonths;    // months an established customer keeps ordering
    var F = NC.FREQ;
    var rnd = o.rng || NC.rng, i;         // own stream when given one (see NC.simulate)
    var agg = { clean: 0, late: 0, substituted: 0, cancelled: 0, compensated: 0, secondOrder: 0, thirdOrder: 0, orders: 0, months3plus: 0 };

    for (i = 0; i < n; i++) {
      var u = rnd(), bad;
      if (u < mix.cancel) { bad = 'cancelled'; agg.cancelled++; }
      else if (u < mix.cancel + mix.late15) { bad = 'late'; agg.late++; }
      else if (u < mix.cancel + mix.late15 + mix.sub) { bad = 'substituted'; agg.substituted++; }
      else if (u < mix.cancel + mix.late15 + mix.sub + mix.ticket) { bad = 'compensated'; agg.compensated++; }
      else { bad = 'clean'; agg.clean++; }

      var mult = NC.OUTCOME_MULT[bad] * NORM;
      var p2 = NC.clamp(p2base * mult, 0.02, 0.85);
      var p3 = NC.clamp(p3base * (1 + (mult - 1) * 0.8), 0.05, 0.92);
      var months3 = NC.clamp(L0 / mult, 1.5, 48);        // churn is inversely proportional to the experience
      var orders = F.m1;

      if (rnd() < p2) {
        orders += F.m2; agg.secondOrder++;
        if (rnd() < p3) {
          orders += F.m3; agg.thirdOrder++;
          var extra = 0, pl = 1 - 1 / months3;
          while (extra < 60 && rnd() < pl) { orders += F.m3plus; extra++; }
          agg.months3plus += extra;
        }
      }
      agg.orders += orders;
    }
    return {
      n: n,
      outcomes: { clean: agg.clean / n, late: agg.late / n, substituted: agg.substituted / n, cancelled: agg.cancelled / n, compensated: agg.compensated / n },
      p2: agg.secondOrder / n,
      p3: agg.thirdOrder / Math.max(1, agg.secondOrder),
      months3plus: agg.months3plus / Math.max(1, agg.thirdOrder),
      ordersPerCustomer: agg.orders / n,
      mixMean: mixMean(mix), norm: NORM
    };
  }

  NC.simulate = function (opts) {
    var o = opts || {};
    var mix = o.mix || NC.BASE_MIX;
    var key = ['n=' + Math.min(o.n || 30000, 200000),
      'c=' + r6(mix.cancel), 'l=' + r6(mix.late15), 's=' + r6(mix.sub), 't=' + r6(mix.ticket),
      'p2=' + r6(o.p2), 'p3=' + r6(o.p3), 'lm=' + r6(o.loyaltyMonths)].join('|');
    return memo('simulate', key, function () {
      /* Seed a private stream from the key (FNV-1a). This makes a simulation a
         pure function of its inputs: the answer cannot change because some other
         view happened to consume the shared RNG first. */
      var h = 2166136261;
      for (var i = 0; i < key.length; i++) { h ^= key.charCodeAt(i); h = (h * 16777619) >>> 0; }
      var o2 = Object.assign({}, o, { rng: NC.mulberry32(h || 1) });
      return simulateRaw(o2);
    });
  };

  NC.businessCase = function (params) {
    var P = Object.assign({}, NC.DEFAULTS, params || {});
    var target = P.targetMix || NC.mixWithTicket({ cancel: 0.06, late15: 0.035, sub: 0.04 });
    /* n=200,000: large enough that "today's mix reproduces the disclosed 31%
       second order rate" holds to ~0.1pp. Memoised, so the cost is paid once. */
    var legacy = NC.simulate({ mix: NC.BASE_MIX, p2: P.secondOrder30d, p3: P.thirdOrderRepeat, loyaltyMonths: P.loyaltyMonths, n: 200000 });
    var sure = NC.simulate({ mix: target, p2: P.secondOrder30d, p3: P.thirdOrderRepeat, loyaltyMonths: P.loyaltyMonths, n: 200000 });
    function money(s) { return s.ordersPerCustomer * P.aov * P.takeRate; }
    var ltvLegacy = money(legacy), ltvSure = money(sure);
    var acq = (NC.CASE.kpi.promo.now * NC.CASE.marketing.buyShare) / NC.kpis.newBuyersPerMonth;
    return {
      legacy: legacy, sure: sure, targetMix: target,
      ltvLegacy: ltvLegacy, ltvSure: ltvSure, ltvLift: (ltvSure - ltvLegacy) / ltvLegacy,
      ordersLegacy: legacy.ordersPerCustomer, ordersSure: sure.ordersPerCustomer,
      cac: acq, ltvCacLegacy: ltvLegacy / acq, ltvCacSure: ltvSure / acq,
      cohortMonthlyGain: (ltvSure - ltvLegacy) * NC.kpis.newBuyersPerMonth,
      p2Legacy: legacy.p2, p2Sure: sure.p2
    };
  };

  /* ======================= 6. NETWORK LEAK MAP =========================== */
  NC.worldRates = function (world) {
    world = world || NC.STORES;
    var ws = 0, c = 0, l = 0, s = 0;
    world.forEach(function (x) { ws += x.orderWeight; c += x.orderWeight * x.cancelRate; l += x.orderWeight * x.lateRate; s += x.orderWeight * x.subRate; });
    var out = { cancel: c / ws, late: l / ws, sub: s / ws };
    out.ticket = NC.worldTicketRate({ cancel: out.cancel, late15: out.late, sub: out.sub });
    return out;
  };

  NC.leakMap = function (world) {
    world = world || NC.STORES;
    var K = NC.CASE.kpi, AOV = K.aov.now, take = NC.kpis.takeNow, orders = K.orders.now;
    var R = NC.worldRates(world);
    var cancels = orders * R.cancel;
    var delivered = orders - cancels;
    var lateOrders = orders * R.late;
    var subOrders = orders * R.sub;

    var lines = [
      { id: 'lostGMV', label: 'Revenue lost on cancelled orders', owner: 'Inventory accuracy',
        value: cancels * AOV * take, detail: F.num(cancels) + ' orders/mo · ' + F.pct(R.cancel) + ' of demand',
        lever: 'Availability score + verified-stock gate', evidence: 'Case §5 order outcomes' },
      { id: 'support', label: 'Support cost caused by fulfilment failures', owner: 'Support',
        value: orders * R.ticket * 0.72 * NC.CASE.support.ticketCost,
        detail: F.num(orders * R.ticket) + ' tickets/mo · 72% are refund, delay or missing-item',
        lever: 'Fewer failures + proactive status push', evidence: 'Case §8 ticket mix' },
      { id: 'refund', label: 'Refunds & goodwill compensations', owner: 'Refunds',
        value: orders * 0.06 * 42, detail: '6% of orders need a refund or a support fix, ~₹42 of compensation each',
        lever: 'Confirm before payment · auto-compensate after', evidence: 'Case §5 · ₹42 per case assumed' },
      { id: 'rider', label: 'Rider minutes burnt on re-tries and waits', owner: 'Delivery',
        value: lateOrders * 34, detail: F.num(lateOrders) + ' orders/mo arrive >15 min late · ~₹34 of idle rider-minutes each',
        lever: 'An honest promise is a schedulable promise', evidence: 'Case §5 · ₹34 per case assumed' },
      { id: 'subCost', label: 'Substitution friction (calls, swaps, comps)', owner: 'Store ops',
        value: subOrders * 42, detail: F.num(subOrders) + ' orders/mo contain a substitute the customer did not approve',
        lever: 'Offer the swap before ordering, not after', evidence: 'Case §5 · ₹42 per case assumed' }
    ];
    var reliabilityLeak = lines.reduce(function (a, l) { return a + l.value; }, 0);
    /* Sensitivity: rebuild the leak with the assumed unit costs halved. Those are
       the only soft inputs in the map — every other input is a disclosed
       order-level rate — so this is the honest "what if our assumptions are
       generous to us" test. */
    function byId(id) { return (lines.filter(function (l) { return l.id === id; })[0] || { value: 0 }).value; }
    var softLines = byId('refund') + byId('rider') + byId('subCost');
    /* Sensitivity: rebuild the leak with the assumed unit costs halved. Those are
       the only soft inputs in the map — every other input is a disclosed
       order-level rate — so this is the honest "what if our assumptions are
       generous to us" test. */
    function byId(id) { return (lines.filter(function (l) { return l.id === id; })[0] || { value: 0 }).value; }
    var softLines = byId('refund') + byId('rider') + byId('subCost');
    /* ONE cohort number in the whole submission: the business case at the full
       fixed failure mix. Realisability is handled separately and explicitly by
       the coverage ramp in the 12-month plans — not by silently haircutting the
       mix here and reporting a second, smaller figure elsewhere. */
    var bc = NC.businessCase();

    return {
      lines: lines,
      reliabilityLeak: reliabilityLeak,
      softAssumedCost: softLines,
      reliabilityLeakSoftHalf: reliabilityLeak - 0.5 * softLines,
      promoWaste: K.promo.now * 0.44,
      cohortLifetimeRevenueGain: bc.cohortMonthlyGain,
      totalMonthlyValue: reliabilityLeak + bc.cohortMonthlyGain,
      annualised: (reliabilityLeak + bc.cohortMonthlyGain) * 12,
      annualisedDirect: reliabilityLeak * 12,
      rates: Object.assign({}, R, { cancels: cancels, lateOrders: lateOrders, subOrders: subOrders, delivered: delivered }),
      businessCase: bc
    };
  };

  /* ============= 7. INTERVENTION QUEUE (generated from the data) ========= */
  NC.interventionQueue = function (world) {
    world = world || NC.STORES;
    var AOV = NC.CASE.kpi.aov.now, take = NC.kpis.takeNow;
    var bc = NC.businessCase();
    var ltvLift = bc.ltvSure - bc.ltvLegacy;              // ₹ of lifetime revenue rescued per failed experience
    var out = [];

    world.forEach(function (s) {
      var cancels = s.monthlyOrders * s.cancelRate;
      var tickets = s.monthlyOrders * NC.worldTicketRate({ cancel: s.cancelRate, late15: s.lateRate, sub: s.subRate });
      var subs = s.monthlyOrders * s.subRate;
      void 0;
      var remC = cancels, remS = subs, remT = tickets;

      var acts = [];
      if (s.syncHours > 6) acts.push({ id: 'sync', label: 'Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day', cutCancel: s.syncHours > 36 ? 0.48 : s.syncHours > 24 ? 0.42 : 0.30, cutSub: 0.25, cutTicket: 0.30, effort: 1 });
      if (s.cancelRate > 0.14) acts.push({ id: 'gate', label: 'Availability-gate the riskiest SKUs until the store verifies them', cutCancel: 0.28, cutSub: 0.15, cutTicket: 0.18, effort: 1 });
      if (s.acceptRate < 0.93) acts.push({ id: 'cap', label: 'Send a peak-hour demand forecast + a capacity cap the store can accept', cutCancel: 0.16, cutSub: 0, cutTicket: 0.10, effort: 1 });
      if (s.subRate > 0.09) acts.push({ id: 'subsop', label: "Push a 2-tap substitution SOP with this store's 5 most likely swaps", cutCancel: 0, cutSub: 0.45, cutTicket: 0.12, effort: 1 });
      if (s.reliability < 55) acts.push({ id: 'call', label: 'Partner-success call — churn-risk store (18% of partners are considering leaving)', cutCancel: 0.09, cutSub: 0.05, cutTicket: 0.08, effort: 2 });
      if (s.syncHours <= 6 && s.cancelRate > 0.075) acts.push({ id: 'nudge', label: 'Turn on the pre-peak stock nudge — 3 SKUs likely to run out this evening', cutCancel: 0.14, cutSub: 0.10, cutTicket: 0.10, effort: 1 });

      acts.forEach(function (a) {
        /* incremental, so actions on the same store never double-count */
        var dC = remC * a.cutCancel, dS = remS * a.cutSub, dT = remT * a.cutTicket;
        var vCancel = dC * AOV * take;
        var vSub = dS * 42;
        var vTicket = dT * NC.CASE.support.ticketCost;
        var vRepeat = dC * ltvLift * 0.55;
        remC -= dC; remS -= dS; remT -= dT;
        out.push(Object.assign({ storeId: s.id, storeName: s.name, city: s.city, category: s.category,
          reliability: s.reliability, syncHours: s.syncHours, monthlyOrders: s.monthlyOrders,
          vCancel: vCancel, vSub: vSub, vTicket: vTicket, vRepeat: vRepeat,
          monthlyValue: vCancel + vSub + vTicket }, a,
          { gain: vCancel + vSub + vTicket + vRepeat }));
        out[out.length - 1].gain = vCancel + vSub + vTicket;
      });
    });
    out.sort(function (a, b) { return (b.gain / b.effort) - (a.gain / a.effort); });
    var cum = 0;
    out.forEach(function (a, i) { a.rank = i + 1; cum += a.gain; a.cumulative = cum; });
    out.totalMonthly = cum;
    out.totalLifetime = out.reduce(function (x, a) { return x + a.vRepeat; }, 0);
    return out;
  };

  NC.applyIntervention = function (storeId, actionId, cues) {
    var s = NC.storeById(storeId);
    if (!s) return null;
    cues = cues || {};
    var before = { syncHours: s.syncHours, cancelRate: s.cancelRate, subRate: s.subRate, acceptRate: s.acceptRate, reliability: s.reliability };
    var m = {
      sync:   { sync: 0, cancel: s.syncHours > 24 ? 0.58 : 0.72, sub: 0.80, rel: 22 },
      gate:   { cancel: 0.78, sub: 0.88, rel: 9 },
      cap:    { cancel: 0.88, acc: 0.07, rel: 6 },
      subsop: { sub: 0.62, rel: 5 },
      call:   { cancel: 0.94, acc: 0.03, rel: 4 },
      nudge:  { cancel: 0.90, sub: 0.92, rel: 6 }
    }[actionId];
    if (!m) return null;
    if (m.cancel) s.cancelRate *= m.cancel;
    if (m.sub) s.subRate *= m.sub;
    if (m.acc) s.acceptRate = Math.min(0.99, s.acceptRate + m.acc);
    if (actionId === 'sync') { s.syncHours = Math.min(s.syncHours, 2); s.syncPerDay = Math.max(s.syncPerDay, 3); }
    s.reliability = NC.clamp(s.reliability + (m.rel || 4), 12, 97);
    s.touched = true;
    return { store: s, before: before };
  };

  NC.autoHeal = function (limit) {
    var q = NC.interventionQueue().filter(function (a) { return !a.applied; });
    var applied = 0, gain = 0, done = {};
    for (var i = 0; i < q.length && applied < (limit || 20); i++) {
      var a = q[i];
      if (done[a.storeId + a.id]) continue;
      NC.applyIntervention(a.storeId, a.id);
      a.applied = true; done[a.storeId + a.id] = 1;
      applied++; gain += a.gain;
      NC.logIntervention(a.storeId, a.id, a.label, a.gain);
    }
    return { applied: applied, gain: gain };
  };

  /* ============= 8. TWELVE-MONTH COHORT MODEL (the coin, not the ad) ===== */
  NC.PLANS = {
    A: { id: 'A', name: 'Plan A — Scale acquisition', tagline: 'What management is considering: +30% marketing, no product change.',
         spendMult: 1.30, acqShare: 0.58, reliabilityShare: 0, program: 0, couponRecovery: 0,
         mix: NC.BASE_MIX, attempt: true },
    B: { id: 'B', name: 'Plan B — NOVA SURE', tagline: '₹25L reliability product, promo held flat, the 44% of coupons that were never redeemed re-pointed at retention.',
         spendMult: 1.00, acqShare: 0.58, reliabilityShare: 1, program: 2500000, couponRecovery: 0.25,
         mix: { cancel: 0.06, late15: 0.035, sub: 0.04, ticket: 0.105 }, attempt: true },
    C: { id: 'C', name: 'Plan C — Do nothing', tagline: 'Hold spend flat and ship nothing. The honest counterfactual.',
         spendMult: 1.00, acqShare: 0.58, reliabilityShare: 0, program: 0, couponRecovery: 0, mix: NC.BASE_MIX }
  };
  NC.programPhase = [0.10, 0.16, 0.20, 0.20, 0.18, 0.16];

  /* The failure cost of the network as it stands today.  Everything in the
     projection is expressed as a DELTA against this month, because we do not
     know NOVA CART's rider base pay, commissions or tech costs — so we never
     claim an absolute profit number, only movement against today.        */
  NC.baselineMonth = (function () {
    var K = NC.CASE.kpi, AOV = K.aov.now, take = NC.kpis.takeNow, orders = K.orders.now;
    var M = NC.BASE_MIX;
    return {
      orders: orders,
      revenue: orders * AOV * take,
      promo: K.promo.now,
      tickets: K.tickets.now,
      support: K.tickets.now * NC.CASE.support.ticketCost,
      refundCancel: orders * M.cancel * AOV * take,
      compensation: orders * 0.06 * 42,
      rider: orders * (1 - M.cancel) * M.late15 * 34,
      sub: orders * (1 - M.cancel) * M.sub * 42
    };
  })();

  /* the repeat-rate reaction function is fitted to NOVA CART's own history:
     41% repeat when cancellations were 6%, 27% when they reached 11%.      */
  NC.repeatFromCancel = function (cancelRate, P) {
    var gap = NC.clamp((NC.BASE_MIX.cancel - cancelRate) / (NC.BASE_MIX.cancel - 0.06), 0, 1.2);
    return P.repeatRateNow + (P.historicRepeat - P.repeatRateNow) * P.reliabilityShare * gap;
  };

  NC.project = function (input) {
    input = input || {};
    var P = Object.assign({}, NC.DEFAULTS, input.params || {});
    var plan = Object.assign({}, NC.PLANS.B, input.plan || {});
    var months = input.months || 12;
    var coverage = input.coverage === undefined ? P.coverage : input.coverage;
    var startPromo = NC.CASE.kpi.promo.now;
    var baseAcq = startPromo * 0.58;
    var isFix = plan.id === 'B';
    var cov = isFix ? coverage : 0;

    /* the product is the only thing that changes the failure mix */
    var mix = {};
    ['cancel', 'late15', 'sub', 'ticket'].forEach(function (k) {
      mix[k] = NC.BASE_MIX[k] + (plan.mix[k] - NC.BASE_MIX[k]) * cov;
    });

    /* the funnel responds to the failure mix, analytically — no sampling noise */
    var mixLift = mixMean(mix) / mixMean(NC.BASE_MIX);
    var p2 = NC.clamp(P.secondOrder30d * mixLift, 0.10, 0.70);
    var churn = (1 - P.monthlyRetention) * (1 - P.retentionResponse * cov);
    var pRetain = 1 - churn;
    var freq = P.freqReturning * (1 + (mixLift - 1) * 0.30);
    var conv = NC.clamp(P.firstOrderConv * (1 + (mixLift - 1) * 0.40), 0.30, 0.85);

    var returning = NC.NOW.orderingCustomers - NC.NOW.newBuyers;
    var registered = NC.CASE.kpi.registered.now;
    var rows = [], cumProgram = 0, cumContribution = 0;
    var programTotal = plan.program * (1 + (input.programOverrun || 0));
    var prevNewBuyers = NC.NOW.newBuyers;

    for (var m = 1; m <= months; m++) {
      var rampIn = m / 3;
      /* the fix rolls out store by store: coverage ramps to plan level by M4 */
      var covM = cov * Math.min(1, m / 4);
      var mixM = {};
      ['cancel', 'late15', 'sub', 'ticket'].forEach(function (k) {
        mixM[k] = NC.BASE_MIX[k] + (plan.mix[k] - NC.BASE_MIX[k]) * covM;
      });
      var mixM = NC.mixWithTicket(mixM);
      var liftM = mixMean(mixM) / mixMean(NC.BASE_MIX);
      var churnM = (1 - P.monthlyRetention) * (1 - P.retentionResponse * covM);
      var p2M = NC.clamp(P.secondOrder30d * liftM, 0.10, 0.70);
      var freqM = P.freqReturning * (1 + (liftM - 1) * 0.30);
      var convM = NC.clamp(P.firstOrderConv * (1 + (liftM - 1) * 0.40), 0.30, 0.85);
      var spendMult = 1 + (plan.spendMult - 1) * Math.min(1, m / 2);
      var promo = plan.attempt === false ? startPromo : startPromo * spendMult;
      if (plan.id === 'C') promo = startPromo;
      var couponSave = plan.couponRecovery ? startPromo * 0.44 * plan.couponRecovery : 0;
      var newReg = NC.CASE.marketing.newRegPerMonth * Math.pow((promo * plan.acqShare) / baseAcq, 0.75);
      var newBuyers = newReg * convM * (plan.id === 'A' ? 1 + 0.04 * Math.min(1, rampIn) : 1);

      var retained = returning * (1 - churnM);
      var inflow = prevNewBuyers * p2M;                                 // last month's buyers returning
      var returningPrev = returning;
      returning = retained + inflow;

      var orders = newBuyers * NC.FREQ.m1 + returning * freqM;
      var gmv = orders * P.aov;
      var take = plan.id === 'A' ? 0.134 : plan.id === 'B' ? 0.141 : P.takeRate;
      var mix = mixM;
      var revenue = gmv * take;

      var B = NC.baselineMonth;
      var tickets = orders * mixM.ticket;
      var supportCost = tickets * NC.CASE.support.ticketCost;
      var refundCancel = orders * mix.cancel * P.aov * take;
      var compensation = orders * 0.06 * (mixM.ticket / NC.BASE_MIX.ticket) * 42;
      var rider = orders * mixM.late15 * 34;
      var subCost = orders * mixM.sub * 42;
      var prog = m <= 6 ? programTotal * NC.programPhase[m - 1] : 0;
      cumProgram += prog;
      /* everything is a delta against the month we are standing in */
      var dRevenue = revenue - B.revenue;
      var dCost = (supportCost - B.support) + (refundCancel + compensation - B.refundCancel - B.compensation)
        + (rider - B.rider) + (subCost - B.sub);
      var contribution = dRevenue - dCost - (promo - B.promo) - prog;
      cumContribution += contribution;

      registered += newReg;
      prevNewBuyers = newBuyers;
      rows.push({
        month: m, promo: promo, newReg: newReg, newBuyers: newBuyers, returning: returning,
        returningPrev: returningPrev, retained: retained, inflow: inflow,
        orderingCustomers: newBuyers + returning,
        orders: orders, gmv: gmv, revenue: revenue, take: take, mixUsed: mixM, covM: covM,
        tickets: tickets, supportCost: supportCost, program: prog, contribution: contribution,
        refundCost: refundCancel + compensation, riderCost: rider, subCost: subCost,
        dRevenue: dRevenue, dCost: dCost, cumContribution: cumContribution, couponSave: couponSave,
        ordersAbs: orders * (1 - mix.cancel), servedShare: 1 - mix.cancel,
        p2: p2M, pRetain: 1 - churnM, churn: churnM, mixLift: liftM,
        /* lifetime repeat metric: NOVA CART's own two-point elasticity */
        repeatRate: NC.repeatFromCancel(mixM.cancel, { repeatRateNow: P.repeatRateNow, historicRepeat: P.historicRepeat, reliabilityShare: P.reliabilityShare }),
        costPerOrder: (promo + supportCost) / orders, promoPerOrder: promo / orders
      });
    }
    var m6 = rows[Math.min(5, rows.length - 1)], last = rows[rows.length - 1];
    var payback = null;
    if (plan.program > 0) for (var i = 0; i < rows.length; i++) if (rows[i].cumContribution >= 0) { payback = rows[i].month; break; }
    return {
      plan: plan, params: P, rows: rows, mix: mix, coverage: cov, paybackMonth: payback,
      runRateM12: last.contribution,
      m6: m6, m12: last,
      cumulative6: rows.slice(0, 6).reduce(function (a, r) { return a + r.contribution; }, 0),
      cumulative12: cumContribution, programSpent: cumProgram,
      derived: { p2: p2, pRetain: pRetain, churn: churn, freq: freq, conv: conv, mixLift: mixLift }
    };
  };

  function scenariosRaw(params, coverage) {
    return {
      A: NC.project({ plan: NC.PLANS.A, params: params, months: 12 }),
      B: NC.project({ plan: NC.PLANS.B, params: params, months: 12, coverage: coverage }),
      C: NC.project({ plan: NC.PLANS.C, params: params, months: 12 })
    };
  }
  NC.scenarios = function (params, coverage) {
    var P = Object.assign({}, NC.DEFAULTS, params || {});
    return memo('scenarios', paramsKey(P) + '|cov=' + r6(coverage), function () {
      return scenariosRaw(P, coverage);
    });
  };

  /* =========================== 9. SENSITIVITY =========================== */
  function sensitivityRaw(params, cov) {
    var lifts = [0, 0.25, 0.5, 0.75, 1.0];
    var spends = [0.9, 1.0, 1.1, 1.2, 1.3];
    var grid = lifts.map(function (L) {
      return spends.map(function (S) {
        var plan = Object.assign({}, NC.PLANS.B, {
          reliabilityShare: 1, spendMult: S, attempt: true} );
        var r = NC.project({ plan: plan, params: params, months: 12, coverage: L });
        return { lift: L, spend: S, contribution6: r.cumulative6, revenueM12: r.m12.revenue, ordersM12: r.m12.orders, repeatM12: r.m12.repeatRate, ordersM6: r.m6.orders };
      });
    });
    return { lifts: lifts, spends: spends, grid: grid };
  }
  NC.sensitivity = function (params, cov) {
    var P = Object.assign({}, NC.DEFAULTS, params || {});
    return memo('sensitivity', paramsKey(P) + '|cov=' + r6(cov), function () {
      return sensitivityRaw(P, cov);
    });
  };

  /* ====================== 10. THE DECISION COPILOT ======================= */
  var QA = [
    { id: 'growth-quality', keys: ['growth', 'quality', 'bigger', 'better', 'improving', 'trajectory'],
      run: function () {
        var K = NC.CASE.kpi, d = NC.kpis;
        return {
          q: 'Is NOVA CART getting better, or just bigger?',
          headline: 'Bigger, and worse on every quality axis that predicts repeat purchase.',
          evidence: [
            'Orders ' + F.num(K.orders.prior) + ' → ' + F.num(K.orders.now) + ' (' + F.signed((K.orders.now - K.orders.prior) / K.orders.prior) + '); revenue ' + F.lakh(K.revenue.prior) + ' → ' + F.lakh(K.revenue.now) + ' (' + F.signed((K.revenue.now - K.revenue.prior) / K.revenue.prior) + ')',
            'Promotional spend ' + F.lakh(K.promo.prior) + ' → ' + F.lakh(K.promo.now) + ' (' + F.signed((K.promo.now - K.promo.prior) / K.promo.prior) + ') — spend grew ' + (((K.promo.now - K.promo.prior) / K.promo.prior) / ((K.revenue.now - K.revenue.prior) / K.revenue.prior)).toFixed(1) + '× faster than revenue',
            'Repeat ' + F.pct(K.repeat.prior, 0) + ' → ' + F.pct(K.repeat.now, 0) + ' · delivery ' + K.delivery.prior + ' → ' + K.delivery.now + ' min · cancellation ' + F.pct(K.cancel.prior, 0) + ' → ' + F.pct(K.cancel.now, 0) + ' · tickets ' + F.num(K.tickets.prior) + ' → ' + F.num(K.tickets.now),
            'In customers: repeat buyers ' + F.num(d.repeatCustPrior) + ' → ' + F.num(d.repeatCustNow) + ' — ' + F.num(Math.abs(d.repeatCustDelta)) + ' FEWER repeat buyers while registrations rose by ' + F.num(d.registeredDelta) + ' (defined as registered users x repeat rate; on MAU x rate the fall is ' + F.num(Math.abs(d.repeatBases[1].now - d.repeatBases[1].prior)) + ', on orders x rate ' + F.num(Math.abs(d.repeatBases[2].now - d.repeatBases[2].prior)) + ' — every basis falls)'
          ],
          method: 'Case-pack figures. Repeat buyers are defined as registered users x repeat purchase rate — the most conservative of the three possible bases (MAU x rate and orders x rate both fall by more), which is why the count is quoted as a floor rather than a point estimate.',
          recommendation: 'Stop reporting growth in registrations. The only number that compounds is repeat buyers, and that number fell.',
          confidence: 'High — this is arithmetic, not inference.'
        };
      } },
    { id: 'leak', keys: ['leak', 'cost of', 'how much', 'money', 'losing', 'reliability cost', 'cost us',
        'costing', 'unreliable fulfilment', 'unreliable', 'fulfilment', 'per month', 'every month', 'wasted', 'burn'],
      run: function () {
        var L = NC.leakMap();
        return {
          q: 'What is unreliable fulfilment costing NOVA CART every month?',
          headline: F.lakh(L.reliabilityLeak) + '/month of direct leak, on top of ' + F.lakh(L.cohortLifetimeRevenueGain) + '/month of lifetime revenue lost from each new cohort.',
          evidence: L.lines.map(function (l) { return l.label + ' — ' + F.lakh(l.value) + ' (' + l.detail + ')'; })
            .concat(['Lifetime revenue from one month\'s acquired customers: ' + F.inr(L.businessCase.ltvLegacy) + '/customer today vs ' + F.inr(L.businessCase.ltvSure) + ' with the failure mix fixed — ' + F.lakh(L.cohortLifetimeRevenueGain) + ' per monthly cohort']),
          method: 'Leak = cancelled-order revenue + failure-driven support + refunds + wasted rider minutes + substitution friction. Cohort value comes from the Monte Carlo funnel, not from a rule of thumb.',
          recommendation: 'Recovering 55% of the direct leak is ' + F.lakh(L.reliabilityLeak * 0.55) + '/month — the entire ₹25L programme pays for itself in under ' + (2500000 / (L.reliabilityLeak * 0.55)).toFixed(1) + ' months.',
          confidence: 'Medium-high. Order-level rates are disclosed; ₹42 refund and ₹34 rider-minute costs are stated assumptions and can be replaced in one line.'
        };
      } },
    { id: 'promo', keys: ['promo', 'marketing', 'spend', 'discount', 'budget', 'roas', 'acquire', 'acquisition', '30%', 'coupon'],
      run: function () {
        var d = NC.kpis;
        var K = NC.CASE.kpi;
        var dOrders = K.orders.now - K.orders.prior, dPromo = K.promo.now - K.promo.prior;
        return {
          q: 'Should NOVA CART increase marketing spend by another 30%?',
          headline: 'No. Every incremental order bought in the last six months cost more than it earned.',
          evidence: [
            'Incremental promo spend ' + F.lakh(dPromo) + '/mo bought ' + F.num(dOrders) + ' incremental orders = ' + F.inr(d.marginalPromoPerOrder) + ' of promo per EXTRA order, and those extra orders added ' + F.inr(d.marginalRevPerOrder) + ' of platform revenue each. (Today\'s average revenue per order is ' + F.inr(d.netRevPerOrder) + ' — an average is not what the extra spend bought. Marginal-to-marginal is the like-for-like comparison: ' + d.marginalRevPerOrder.toFixed(0) + ' / ' + d.marginalPromoPerOrder.toFixed(0) + ' = ' + d.incrementalRoas.toFixed(2) + 'x.)',
            'ROAS, one definition: extra revenue / extra spend = ' + d.incrementalRoas.toFixed(2) + '×. Even on the most generous reading — today\'s *average* revenue per order divided by the marginal promo cost of an extra order (' + F.inr(d.netRevPerOrder) + ' / ' + F.inr(d.marginalPromoPerOrder) + ') — it is ' + d.roasBoundGenerous.toFixed(2) + '×. Blended, the whole business runs at ' + d.blendedRoas.toFixed(2) + '×. All three are below 1, so the conclusion survives any of them.',
            'The experiment has already run: +' + F.num(d.registeredDelta) + ' registered users and ' + F.num(Math.abs(d.repeatCustDelta)) + ' fewer repeat buyers.',
            'Cost to acquire one buyer ≈ ' + F.inr(Math.round(d.cacPerNewBuyer / 10) * 10) + ' (58% acquisition-tagged spend ÷ ' + F.num(Math.round(d.newBuyersPerMonth)) + ' first orders/mo) against ' + F.inr(NC.businessCase().ltvLegacy) + ' of lifetime revenue at today\'s experience mix.',
            F.lakh(K.promo.now * 0.44) + '/month of coupons are issued and never redeemed (case §4) — that is the budget line to move, and it needs no approval.'
          ],
          method: 'Marginal ROAS, promo-per-order and repeat-buyer count come straight from the disclosed six-month numbers; LTV comes from the funnel simulation.',
          recommendation: 'Hold the budget flat, ship the reliability layer, and re-point the never-redeemed coupon spend at customers who have just had a bad experience — the moment when a gesture actually changes behaviour.',
          confidence: 'High on the marginal ROAS; medium on the absolute LTV level.'
        };
      } },
    { id: 'inventory', keys: ['inventory', 'stock', 'availability', 'unavailable', 'sku', 'catalog'],
      run: function () {
        var R = NC.CASE.cancelReasons;
        return {
          q: 'Is the bottleneck inventory accuracy or delivery speed?',
          headline: 'Inventory accuracy — because it is upstream of the cancellations and of the delay.',
          evidence: [
            R[0].pct + '% of cancellations are "product unavailable" and ' + R[2].pct + '% more are the store rejecting the order — ' + (R[0].pct + R[2].pct) + '% of cancellations start as a stock record that was wrong.',
            '29% of surveyed customers were shown stock that did not exist; 19% repeatedly search for products no nearby store carries.',
            'Partner stores refresh the catalogue anywhere between 4× a day and once every 2 days. A 36-hour-old stock number is not a fact.',
            'External: 65% of retail inventory records are inaccurate, with a mean deviation of 35% of on-shelf stock (DeHoratius & Raman, 2008). This is normal retail, not a NOVA CART-specific failing — so the fix cannot be "try harder".'
          ],
          method: 'Cancellation-reason mix + customer survey + disclosed partner sync behaviour, cross-checked against published inventory-record-accuracy research.',
          recommendation: 'Stop asking stores to be more accurate. Treat every stock number as an estimate with a confidence score, and gate the customer promise on that score.',
          confidence: 'High on the mechanism; the size of the effect is proven store by store in the Store app.'
        };
      } },
    { id: 'eta', keys: ['eta', 'promise', 'late', 'delay', 'delivery time', '37', 'speed', 'faster'],
      run: function () {
        var s = NC.STORES.slice().sort(function (a, b) { return b.reliability - a.reliability; })[0];
        var cart = [{ skuId: 'SKU01', qty: 1 }, { skuId: 'SKU04', qty: 2 }, { skuId: 'SKU17', qty: 1 }];
        var p = NC.promise(s, cart, {});
        var r = NC.routeBasket(cart, s.city, { primaryStoreId: s.id });
        var L = NC.leakMap();
        return {
          q: 'Customers say delivery is too slow. Should we deliver faster?',
          headline: 'No — promise accurately. The app currently advertises ' + p.legacy.promise + ' min on a ' + p.central + ' min job and misses its own number ' + F.pct(p.legacy.late15, 1) + ' of the time.',
          evidence: [
            'Honest central estimate for this basket from our best store: ' + p.central + ' min ± ' + p.sigma + ' min. The app advertises ' + p.legacy.promise + ' min.',
            'Late by >15 min: ' + F.pct(p.legacy.late15, 1) + ' → ' + F.pct(p.smart.late15, 1) + ' with an honest promise (' + p.smart.promise + ' min) and verified stock. Arriving within ±5 min of the promise: ' + F.pct(p.legacy.kept, 0) + ' → ' + F.pct(p.smart.kept, 0) + '.',
            NC.CASE.cancelReasons[1].pct + '% of cancellations are customers cancelling because of the delay — the promise is generating its own cancellations. Wasted rider time costs ' + F.lakh(L.lines[3].value) + '/month.',
            'External: late deliveries lengthen the gap to the next purchase while early ones shorten it (Harter, Stich & Spann, 2024, Q-commerce repurchase study); 69% of shoppers are less likely to buy again after a missed delivery window (Voxware); 71% forgive a delay if they are told why and given a new accurate ETA (Circuit Logistics, 2025).'
          ],
          method: 'Delivery time modelled as a normal distribution around the store\'s real prep + travel time; the late rate is the tail beyond the promise. Two visible parameters: central estimate and variance.',
          recommendation: 'Sell a 5-minute window you can keep instead of a 30-minute promise you miss. Speed is a capex race we cannot win; honesty is free and it compounds.',
          confidence: 'High on direction, and the parameters are visible sliders.'
        };
      } },
    { id: 'churn', keys: ['churn', 'stopped', 'stop ordering', '4 star', '4★', '61', 'rating', 'leave', 'loyal', 'satisfied'],
      run: function () {
        return {
          q: 'Why do customers who liked us stop ordering?',
          headline: 'Because they liked us. 61% of churned customers had rated NOVA CART 4★ or higher.',
          evidence: [
            'A 4★+ customer is not someone who disliked the product — it is someone whose expectation was formed and then broken.',
            'Every promise broke in the same six months: delivery +8 min, cancellations +5 pts, tickets +90%, delivery accuracy complaints 34% of survey mentions.',
            'The top survey reasons are not "the app is bad": 38% price/fees, 34% delivery, 29% availability, 24% confusing discounts.',
            'External: 32% of consumers stop doing business with a brand they love after one bad experience (PwC); 55% switch for more reliable delivery (Capgemini).'
          ],
          method: 'Case §3 churn signal + survey mix + published service-failure research.',
          recommendation: 'Treat churn as a recovery problem, not an acquisition problem: detect the bad experience within the hour and repair it before the customer quietly leaves.',
          confidence: 'High on the diagnosis.'
        };
      } },
    { id: 'funnel', keys: ['funnel', 'second order', '31', 'first order', '54', 'conversion', 'cliff'],
      run: function () {
        var bc = NC.businessCase();
        return {
          q: 'Where is the highest-leverage point in the funnel?',
          headline: 'The 54% → 31% cliff. Two-thirds of first orders never become a second order.',
          evidence: [
            '54% of new users complete a first order; 31% of those place a second within 30 days; customers who reach 3 orders carry a 72% monthly repeat probability (case §4).',
            'That is a cliff, not a slope: 1 → 2 orders loses ' + F.pct(1 - 0.31, 0) + ' of the audience, and 3+ orders is where the compounding starts.',
            'Simulating the current failure mix gives ' + bc.ordersLegacy.toFixed(2) + ' lifetime orders per acquired customer = ' + F.inr(bc.ltvLegacy) + ' of platform revenue, against ' + F.inr(Math.round(bc.cac / 10) * 10) + ' of acquisition cost → LTV:CAC ' + bc.ltvCacLegacy.toFixed(2) + ':1.',
            'The same simulator with the failure mix fixed gives ' + bc.ordersSure.toFixed(2) + ' orders and ' + F.inr(bc.ltvSure) + ' — a ' + F.pct(bc.ltvLift, 0) + ' lift in lifetime revenue per acquired customer, at zero extra acquisition cost.'
          ],
          method: 'Absorbing-chain simulation over the disclosed funnel (1 → 2 → 3+ orders), perturbed by the order-outcome mix through documented multipliers.',
          recommendation: 'Buy the second order, not the first. "3 orders unlocks 72%" is the product spec, and the promise is what gets a customer to order 3.',
          confidence: 'Medium-high — the funnel levels are disclosed; the outcome multipliers are explicit assumptions.'
        };
      } },
    { id: 'partner', keys: ['partner', 'store', 'merchant', '39', '18%', 'leaving', 'kirana'],
      run: function () {
        return {
          q: 'Are the partner stores the problem?',
          headline: 'No. They are the moat — and 18% of them are about to walk away.',
          evidence: [
            '46% of partners say NOVA CART brings valuable additional customers, but 39% say maintaining the online catalogue is too much effort and 18% are considering leaving within a year (case §6).',
            'The partner quote in the pack is the entire business case: "maintaining the online catalogue takes more effort than the additional business is worth."',
            'Meanwhile 21% of customers say they would rather buy directly from a nearby store, and larger platforms can outspend us on speed and discounts.',
            'External: ONDC now carries 7.64 lakh+ sellers across 616 cities with 21.8 crore transactions in FY26 at 8–10% commissions — the open rails for exactly this local assortment, with no warehouses required.'
          ],
          method: 'Partner survey + competitive structure + ONDC network data.',
          recommendation: 'Make the store-facing product so small that keeping stock honest takes 15 seconds. Store effort is the input, catalogue accuracy is the output, trust is the revenue.',
          confidence: 'High.'
        };
      } },
    { id: 'refund', keys: ['refund', 'support', 'ticket', 'resolution', 'complaint', 'helpdesk'],
      run: function () {
        var K = NC.CASE.kpi;
        return {
          q: 'Why are support tickets up 90% when orders only grew 23%?',
          headline: 'Because tickets are not driven by volume. They are driven by failures.',
          evidence: [
            'Tickets per 100 orders: ' + (NC.kpis.ticketRatePrior * 100).toFixed(1) + ' → ' + (NC.kpis.ticketRate * 100).toFixed(1) + ' (' + F.signed((NC.kpis.ticketRate - NC.kpis.ticketRatePrior) / NC.kpis.ticketRatePrior, 0) + ') while orders rose 23%.',
            '72% of tickets are refund status, delayed delivery or missing items (case §8) — the same failures visible in the order data.',
            'Support at ₹75 a ticket is ' + F.lakh(NC.kpis.supportCost) + '/month = ' + F.pct(NC.kpis.supportShareOfRevenue, 0) + ' of net revenue, up from ' + F.pct(NC.kpis.supportShareOfRevenuePrior, 0) + '.',
            'Average resolution is 9.2 hours across three systems that do not talk to each other — the first human contact happens long after the moment when the relationship could still have been saved.'
          ],
          method: 'Ticket-rate normalisation per 100 orders rather than absolute counts; ticket mix from case §8; ₹75 per ticket is a stated assumption.',
          recommendation: 'Resolve the order, not the ticket: detect the failure, credit automatically, message the customer before they contact us. Target ≈3,300 tickets/month at the same volume.',
          confidence: 'Medium-high on causation, high on the arithmetic.'
        };
      } },
    { id: 'moat', keys: ['moat', 'compete', 'blinkit', 'zepto', 'competitor', 'advantage', 'local', 'positioning'],
      run: function () {
        return {
          q: 'What can NOVA CART build that larger platforms cannot copy?',
          headline: 'Verified local availability — not speed, and not price.',
          evidence: [
            'Competitors win with dark stores and discounts: India\'s quick-commerce GMV is ~₹11,000 crore a month and Blinkit alone runs 1,300+ dark stores. NOVA CART has a ₹25L budget and an explicit no-warehouse constraint.',
            'NOVA CART has 620 independent stores holding products a dark store will never list. Today that advantage is hidden behind a catalogue that says "in stock" when it is not.',
            'Every verified availability signal makes the promise sharper and the local data asset harder to copy — it compounds, which a discount does not.',
            'External: 1.4 crore kirana stores still make 75–80% of FMCG sales in India. The category is being digitised anyway; the winner is whoever makes the local promise trustworthy.'
          ],
          method: 'Competitive structure + budget constraint + the case\'s own admission that the local advantage "has not yet been developed into a clear strategy".',
          recommendation: 'Position on "verified nearby", not "10 minutes". It is the only promise our cost structure can actually keep.',
          confidence: 'High on the positioning logic.'
        };
      } },
    { id: 'what-build', keys: ['what should', 'build', 'one product', 'recommend', 'answer', 'priority', 'final'],
      run: function () {
        var bc = NC.businessCase(), L = NC.leakMap();
        return {
          q: 'If NOVA CART could build exactly one digital product, what should it be?',
          headline: 'NOVA SURE — an availability-and-promise layer that sits on top of the systems NOVA CART already owns.',
          evidence: [
            'It attacks one shared cause: 53% of cancellations (stock records that were wrong), 27% more (delay-driven cancellations) and the 29% of customers shown stock that did not exist.',
            'No warehouses, no new headcount at scale — a reliability layer over the existing customer app, partner dashboard and order database.',
            'The ₹25L budget covers the build once; the direct leak it removes is ' + F.lakh(L.reliabilityLeak) + '/month before counting the ' + F.lakh(L.cohortLifetimeRevenueGain) + '/month of lifetime revenue it protects.',
            'It is the only intervention that raises LTV instead of buying it: ' + F.pct(bc.ltvLift, 0) + ' more lifetime revenue per acquired customer with no additional ad spend.',
            'And it changes the strategic question from "how do we out-discount Blinkit" to "why would a customer buy from a verified local store instead" — a question with an answer.'
          ],
          method: 'Cross-checked against every symptom in the case pack: survey, funnel, operations, partner, support and finance.',
          recommendation: 'Build NOVA SURE: three surfaces (customer promise, 15-second store sync, Ops Trust Console) on one shared spine. Then re-point marketing at the customers it rescues.',
          confidence: 'High.'
        };
      } }
  ];

  /* Each UI preset button maps to exactly one intent, so a preset can never
     fall through to the "no answer" path. Asserted in tests/demo_path.js. */
  var PRESET_INTENT = ['growth-quality', 'leak', 'promo', 'inventory', 'what-build', 'churn', 'refund', 'moat'];

  NC.copilot = function (question) {
    if (!question) return null;
    /* Deterministic keyword scoring: normalise the question (lower-case, strip
       punctuation) and score each intent by the total length of the phrases it
       matches, so a longer, more specific phrase beats a generic one. No model
       call, no randomness — the same question always returns the same answer. */
    var ql = question.toLowerCase().replace(/[^a-z0-9\u20b9%+ \u2605\u2b50 ]+/g, ' ').replace(/\s+/g, ' ').trim();
    var best = null, bestScore = 0;
    QA.forEach(function (item) {
      var s = 0;
      item.keys.forEach(function (k) { if (ql.indexOf(k) >= 0) { s += k.length; } });
      if (s > bestScore) { bestScore = s; best = item; }
    });
    /* Preset questions must always reach their own intent — they are the
       buttons the UI shows. If one ever fails to match, that is a bug, not a
       user error. */
    var presetIndex = NC.copilotPrompts.indexOf(question);
    if (presetIndex >= 0 && PRESET_INTENT[presetIndex]) { best = QA.filter(function (x) { return x.id === PRESET_INTENT[presetIndex]; })[0] || best; }
    if (!best) {
      return {
        q: question, matched: false, headline: 'No pre-computed answer for that phrasing.',
        evidence: ['Try: "is the business getting better", "what is reliability costing us", "should we raise marketing spend 30%", "is inventory or delivery the bottleneck", "why do 4★ customers churn", "what should we build".'],
        method: 'This copilot is deterministic: it answers only with numbers it can compute from the case data and the live model, and it shows its arithmetic. It never invents a figure.',
        recommendation: 'Re-phrase toward one of the themes above.',
        confidence: 'n/a'
      };
    }
    var r = best.run();
    r.matched = true; r.id = best.id;
    return r;
  };
  NC.copilotPrompts = [
    'Is NOVA CART getting better or just bigger?',
    'What is unreliable fulfilment costing us every month?',
    'Should we increase marketing spend by another 30%?',
    'Is inventory accuracy really the bottleneck, or is it delivery?',
    'If we could build only one product, what should it be?',
    'Why do customers who rated us 4★ stop ordering?',
    'Why are support tickets up 90% while orders grew 23%?',
    'What can we build that Blinkit cannot copy?'
  ];

  /* ======================== 11. STORE-LEVEL VIEWS ======================== */
  NC.storeStats = function (store) {
    var AOV = NC.CASE.kpi.aov.now, take = NC.kpis.takeNow;
    var cancels = store.monthlyOrders * store.cancelRate;
    var tickets = store.monthlyOrders * NC.worldTicketRate({ cancel: store.cancelRate, late15: store.lateRate, sub: store.subRate });
    var risk = 0, verified = 0;
    NC.SKUS.forEach(function (k) {
      var a = NC.availability(store, k);
      if (a.score < 62 && a.qty > 0) risk++;
      if (a.score >= 82) verified++;
    });
    var exposure = cancels * AOV * take + tickets * 0.3 * NC.CASE.support.ticketCost
      + store.monthlyOrders * (1 - store.cancelRate) * store.subRate * 42;
    return { cancels: cancels, tickets: tickets, exposure: exposure, riskSkus: risk, verifiedSkus: verified,
      reliability: store.reliability, band: NC.bandOf(store.reliability) };
  };

  NC.rankStores = function (metric) {
    var arr = NC.STORES.slice();
    if (metric === 'exposure') arr.sort(function (a, b) { return NC.storeStats(b).exposure - NC.storeStats(a).exposure; });
    else arr.sort(function (a, b) { return a.reliability - b.reliability; });
    return arr;
  };

  /* ======================== 12. MUTABLE WORLD STATE ====================== */
  /* The Ops console edits a live copy, so the promise engine, leak map,
     scenario model and copilot all move together when a store is fixed.   */
  NC.reliabilityOf = function (s) { return NC.clamp(Math.round(100 + NC.storeScoreAdj(s)), 12, 97); };

  /* Capture the as-shipped store fields ONCE, at load. Re-capturing later would
     record already-mutated values as "pristine" — which silently made repeat
     calls to initWorld() compound their effects instead of restoring state. */
  NC.capturePristine = function () {
    if (NC.PRISTINE && NC.PRISTINE.length) { return NC.PRISTINE; }
    NC.PRISTINE = NC.STORES.map(function (s) {
      return { id: s.id, syncHours: s.syncHours, syncPerDay: s.syncPerDay, cancelRate: s.cancelRate,
        lateRate: s.lateRate, subRate: s.subRate, acceptRate: s.acceptRate };
    });
    return NC.PRISTINE;
  };

  NC.resetWorld = function () {
    if (!NC.PRISTINE) NC.capturePristine();
    NC.PRISTINE.forEach(function (b) {
      var s = NC.storeById(b.id); if (!s) return;
      s.syncHours = b.syncHours; s.syncPerDay = b.syncPerDay;
      s.cancelRate = b.cancelRate; s.lateRate = b.lateRate; s.subRate = b.subRate; s.acceptRate = b.acceptRate;
      s.reliability = NC.reliabilityOf(s);
      s.touched = false;
    });
    NC.VERIFIED = {};
    NC.STORES.forEach(function (s) { s._syncedCount = 0; });
    NC.STATE = { interventions: [], recovered: 0, startedAt: null };
    return NC.STATE;
  };
  /* initWorld = the one entry point for "start from the case pack as shipped".
     It re-captures the pristine store fields and restores them, so repeated
     calls are idempotent — the demo rewinds with this, and the tests assert
     that rebuilding twice produces identical state. */
  NC.initWorld = function () { return NC.resetWorld(); };

  NC.logIntervention = function (storeId, actionId, label, gain) {
    NC.STATE = NC.STATE || { interventions: [], recovered: 0 };
    NC.STATE.interventions.push({ storeId: storeId, actionId: actionId, label: label, gain: gain, n: NC.STATE.interventions.length + 1 });
    NC.STATE.recovered += gain;
  };
  NC.coverageFromWorld = function () {
    var total = 0, fixed = 0;
    NC.STORES.forEach(function (s) { total += s.orderWeight; if (s.touched) fixed += s.orderWeight; });
    return Math.min(1, fixed / total);
  };

  /* initialise the live world as soon as the engine loads */
  (function () { NC.capturePristine(); NC.resetWorld(); })();

})(typeof window !== 'undefined' ? window : globalThis);
