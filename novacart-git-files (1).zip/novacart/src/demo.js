/* ============================================================================
   demo.js — the scripted 3-minute walkthrough (backup demo).

   Same engine and same views as index.html; this file only decides which state
   to show and in what order. Every scene is a pure function of the engine:
   apply(i) rebuilds the world from scratch and replays scenes 0..i, so it is
   deterministic and order-independent (asserted in tests/smoke_demo.js).

   Nothing here runs in index.html — the interactive app loads data/engine/ui
   only. This driver is inlined into demo.html by tools/build.py.
   ========================================================================== */
(function (global) {
  'use strict';
  var NC = global.NC;
  if (!NC) { return; }

  var VIDEO_MINUTES = 3;
  var STORE = 'ST07';            // Vidya Book Depot — worst store in the pilot cohort
  var CITY = 'Nizamabad';
  var VERIFY = ['SKU23', 'SKU21', 'SKU24', 'SKU22'];   // the stationery basket the demo uses

  /* Actions a scene performs on the world. Kept separate from the caption so a
     scene is data, not code with side effects hidden inside it. */
  function setApp(o) {
    var A = NC.APP;
    A.tab = o.tab || A.tab;
    if (o.city) { A.city = o.city; }
    if (o.storeId) { A.storeId = o.storeId; }
    if (o.step) { A.step = o.step; }
    A.cart = o.cart ? o.cart.slice() : (o.keepCart ? A.cart : []);
  }
  function verifyShelf() { VERIFY.forEach(function (id) { NC.storeSync(STORE, id, 'in'); }); }

  var SCENES = [
    {
      tab: 'diagnosis', title: '1 · The problem', secs: 18,
      caption: 'Six months of growth, and the customers who paid for it are leaving.',
      say: 'Orders up 23%. Repeat purchase rate down from 41% to 27%. Every extra order cost ₹103 in promotions and brought back ₹59. That is a 0.57× return, and it is why the growth is not compounding.'
    },
    {
      tab: 'customer', city: CITY, storeId: STORE, step: 1, title: '2 · Where the order comes from', secs: 16,
      caption: 'A real partner store — the worst in the pilot cohort, chosen on purpose.',
      say: 'Catalogue last updated 48 hours ago, reliability score 38, cancellation rate 26.4%. The customer sees a store card; what they cannot see is how old the shelf information is.'
    },
    {
      tab: 'customer', step: 2, keepCart: false, title: '3 · The basket', secs: 16,
      caption: 'Every line on this shelf is unverified — and the app now says so.',
      say: 'Today the app would show these as available. NOVA SURE scores each line against catalogue age, this store\u2019s failure history on these specific items, and its cancellation rate. Nothing here is promisable.'
    },
    {
      tab: 'customer', step: 3, title: '4 · The promise, before', secs: 20,
      caption: 'Same basket, same store: not one line can be promised, and the promise itself is dishonest.',
      say: 'The old engine promises 56 minutes and misses by more than 15 minutes 18% of the time. NOVA SURE re-plans the basket — three lines re-routed to a nearby store, one substituted — and says 60 minutes, because it would rather be honest than fast.'
    },
    {
      tab: 'store', title: '5 · The store\u2019s side', secs: 18,
      caption: 'The fix costs the shopkeeper four taps, twice a day. No counts, no scanning, no integration.',
      say: 'Three buttons per item: plenty, a few, or out. We never ask a shopkeeper for an inventory number, because 39% already say catalogue upkeep costs too much effort.'
    },
    {
      tab: 'store', act: verifyShelf, title: '6 · Four taps later', secs: 18,
      caption: 'Catalogue goes live. Reliability 38 → 86. Cancellation rate 26.4% → 17.3%.',
      say: 'Verification is a fact with a timestamp, not a prediction. That is what makes it cheap, and it is why it compounds: every verified item makes the promise better for the next customer too.'
    },
    {
      tab: 'customer', step: 3, title: '7 · The promise, after', secs: 20,
      caption: 'All four lines promisable. 54 minutes promised — four minutes faster than before — and a 1.1% late risk.',
      say: 'Same basket. Same store. The promise is now shorter than the unverified version and an order of magnitude more reliable: the chance of arriving badly late fell from 18% to 1.1%. Customers do not churn on speed; they churn on promises that break.'
    },
    {
      tab: 'ops', act: function () { NC.autoHeal(20); }, title: '8 · The operator\u2019s console', secs: 22,
      caption: 'The leak is arithmetic with an owner against each line, and every intervention is one tap.',
      say: 'This is a modelled estimate, and the app labels it as one: disclosed order rates times stated unit costs. Halve the assumed costs and it is still ₹8.05 lakh a month. The top twenty interventions move it from ₹9.89L to ₹8.76L — ₹1.69 lakh a month, in one shift.'
    },
    {
      tab: 'decision', title: '9 · The decision', secs: 24,
      caption: 'Continue as we are: −₹67.74L. Do nothing: −₹10.10L. NOVA SURE: +₹10.33L. The gap is ₹78.07L.',
      say: 'This is the number to argue with: the gap between the plan being run and the plan that could be run. Plan B pays back in month 10 at today\u2019s rollout, month 5 once operations use the console — and with the console used, the gap widens to ₹104.77 lakh.'
    },
    {
      tab: 'copilot', title: '10 · The argument, settled', secs: 18,
      caption: 'A deterministic copilot: no model call, no invented figure, method and confidence printed with every answer.',
      say: 'Asked whether NOVA CART is getting better or just bigger, it answers with the four numbers that settle it — and it says which base each figure uses. Ask something it cannot compute and it says so.'
    },
    {
      tab: 'decision', title: '11 · The ask', secs: 20,
      caption: '₹25 lakh over six months, gated at every phase, break-even at about 42% of order volume on the verified stack.',
      say: 'Phase gates are adoption gates, not feature gates: if stores do not verify, we stop. Breakeven needs verified stores carrying about 42% of order volume, and the sensitivity grid shows coverage raising contribution at every level of marketing spend. That is the whole proposal.'
    }
  ];

  /* Rebuild the world deterministically, replay scenes 0..i, return the HTML. */
  function apply(i) {
    i = Math.max(0, Math.min(SCENES.length - 1, i));
    NC.initWorld();
    NC.resetCache();
    NC.APP.toast = null;
    NC.APP.sensitivity = null;
    NC.APP.cart = [];
    NC.APP.step = 1;
    NC.APP.storeId = 'ST01';
    NC.APP.city = 'Nizamabad';
    NC.APP.tab = 'diagnosis';
    /* Walk the app scene by scene, rendering each one, exactly as a user
       clicking through would. Rendering matters: the views themselves seed the
       suggested basket and cache the plan/promise, so replaying state without
       rendering would not reproduce the journey. */
    var body = '';
    for (var k = 0; k <= i; k++) {
      var s = SCENES[k];
      setApp(s);
      if (s.act) { s.act(); }
      try {
        body = NC.views[NC.APP.tab]();
      } catch (e) {
        body = '<div class="card"><h2>Scene failed to render</h2><pre>' + String(e && e.message) + '</pre></div>';
      }
    }
    var cur = SCENES[i];
    return {
      index: i, total: SCENES.length, title: cur.title, caption: cur.caption, say: cur.say,
      secs: cur.secs, tab: NC.APP.tab,
      header: NC.trustStrip(),
      html: body
    };
  }

  NC.DEMO = {
    scenes: SCENES, apply: apply, total: SCENES.length, minutes: VIDEO_MINUTES,
    store: STORE, verify: VERIFY
  };

  /* ============================ browser driver ============================
     Only runs where a DOM exists (demo.html). Keeps all DOM work out of the
     pure part above, so the scenes stay testable in Node. */
  if (!global.document) { return; }

  global.document.addEventListener('DOMContentLoaded', function () {
    var stage = global.document.getElementById('dstage');
    var head = global.document.getElementById('dhead');
    var cap = global.document.getElementById('dcap');
    var foot = global.document.getElementById('dfoot');
    if (!stage) { return; }

    var i = 0, playing = false, timer = null;

    function paint() {
      var s = NC.DEMO.apply(i);
      stage.innerHTML = s.header + s.html;
      head.innerHTML = '<span class="dtitle">NOVA SURE — ' + NC.DEMO.minutes + '-minute walkthrough</span>' +
        '<span class="dchips">' + NC.DEMO.scenes.map(function (sc, n) {
          return '<button class="dchip' + (n === i ? ' on' : '') + '" data-jump="' + n + '">' + (n + 1) + '</button>';
        }).join('') + '</span>';
      cap.innerHTML = '<div class="dt">' + s.title + '</div><div class="dc">' + s.caption + '</div>' +
        '<div class="ds">“' + s.say + '”</div>';
      foot.innerHTML = '<button class="dbtn" data-go="-1">◀ prev</button>' +
        '<button class="dbtn play" data-play="1">' + (playing ? '❚❚ pause' : '▶ play') + '</button>' +
        '<button class="dbtn" data-go="1">next ▶</button>' +
        '<button class="dbtn" data-restart="1">↺ restart</button>' +
        '<span class="dprog"><i style="width:' + ((i + 1) / NC.DEMO.total * 100).toFixed(1) + '%"></i></span>' +
        '<span class="dhint">space = play/pause · ← → = step · ' + s.secs + 's per scene</span>' +
        '<a class="dbtn link" href="index.html">open the interactive app →</a>';
      global.scrollTo && global.scrollTo(0, 0);
    }
    function go(d) { i = Math.max(0, Math.min(NC.DEMO.total - 1, i + d)); paint(); }
    function tick() {
      if (!playing) { return; }
      if (i >= NC.DEMO.total - 1) { playing = false; paint(); return; }
      go(1);
      timer = global.setTimeout(tick, NC.DEMO.scenes[i].secs * 1000);
    }
    function play() {
      playing = !playing;
      if (timer) { global.clearTimeout(timer); timer = null; }
      paint();
      if (playing) { timer = global.setTimeout(tick, NC.DEMO.scenes[i].secs * 1000); }
    }

    global.document.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('[data-go],[data-play],[data-restart],[data-jump]') : null;
      if (!t) { return; }
      if (t.dataset.jump !== undefined) { i = +t.dataset.jump; paint(); return; }
      if (t.dataset.play !== undefined) { play(); return; }
      if (t.dataset.restart !== undefined) { i = 0; playing = false; if (timer) { global.clearTimeout(timer); timer = null; } paint(); return; }
      go(+t.dataset.go);
    });
    global.document.addEventListener('keydown', function (e) {
      if (e.key === ' ') { e.preventDefault(); play(); }
      else if (e.key === 'ArrowRight') { go(1); }
      else if (e.key === 'ArrowLeft') { go(-1); }
    });
    paint();
  });
})(typeof globalThis !== 'undefined' ? globalThis : this);
