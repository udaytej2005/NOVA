/* ============================================================================
   NOVA CART — NOVA SURE
   ui.js : the product. Every screen is a pure function returning HTML, and a
   single delegated event handler drives all state changes, so the whole app
   can be smoke-tested without a browser.
   ========================================================================== */
(function (global) {
  'use strict';
  var NC = global.NC = global.NC || {};
  var F = NC.F;

  /* ============================== state ================================= */
  NC.APP = {
    tab: 'diagnosis',
    city: 'Hyderabad',
    storeId: 'ST12',
    cart: [],
    step: 1,
    plan: null, promise: null, mc: null,
    asked: null, question: '',
    scenarios: null, sensitivity: null,
    seedDone: false
  };

  /* ============================ svg helpers ============================= */
  /* Escapes user-typed text before it can reach innerHTML. Quotes are escaped
     too, because questions are echoed into an attribute (value="..."). */
  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function lineChart(series, opts) {
    opts = opts || {};
    var W = 720, H = opts.height || 230, P = { l: 54, r: 18, t: 14, b: 28 };
    var n = series[0].values.length;
    var all = [];
    series.forEach(function (s) { all = all.concat(s.values); });
    var max = Math.max.apply(null, all), min = Math.min.apply(null, all);
    if (opts.zeroBase) min = Math.min(0, min);
    var pad = (max - min) * 0.12 || 1;
    max += pad; min = (opts.zeroBase ? Math.min(0, min) : min - pad);
    var x = function (i) { return P.l + (W - P.l - P.r) * (n === 1 ? 0.5 : i / (n - 1)); };
    var y = function (v) { return H - P.b - (H - P.t - P.b) * ((v - min) / (max - min || 1)); };
    var out = ['<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img">'];
    for (var g = 0; g <= 4; g++) {
      var v = min + (max - min) * g / 4;
      out.push('<line x1="' + P.l + '" x2="' + (W - P.r) + '" y1="' + y(v).toFixed(1) + '" y2="' + y(v).toFixed(1) + '" stroke="#eef1f6"/>');
      out.push('<text class="axis" x="' + (P.l - 8) + '" y="' + (y(v) + 3).toFixed(1) + '" text-anchor="end">' + (opts.fmt ? opts.fmt(v) : Math.round(v)) + '</text>');
    }
    if (min < 0 && max > 0) out.push('<line x1="' + P.l + '" x2="' + (W - P.r) + '" y1="' + y(0).toFixed(1) + '" y2="' + y(0).toFixed(1) + '" stroke="#c9d3e0" stroke-dasharray="3 3"/>');
    for (var i = 0; i < n; i++) {
      if (n > 13 && i % 2) continue;
      out.push('<text class="axis" x="' + x(i).toFixed(1) + '" y="' + (H - 9) + '" text-anchor="middle">' + ((opts.xlabels && opts.xlabels[i]) || (i + 1)) + '</text>');
    }
    series.forEach(function (s) {
      var d = s.values.map(function (v, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1); }).join(' ');
      if (s.fill) {
        out.push('<path d="' + d + ' L' + x(n - 1).toFixed(1) + ' ' + y(opts.zeroBase ? 0 : min).toFixed(1) + ' L' + x(0).toFixed(1) + ' ' + y(opts.zeroBase ? 0 : min).toFixed(1) + ' Z" fill="' + s.colour + '" opacity=".10"/>');
      }
      out.push('<path d="' + d + '" fill="none" stroke="' + s.colour + '" stroke-width="' + (s.width || 2.4) + '"' + (s.dashed ? ' stroke-dasharray="5 4"' : '') + ' stroke-linejoin="round"/>');
      if (s.dots !== false) s.values.forEach(function (v, i) {
        if (n > 13 && i % 2 && i !== n - 1) return;
        out.push('<circle cx="' + x(i).toFixed(1) + '" cy="' + y(v).toFixed(1) + '" r="2.6" fill="#fff" stroke="' + s.colour + '" stroke-width="1.8"/>');
      });
    });
    out.push('</svg>');
    var legend = '<div class="btnrow" style="margin-top:2px">' + series.map(function (s) {
      return '<span class="mini"><span style="display:inline-block;width:9px;height:9px;border-radius:3px;background:' + s.colour + ';margin-right:5px"></span>' + esc(s.name) + '</span>';
    }).join('') + '</div>';
    return out.join('') + legend;
  }

  function barRows(rows, opts) {
    opts = opts || {};
    var max = Math.max.apply(null, rows.map(function (r) { return r.value; })) || 1;
    return '<div style="display:grid;gap:8px">' + rows.map(function (r) {
      return '<div><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px">' +
        '<span>' + esc(r.label) + '</span><b class="num" style="color:' + (r.colour || 'var(--ink)') + '">' + r.display + '</b></div>' +
        '<div style="height:7px;border-radius:6px;background:#eef1f6;overflow:hidden"><div style="height:100%;width:' + (r.value / max * 100).toFixed(1) + '%;background:' + (r.colour || 'var(--acc)') + '"></div></div>' +
        (r.note ? '<div class="mini" style="margin-top:3px">' + esc(r.note) + '</div>' : '') + '</div>';
    }).join('') + '</div>';
  }

  function tile(label, value, delta, tone, note) {
    return '<div class="tile"><div class="lbl">' + esc(label) + '</div><div class="val num">' + value + '</div>' +
      (delta ? '<div class="delta ' + (tone || 'flat') + '">' + delta + '</div>' : '') +
      (note ? '<div class="prev num">' + note + '</div>' : '') + '</div>';
  }

  /* ============================ DIAGNOSIS =============================== */
  /* Assumptions & sensitivity. Every number in this app is either disclosed in
     the case pack, derived from it, or an assumption listed here. The labels are
     explicit so a modelled estimate is never read as a disclosed fact. */
  function assumptionsBox(where) {
    var L = NC.leakMap(), d = NC.kpis, D = NC.DEFAULTS, r = d.repeatBases;
    return '<div class="card assump">' +
      '<h3>Assumptions &amp; sensitivity — read this before quoting any number</h3>' +
      '<div class="row2">' +
      '<span class="k">Leak ' + F.lakh(L.reliabilityLeak) + '/mo</span><span class="v"><b>Modelled estimate</b>, not a disclosed figure: five lines, each an order-level rate that IS disclosed × one assumed unit cost (₹' + NC.CASE.support.ticketCost + ' per ticket, ₹42 per refund or substitution event, ₹34 of rider minutes per late order). <b>Halve the assumed costs and it is still ' + F.lakh(L.reliabilityLeakSoftHalf) + '/month.</b></span>' +
      '<span class="k">Monte Carlo</span><span class="v"><b>Modelled.</b> Seeded (20260202) and bounded: n=200,000 for the business case, n=15,000 for the in-app proof card. Reproducible to about ±0.1pp, and the same seed gives the same answer in the browser and in Node.</span>' +
      '<span class="k">ROAS</span><span class="v"><b>One definition, used everywhere:</b> extra revenue ÷ extra spend = <b>' + d.incrementalRoas.toFixed(2) + '×</b>. Most generous alternative (' + F.inr(d.netRevPerOrder) + ' average per order ÷ ' + F.inr(d.marginalPromoPerOrder) + ' marginal promo per extra order) = <b>' + d.roasBoundGenerous.toFixed(2) + '×</b>. Blended = ' + d.blendedRoas.toFixed(2) + '×. All three below 1, so the conclusion does not depend on which is used.</span>' +
      '<span class="k">Repeat buyers</span><span class="v">The case pack does not state the base the repeat rate is measured on, so all three are reported: registered × rate <b>' + F.num(r[0].now - r[0].prior) + '</b>, orders × rate <b>' + F.num(r[2].now - r[2].prior) + '</b>, MAU × rate <b>' + F.num(r[1].now - r[1].prior) + '</b>. <b>Every base falls</b>, so the direction does not depend on the denominator.</span>' +
      '<span class="k">Calibration</span><span class="v">Two aggregate parameters (monthly retention ' + D.monthlyRetention.toFixed(4) + ', established-customer lifetime ' + D.loyaltyMonths + ' months) are calibrated so the model reproduces the disclosed 38,500 orders; the disclosed funnel rates then act as marginal effects. Both are sliders in the Decision Room.</span>' +
      '<span class="k">Delta frame</span><span class="v">Every projection is a <b>change against the current month</b>. No absolute profit is claimed, because rider base pay, commissions and technology cost are not disclosed.</span>' +
      '</div>' +
      '<div class="foot">' + (where === 'decision'
        ? 'Change any of these in the sliders beside this card and every figure in the app recomputes.'
        : 'Full list with the role each assumption plays: EVIDENCE.md §11, generated from this same engine.') + '</div>' +
      '</div>';
  }

  function viewDiagnosis() {
    var K = NC.CASE.kpi, d = NC.kpis, L = NC.leakMap();
    var rows = [
      ['registered', 'up'], ['mau', ''], ['orders', ''], ['aov', ''],
      ['repeat', 'down'], ['delivery', 'down'], ['cancel', 'down'], ['tickets', 'down'], ['promo', 'down'], ['revenue', '']
    ].map(function (p) {
      var k = K[p[0]];
      var fmt = k.unit === 'inr' ? function (v) { return F.lakh(v, 2); }
        : k.unit === 'pct' ? function (v) { return F.pct(v, 0); }
        : k.unit === 'min' ? function (v) { return v + ' min'; }
        : function (v) { return F.num(v); };
      var pct = (k.now - k.prior) / k.prior;
      var good = k.direction === 'up' ? pct >= 0 : pct <= 0;
      return '<tr><td><b>' + k.label + '</b></td><td class="r num">' + fmt(k.prior) + '</td><td class="r num"><b>' + fmt(k.now) +
        '</b></td><td class="r num ' + (pct === 0 ? '' : good ? 'up-good' : 'up-bad') + '" style="font-weight:700">' + F.signed(pct, 1) + '</td></tr>';
    }).join('');

    var elasticity = ((K.repeat.prior - K.repeat.now) * 100 / ((K.cancel.now - K.cancel.prior) * 100)).toFixed(1);

    return [
      '<div class="sec-title"><h2>The diagnosis</h2><p>What the case pack says, and what it implies once the numbers are put next to each other.</p></div>',

      '<div class="card" style="border-left:4px solid var(--dang)">',
      '<h2 style="font-size:17px">NOVA CART is buying growth it cannot keep.</h2>',
      '<p class="sub" style="margin:6px 0 0">Registered users rose ' + F.signed((K.registered.now - K.registered.prior) / K.registered.prior, 0) +
      ' in six months. Repeat buyers fell by <b>' + F.num(Math.abs(d.repeatCustDelta)) + '</b>. Registration is not the number that compounds — repeat purchasing is, and the engine that produces it is misfiring.</p>',
      '</div>',

      '<div class="grid g4" style="margin-top:16px">',
      tile('Incremental ROAS (6-mo)', d.incrementalRoas.toFixed(2) + '×', '₹1 of extra marketing → ₹' + d.incrementalRoas.toFixed(2) + ' of extra revenue', 'up-bad', 'most generous reading ' + d.roasBoundGenerous.toFixed(2) + '× · blended ' + d.blendedRoas.toFixed(2) + '×'),
      tile('Promo spend per order', F.inr(d.promoPerOrder), F.pct(d.promoShareOfNetRev, 0) + ' of net revenue per order', 'up-bad', 'was ' + F.inr(d.promoPerOrderPrior) + ' / ' + F.pct(d.promoShareOfNetRevPrior, 0)),
      tile('Repeat buyers, absolute', F.num(d.repeatCustNow), '▼ ' + F.num(Math.abs(d.repeatBases[0].now - d.repeatBases[0].prior)) + ' registered base · ▼ ' + F.num(Math.abs(d.repeatBases[1].now - d.repeatBases[1].prior)) + ' MAU base', 'up-bad', 'every base falls · was ' + F.num(d.repeatCustPrior)),
      tile('Cost of unreliability', F.lakh(L.reliabilityLeak) + '/mo', F.cr(L.annualised) + ' a year', 'up-bad', F.pct(L.reliabilityLeak / K.revenue.now, 0) + ' of monthly revenue'),
      '</div>',

      '<div class="grid g23" style="margin-top:16px">',
      '<div class="card"><h2>Six months, ten metrics</h2><p class="sub">Four things went right. Six went wrong — and they went wrong together.</p>',
      '<table><thead><tr><th>Metric</th><th class="r">6 months ago</th><th class="r">Today</th><th class="r">Change</th></tr></thead><tbody>' + rows + '</tbody></table>',
      '</div>',
      '<div class="card"><h2>The correlation nobody has drawn</h2><p class="sub">Repeat purchase rate against cancellation rate, from NOVA CART\'s own history.</p>',
      '<div class="promise" style="background:linear-gradient(135deg,#12213c,#1b3a68)">',
      '<div class="cap">NOVA CART, 6 months ago</div><div class="big num">' + F.pct(K.repeat.prior, 0) + '<small> repeat</small></div>',
      '<div class="mini" style="color:#b9cdea;margin-top:6px">when cancellations were ' + F.pct(K.cancel.prior, 0) + ', delivery was ' + K.delivery.prior + ' min and tickets were ' + F.num(K.tickets.prior) + '/mo</div>',
      '<div class="row"><div>Today<b>' + F.pct(K.repeat.now, 0) + '</b></div><div>Cancellations<b>' + F.pct(K.cancel.now, 0) + '</b></div><div>Delivery<b>' + K.delivery.now + ' min</b></div><div>Tickets<b>' + F.num(K.tickets.now) + '</b></div></div>',
      '</div>',
      '<div class="rule"></div>',
      '<div class="kv"><span>Two-point elasticity from the company\'s own data</span><b>−' + elasticity + ' repeat points per +1 cancellation point</b></div>',
      '<div class="kv"><span>Blame split used in the model</span><b>' + F.pct(NC.blameSplit.reliabilityShare, 0) + ' reliability / ' + F.pct(1 - NC.blameSplit.reliabilityShare, 0) + ' promo mix</b></div>',
      '<p class="mini" style="margin-top:9px">We do not claim reliability explains all of it. The acquisition mix also shifted (58% of a rising budget goes to new users, and discount-acquired cohorts retain worse). That is exactly why the attribution is a visible slider in the Decision Room rather than a hidden assumption.</p>',
      '</div></div>',

      '<div class="sec-title"><h2>Where the money leaks</h2><p>Every line is an order-level rate disclosed in the case, or a labelled assumption.</p></div>',
      '<div class="grid g23">',
      '<div class="card"><h2>Reliability leak — ' + F.lakh(L.reliabilityLeak) + ' per month</h2>',
      '<p class="sub">' + F.cr(L.annualisedDirect) + ' a year, against a ₹25 lakh budget. Recovering 55% pays for the entire programme in ' + (NC.CASE.budget.additionalImplementation / (L.reliabilityLeak * 0.55)).toFixed(1) + ' months.</p>',
      '<div class="leakbar">' + L.lines.map(function (l, i) {
        var cols = ['#d0342c', '#e2683c', '#e2932b', '#6b3fd4', '#1b64f2'];
        return '<div style="width:' + (l.value / L.reliabilityLeak * 100).toFixed(1) + '%;background:' + cols[i % 5] + '" title="' + esc(l.label) + '">' + (l.value / L.reliabilityLeak > 0.13 ? F.lakh(l.value) : '') + '</div>';
      }).join('') + '</div>',
      '<div class="leaklegend">' + L.lines.map(function (l, i) {
        var cols = ['#d0342c', '#e2683c', '#e2932b', '#6b3fd4', '#1b64f2'];
        return '<div class="l"><span class="sw" style="background:' + cols[i % 5] + '"></span><span><b>' + esc(l.label) + '</b><br><span class="mini">' + esc(l.detail) + ' · <i>' + esc(l.lever) + '</i></span></span><b class="num">' + F.lakh(l.value) + '</b></div>';
      }).join('') + '</div>',
      '<div class="rule"></div>',
      '<div class="kv"><span>Coupons issued and never redeemed (44%)</span><b>' + F.lakh(L.promoWaste) + '/mo</b></div>',
      '<div class="kv"><span>Lifetime revenue lost per monthly acquired cohort</span><b>' + F.lakh(L.cohortLifetimeRevenueGain) + '/mo</b></div>',
      '<div class="kv"><span>Total monthly value at stake</span><b style="color:var(--dang)">' + F.lakh(L.totalMonthlyValue) + '</b></div>',
      '<p class="mini" style="margin-top:9px">Sensitivity: halving both soft assumptions (₹42 per refund/substitution event, ₹34 per late order) still leaves a ' + F.lakh(L.reliabilityLeakSoftHalf) + '/month leak. The conclusion does not depend on them.</p>',
      '</div>',
      assumptionsBox('diagnosis'),

      '<div class="card"><h2>What customers said (n=2,000)</h2><p class="sub">Top six reasons, and what they map to internally.</p>',
      barRows([
        { label: 'Prices / fees feel higher than expected', value: 38, display: '38%', colour: '#d0342c', note: 'partly a transparency problem — see the fee-visibility note below' },
        { label: 'Delivery takes too long', value: 34, display: '34%', colour: '#e2683c', note: 'includes 13% of orders arriving >15 min after the promise' },
        { label: 'Shown available, then unavailable', value: 29, display: '29%', colour: '#e2932b', note: 'inventory record accuracy — the root cause we are attacking' },
        { label: 'Discounts are confusing', value: 24, display: '24%', colour: '#6b3fd4', note: '44% of coupons are never redeemed' },
        { label: 'Prefer buying from a nearby store', value: 21, display: '21%', colour: '#1b64f2', note: 'the local advantage, currently unused' },
        { label: 'Refund problems', value: 16, display: '16%', colour: '#5b6c81', note: '9.2-hour average resolution across 3 systems' }
      ]),
      '<div class="rule"></div>',
      '<div class="promptcard"><div class="q">The signal that decides the diagnosis</div><div class="a">' +
      F.pct(NC.CASE.churnSignal.pct / 100, 0) + ' of customers who stopped ordering had rated NOVA CART 4★ or higher. ' +
      'People who liked the product left. That is a broken-promise pattern, not a bad-product pattern — and it points at fulfilment, not at advertising.</div></div>',
      '</div></div>',

      '<div class="sec-title"><h2>Cancellations, and who owns them</h2><p>53% of cancellations begin as a stock record that was wrong.</p></div>',
      '<div class="grid g3">',
      '<div class="card"><h2>Why orders die</h2>' + barRows(NC.CASE.cancelReasons.map(function (c, i) {
        var cols = ['#d0342c', '#e2683c', '#e2932b', '#6b3fd4', '#5b6c81'];
        return { label: c.reason + ' · ' + c.owner, value: c.pct, display: c.pct + '%', colour: cols[i] };
      })) + '<p class="mini" style="margin-top:10px">Availability + store rejection = <b>53%</b>. Delay-driven = 27%. Both are promise failures, not demand failures.</p></div>',

      '<div class="card"><h2>Why partner stores are the bottleneck</h2>' + barRows(NC.CASE.partnerSurvey.map(function (p, i) {
        var cols = ['#0f9d58', '#e2932b', '#e2683c', '#6b3fd4', '#e2932b', '#d0342c'];
        return { label: p.text, value: p.pct, display: p.pct + '%', colour: cols[i] };
      })) + '<div class="quote">"Customers blame us when the app says something is available but we don\'t actually have it." — partner store, case §6</div></div>',

      '<div class="card"><h2>What we ruled out</h2>',
      '<p class="sub">Three hypotheses we tested against the evidence and rejected.</p>',
      '<ul class="list">',
      '<li><b>“Customers left because of price.”</b> <span class="cross">Rejected as the primary cause.</span> Price/fees is the top survey mention (38%), but 61% of churners rated us 4★+, competitors can always out-discount us, and our own incremental ROAS is 0.57× — we are already discounting heavily and it is not buying loyalty.</li>',
      '<li><b>“We need more users.”</b> <span class="cross">Rejected.</span> +38,000 registrations produced <i>fewer</i> repeat buyers. Volume is not the constraint; conversion to habit is.</li>',
      '<li><b>“Delivery is too slow, so deliver faster.”</b> <span class="cross">Rejected.</span> A sub-30-minute promise already exists — we miss it 13% of the time and 27% of cancellations are customers giving up on the delay. Speed is a capex race against 1,300+ dark stores; accuracy is not.</li>',
      '</ul>',
      '<div class="rule"></div>',
      '<div class="kv"><span>External validation — inventory records</span><b>65% inaccurate, 35% mean deviation</b></div>',
      '<div class="kv"><span>External validation — late delivery effect</span><b>lengthens time to next purchase</b></div>',
      '<div class="kv"><span>External validation — bad experience churn</span><b>32% leave after one failure</b></div>',
      '<p class="src" style="margin-top:9px">DeHoratius &amp; Raman (2008, Management Science) · Harter, Stich &amp; Spann (2024, quick-commerce repurchase) · PwC consumer research · Voxware delivery-loyalty study · Baymard 2025 · ONDC FY26 network data. Full citations in the written submission.</p>',
      '</div></div>'
    ].join('');
  }

  /* ============================= CUSTOMER APP ============================ */
  function suggestBasket(storeId) {
    var s = NC.storeById(storeId);
    var scored = NC.SKUS.map(function (k) { return { k: k, a: NC.availability(s, k) }; });
    var inCat = scored.filter(function (x) { return x.k.cat === s.category; });
    var others = scored.filter(function (x) { return x.k.cat !== s.category; });
    inCat.sort(function (a, b) { return b.a.score - a.a.score; });
    others.sort(function (a, b) { return a.a.score - b.a.score; });
    var pick = [];
    if (inCat[0]) pick.push(inCat[0].k.id);
    if (inCat[1]) pick.push(inCat[1].k.id);
    others.slice(0, 2).forEach(function (x) { pick.push(x.k.id); });
    return pick.slice(0, 4).map(function (id) { return { skuId: id, qty: 1 }; });
  }

  function ensureSeed() {
    var A = NC.APP;
    if (!A.seedDone) { A.cart = suggestBasket(A.storeId); A.seedDone = true; }
    return A;
  }

  function catalogue(store) {
    var s = NC.SKUS.map(function (k) { return { k: k, a: NC.availability(store, k) }; });
    var inCat = s.filter(function (x) { return x.k.cat === store.category; });
    var rest = s.filter(function (x) { return x.k.cat !== store.category; });
    inCat.sort(function (a, b) { return b.a.score - a.a.score; });
    rest.sort(function (a, b) { return b.a.score - a.a.score; });
    return inCat.concat(rest).slice(0, 12);
  }

  function bandBadge(a) {
    return '<span class="badge" style="background:' + a.band.colour + '1a;color:' + a.band.colour + '"><span class="sd" style="background:' + a.band.colour + '"></span>' +
      a.band.label + (a.qty > 0 ? ' · ' + a.score : '') + '</span>';
  }

  function viewCustomer() {
    var A = ensureSeed(), K = NC.CASE.kpi;
    var cities = NC.CASE.company.citiesList;
    var cityStores = NC.STORES.filter(function (s) { return s.city === A.city; });
    var store = NC.storeById(A.storeId) || cityStores[0];
    if (store.city !== A.city) { A.city = store.city; cityStores = NC.STORES.filter(function (s) { return s.city === A.city; }); }

    var stepbar = '<div class="stepbar">' +
      ['Pick a store', 'Build the basket', 'Review the promise', 'Prove it at scale'].map(function (t, i) {
        var n = i + 1;
        return '<div class="step ' + (A.step === n ? 'on ' : '') + (A.step > n ? 'done' : '') + '"><i>' + (A.step > n ? '✓' : n) + '</i>' + t + '</div>' +
          (n < 4 ? '<hr/>' : '');
      }).join('') + '</div>';

    /* ---------- step 1 : store ---------- */
    if (A.step === 1) {
      return stepbar +
        '<div class="card"><h2>Where are we ordering from?</h2><p class="sub">Customers choose a shop, not a warehouse. Each card below is a real partner store with its own catalogue age — the number the app has never shown them.</p>' +
        '<div class="btnrow" style="margin-bottom:14px">' + cities.map(function (c) {
          return '<button class="btn ' + (c === A.city ? 'primary' : '') + '" data-act="city" data-city="' + c + '">' + c + '</button>';
        }).join('') + '</div>' +
        '<div class="storepick">' + cityStores.map(function (s) {
          var st = NC.storeStats(s);
          var aged = s.syncHours <= 2 ? 'live' : s.syncHours + 'h ago';
          var col = s.reliability >= 80 ? 'var(--ok)' : s.reliability >= 60 ? '#7cb518' : s.reliability >= 45 ? 'var(--warn)' : 'var(--dang)';
          return '<div class="store ' + (s.id === A.storeId ? 'on' : '') + '" data-act="store" data-store="' + s.id + '">' +
            '<div class="nm">' + esc(s.name) + '</div>' +
            '<div class="mini">' + s.category + ' · ' + esc(s.area) + ' · ★ ' + s.rating + '</div>' +
            '<div class="mt"><span class="badge" style="background:' + col + '1a;color:' + col + '">reliability ' + s.reliability + '</span>' +
            '<span class="badge" style="background:#eef1f6;color:#5b6c81">catalogue ' + aged + '</span>' +
            '<span class="badge" style="background:#eef1f6;color:#5b6c81">' + F.num(s.monthlyOrders) + ' orders/mo</span></div>' +
            '<div class="mini" style="margin-top:7px">Cancels ' + F.pct(s.cancelRate) + ' · late ' + F.pct(s.lateRate) + ' · ' + st.riskSkus + ' risky SKUs</div>' +
            '</div>';
        }).join('') + '</div>' +
        '<div class="grid g3" style="margin-top:16px">' +
        tile('Trust index, this city', Math.round(cityStores.reduce(function (a, s) { return a + s.reliability; }, 0) / cityStores.length) + ' / 100', cityStores.filter(function (s) { return s.syncHours <= 2; }).length + ' of ' + cityStores.length + ' stores certified', 'flat', 'verified stock + fresh catalogue') +
        tile('Catalogue age', (cityStores.reduce(function (a, s) { return a + s.syncHours; }, 0) / cityStores.length).toFixed(1) + ' h', 'oldest ' + Math.max.apply(null, cityStores.map(function (s) { return s.syncHours; })) + ' h', 'flat', 'stock numbers are estimates, not facts') +
        tile('Orders exposed to a stock failure', F.pct(cityStores.reduce(function (a, s) { return a + s.orderWeight * s.cancelRate; }, 0) / cityStores.reduce(function (a, s) { return a + s.orderWeight; }, 0), 1), 'network-wide', 'flat', 'case §5: 11% cancellation') +
        '</div></div>';
    }

    /* ---------- step 2 : basket ---------- */
    if (A.step === 2) {
      var items = catalogue(store);
      var inCart = {}; A.cart.forEach(function (l) { inCart[l.skuId] = l.qty; });
      if (!A.cart.length) A.cart = suggestBasket(store.id);
      var total = A.cart.reduce(function (a, l) { return a + NC.skuById(l.skuId).price * l.qty; }, 0);
      return stepbar +
        '<div class="grid g32">' +
        '<div class="card"><h2>' + esc(store.name) + '</h2>' +
        '<p class="sub">' + store.category + ' · ' + esc(store.area) + ', ' + store.city + ' · catalogue updated ' + (store.syncHours <= 2 ? 'live' : store.syncHours + 'h ago') + '</p>' +
        '<div class="btnrow" style="margin-bottom:12px"><button class="btn sm" data-act="step" data-step="1">← change store</button>' +
        '<span class="mini">Every price shown is the store\'s own — NOVA SURE never changes what the shop charges.</span></div>' +
        '<div class="shelf">' + items.map(function (x) {
          var a = x.a, q = inCart[x.k.id] || 0;
          return '<div class="item ' + (q ? 'incart' : '') + '">' +
            '<div class="nm">' + esc(x.k.name) + '</div>' +
            bandBadge(a) +
            '<div class="foot"><span class="pr num">₹' + x.k.price + '</span>' +
            (q ? '<span class="qty"><button data-act="qty" data-sku="' + x.k.id + '" data-d="-1">−</button><span class="num">' + q + '</span><button data-act="qty" data-sku="' + x.k.id + '" data-d="1">+</button></span>'
              : '<button class="btn sm primary" data-act="qty" data-sku="' + x.k.id + '" data-d="1">Add</button>') +
            '</div></div>';
        }).join('') + '</div></div>' +

        '<div class="card"><h2>Basket</h2><p class="sub">' + A.cart.length + ' line' + (A.cart.length === 1 ? '' : 's') + ' · ₹' + F.num(total) + '</p>' +
        (A.cart.length ? A.cart.map(function (l) {
          var k = NC.skuById(l.skuId), a = NC.availability(store, k);
          return '<div class="cartline"><div style="flex:1"><div class="t">' + esc(k.name) + '</div>' +
            '<div class="m">' + l.qty + ' × ₹' + k.price + ' · ' + a.band.label + ' at this store · ' + a.evidence + '</div></div>' +
            '<button class="btn sm" data-act="qty" data-sku="' + k.id + '" data-d="-1">−</button></div>';
        }).join('') : '<p class="mini">Add items from the shelf.</p>') +
        '<div class="rule"></div>' +
        '<button class="btn primary" data-act="step" data-step="3" ' + (A.cart.length ? '' : 'disabled') + '>Review the promise →</button>' +
        '<p class="mini" style="margin-top:9px">Nothing is hidden at this step: the same availability scores the engine uses at order time are on the shelf card.</p>' +
        '</div></div>';
    }

    /* ---------- step 3 : the promise ---------- */
    if (A.step === 3) {
      var plan = NC.routeBasket(A.cart, A.city, { primaryStoreId: store.id });
      var prom = NC.promise(store, A.cart, { extraMin: plan.extraMin });
      A.plan = plan; A.promise = prom;
      var changed = plan.lines.filter(function (l) { return l.action !== 'sell'; });
      var removedRisk = Math.max(0, (plan.riskBefore - plan.riskAfter) / Math.max(plan.riskBefore, 0.01));
      var newCancel = Math.max(0.028, 0.11 * (1 - removedRisk * 0.75));

      var left = '<div>' +
        '<div class="card"><h2>Before checkout, the engine re-plans the basket</h2>' +
        '<p class="sub">It scores every line against the store\'s <b>real</b> history and the age of its catalogue — then fixes whatever cannot honestly be promised.</p>' +
        plan.lines.map(function (l) {
          var chg = l.action !== 'sell';
          return '<div class="planbox ' + (chg ? 'chg' : '') + '"><h4><span>' + esc(l.name) + ' × ' + l.qty + '</span>' +
            '<span class="badge" style="background:' + (chg ? '#fdf1dd' : '#e6f7ee') + ';color:' + (chg ? '#9a6414' : '#0b7a45') + '">' +
            (chg ? l.action.toUpperCase() : 'PROMISABLE') + '</span></h4>' +
            '<p><b>Availability score ' + l.score + ' → ' + l.fixedScore + '</b> · ' + esc(l.actionLabel) + '</p>' +
            '<p class="mini" style="margin-top:4px">' + esc(chg && l.fixedEvidence ? l.fixedEvidence : l.evidence) + '</p>' +
            (l.action === 'substitute' ? '<p class="mini" style="margin-top:4px">Price difference: ' + (l.substitute.priceDelta === 0 ? 'none' : (l.substitute.priceDelta > 0 ? '+' : '') + '₹' + l.substitute.priceDelta) + ' — shown before payment, never after.</p>' : '') +
            (l.action === 'reroute' ? '<p class="mini" style="margin-top:4px">Adds ~' + Math.round(l.etaDelta) + ' min of travel. We would rather arrive a few minutes later than cancel on you.</p>' : '') +
            '</div>';
        }).join('') +
        '<div class="rule"></div>' +
        '<div class="kv"><span>Basket miss risk before re-planning</span><b style="color:var(--dang)">' + F.pct(plan.riskBefore, 1) + '</b></div>' +
        '<div class="kv"><span>Miss risk after re-planning</span><b style="color:var(--ok)">' + F.pct(plan.riskAfter, 1) + '</b></div>' +
        '<div class="kv"><span>Stores involved</span><b>' + plan.stops + ' (' + esc(plan.primaryStore) + ')' + '</b></div>' +
        '<div class="kv"><span>Lines fixed before the customer ever saw them</span><b>' + changed.length + ' of ' + plan.lines.length + '</b></div>' +
        '</div>' +

        '<div class="card" style="margin-top:16px"><h2>From basket to order</h2>' +
        '<p class="sub">The customer experience: one window, and no silent substitution.</p>' +
        '<div class="promise"><div class="cap">Arrives between</div>' +
        '<div class="big num">' + (prom.smart.promise - 4) + '–' + (prom.smart.promise + 5) + '<small> min</small></div>' +
        '<div class="window">🔒 ' + plan.lines.filter(function (l) { return l.fixedScore >= 62; }).length + ' of ' + plan.lines.length + ' lines verified within the last 2 hours · any swap must be approved by you in-app</div>' +
        '<div class="row"><div>Promise kept (±5 min)<b>' + F.pct(prom.smart.kept, 0) + '</b></div>' +
        '<div>Arrives >15 min late<b>' + F.pct(prom.smart.late15, 1) + '</b></div>' +
        '<div>Chance of a cancellation<b>' + F.pct(newCancel, 1) + '</b></div></div></div>' +
        '<div class="rule"></div>' +
        '<h3>The same basket through the old engine</h3>' +
        '<table><thead><tr><th>What the customer experiences</th><th class="r">Old engine</th><th class="r">NOVA SURE</th></tr></thead><tbody>' +
        '<tr><td>Promised time</td><td class="r num">' + prom.legacy.promise + ' min</td><td class="r num"><b>' + (prom.smart.promise - 4) + '–' + (prom.smart.promise + 5) + ' min</b></td></tr>' +
        '<tr><td>Honest central estimate for this basket</td><td class="r num">' + prom.central + ' min</td><td class="r num">' + prom.central + ' min</td></tr>' +
        '<tr><td>Probability of arriving >15 min late</td><td class="r num up-bad">' + F.pct(prom.legacy.late15, 1) + '</td><td class="r num up-good"><b>' + F.pct(prom.smart.late15, 1) + '</b></td></tr>' +
        '<tr><td>Probability of landing within ±5 min</td><td class="r num">' + F.pct(prom.legacy.kept, 0) + '</td><td class="r num up-good"><b>' + F.pct(prom.smart.kept, 0) + '</b></td></tr>' +
        '<tr><td>Chance this basket ends in a cancellation</td><td class="r num up-bad">' + F.pct(Math.min(0.99, plan.riskBefore * 1.05), 0) + '</td><td class="r num up-good"><b>' + F.pct(newCancel, 1) + '</b></td></tr>' +
        '</tbody></table>' +
        '<p class="mini" style="margin-top:10px">The old promise is shorter. That is exactly the problem: it is short because it is optimistic, and we miss it ' + F.pct(prom.legacy.late15, 1) + ' of the time. A promise that is a few minutes longer and an order of magnitude more reliable is a better product.</p>' +
        '<div class="btnrow" style="margin-top:14px"><button class="btn" data-act="step" data-step="2">← edit basket</button>' +
        '<button class="btn primary" data-act="step" data-step="4">Send 1,000 of these orders →</button></div>' +
        '</div></div>';

      var right = '<div>' +
        '<div class="card"><h2>Trust receipt</h2><p class="sub">Every order leaves a record ops can act on and the customer can see.</p>' +
        '<div class="kv"><span>Primary store</span><b>' + esc(plan.primaryStore) + '</b></div>' +
        '<div class="kv"><span>Store catalogue age</span><b>' + (store.syncHours <= 2 ? 'live' : store.syncHours + ' h') + '</b></div>' +
        '<div class="kv"><span>Lines scored Verified</span><b>' + plan.lines.filter(function (l) { return l.fixedScore >= 82; }).length + ' / ' + plan.lines.length + '</b></div>' +
        '<div class="kv"><span>Average availability score</span><b>' + Math.round(plan.avgScoreBefore) + ' → ' + Math.round(plan.avgScoreAfter) + '</b></div>' +
        '<div class="kv"><span>Store cancel rate on record</span><b>' + F.pct(store.cancelRate, 1) + '</b></div>' +
        '<div class="kv"><span>Network promises broken today</span><b class="up-bad">' + F.pct(NC.CASE.kpi.cancel.now, 0) + ' cancelled · ' + F.pct(0.13, 0) + ' late</b></div>' +
        '<div class="rule"></div>' +
        '<h3>Why this store</h3>' +
        '<p class="mini">The app used to sort stores by star rating. It now sorts by <b>availability reliability for this exact basket</b>: catalogue freshness, this store\'s failure history on these specific items, and travel time. That is why ' + esc(store.name) + ' comes first.</p>' +
        '<div class="quote">"Customers blame us when the app says something is available but we don\'t actually have it." — partner store, case §6</div>' +
        '</div>' +
        '<div class="card" style="margin-top:16px"><h2>What the customer is told</h2>' +
        '<p class="mini">A 12-minute window, the store\'s name and distance, the last verification time, and a plain sentence about what happens if reality changes:</p>' +
        '<div class="quote" style="border-color:var(--acc)">"' + esc(store.name) + ' last confirmed your 4 items at 6:42 pm. If anything has run out, we will message you before the rider leaves, and you will approve any swap — or drop the line and pay less."</div>' +
        '<div class="kv"><span>Refund if we break this promise</span><b>automatic, no ticket needed</b></div>' +
        '<div class="kv"><span>Customer effort to get it</span><b>zero</b></div>' +
        '</div></div>';

      var proof = (function () {
        var p2 = A.plan, pr2 = A.promise;
        var rm = Math.max(0, (p2.riskBefore - p2.riskAfter) / Math.max(p2.riskBefore, 0.01));
        var legacyMix = NC.BASE_MIX;
        var sureMix = NC.mixWithTicket({
          cancel: Math.max(0.028, 0.11 * (1 - rm * 0.75)),
          late15: Math.max(0.008, pr2.smart.late15 + 0.012),
          sub: Math.max(0.012, 0.08 * (1 - rm * 0.5))
        });
        var bcL = NC.simulate({ mix: legacyMix, n: 15000 });
        var bcS = NC.simulate({ mix: sureMix, n: 15000 });
        var N = 1000;
        var out = ['<div class="card" style="margin-top:16px;border-left:4px solid var(--acc)"><h2>1,000 customers, same basket, both engines</h2>',
          '<p class="sub">A 15,000-customer Monte Carlo over the disclosed funnel (54% first order, 31% second order in 30 days, 72% monthly repeat at 3+ orders), with conversion perturbed by the failure mix.</p>',
          '<table><thead><tr><th>Per 1,000 customers</th><th class="r">Old engine</th><th class="r">NOVA SURE</th><th class="r">Difference</th></tr></thead><tbody>'];
        [['Orders ending in a cancellation', legacyMix.cancel, sureMix.cancel],
         ['Orders arriving >15 min after the promise', legacyMix.late15, sureMix.late15],
         ['Orders with an unapproved substitution', legacyMix.sub, sureMix.sub],
         ['Orders needing a refund or support fix', legacyMix.ticket, sureMix.ticket]].forEach(function (r) {
          var a = r[1] * N, b = r[2] * N;
          out.push('<tr><td>' + r[0] + '</td><td class="r num">' + a.toFixed(0) + '</td><td class="r num"><b>' + b.toFixed(0) + '</b></td>' +
            '<td class="r num up-good" style="font-weight:700">' + (b - a).toFixed(0) + ' (' + F.signed(a === 0 ? 0 : (b - a) / a, 0) + ')</td></tr>');
        });
        out.push('<tr><td>Second order within 30 days</td><td class="r num">' + F.pct(bcL.p2, 1) + '</td><td class="r num"><b>' + F.pct(bcS.p2, 1) + '</b></td><td class="r num up-good" style="font-weight:700">' + F.signed(bcS.p2 - bcL.p2, 1) + '</td></tr>');
        out.push('<tr><td>Lifetime orders per acquired customer</td><td class="r num">' + bcL.ordersPerCustomer.toFixed(2) + '</td><td class="r num"><b>' + bcS.ordersPerCustomer.toFixed(2) + '</b></td><td class="r num up-good" style="font-weight:700">' + F.signed(bcS.ordersPerCustomer / bcL.ordersPerCustomer - 1, 1) + '</td></tr>');
        out.push('</tbody></table><div class="grid g3" style="margin-top:16px">');
        out.push(tile('Lifetime revenue per customer', F.inr(bcL.ordersPerCustomer * 486 * 0.1395) + ' → ' + F.inr(bcS.ordersPerCustomer * 486 * 0.1395), '+' + F.inr(bcS.ordersPerCustomer * 486 * 0.1395 - bcL.ordersPerCustomer * 486 * 0.1395) + ' each', 'up-good', 'with no extra acquisition spend'));
        out.push(tile('Support tickets avoided', Math.round((legacyMix.ticket - sureMix.ticket) * N) + ' per 1,000', '≈ ' + F.inr(Math.round((legacyMix.ticket - sureMix.ticket) * N * 75)) + ' saved', 'up-good', 'at ₹75 per ticket'));
        out.push(tile('Value of fixing this store alone', F.lakh(NC.storeStats(store).exposure * 0.55) + '/mo', 'this store\'s exposure × 55% recoverable', 'up-good', F.num(store.monthlyOrders) + ' orders/mo'));
        out.push('</div><p class="mini" style="margin-top:12px">The multipliers that turn a bad experience into a churn risk are explicit in the engine (' +
          Object.keys(NC.OUTCOME_MULT).map(function (k) { return k + ' ×' + NC.OUTCOME_MULT[k]; }).join(' · ') +
          ') and are normalised so that today\'s failure mix reproduces today\'s 31% second-order rate exactly. Nothing here is a magic number.</p>');
        out.push('<div class="btnrow" style="margin-top:14px"><button class="btn" data-act="step" data-step="3">← the promise</button>' +
          '<button class="btn dark" data-act="tab" data-tab="store">Now the store\'s side →</button></div></div>');
        return out.join('');
      })();

      return stepbar + '<div class="grid g23">' + left + right + '</div>' + proof;
    }

    return stepbar + '<div class="card"><p>Unknown step.</p></div>';
  }

  /* ============================== STORE APP ============================== */
  function viewStore() {
    var A = NC.APP;
    var store = NC.storeById(A.storeId) || NC.STORES[0];
    var st = NC.storeStats(store);
    var flagged = NC.SKUS.map(function (k) { return { k: k, a: NC.availability(store, k) }; })
      .filter(function (x) { return x.a.score < 82; })
      .sort(function (a, b) { return a.a.score - b.a.score; }).slice(0, 8);
    var peers = NC.STORES.filter(function (s) { return s.city === store.city; }).sort(function (a, b) { return b.reliability - a.reliability; });
    var rank = peers.findIndex(function (s) { return s.id === store.id; }) + 1;

    return '<div class="sec-title"><h2>NOVA SURE Sync — the partner app</h2>' +
      '<p>If updating the catalogue is hard, the catalogue will be wrong. So the whole job is 15 seconds, twice a day.</p>' +
      '<span class="pill">store view</span></div>' +

      '<div class="card tight" style="margin-bottom:14px"><div class="btnrow">' +
      '<span class="mini" style="margin-right:6px"><b>Switch store:</b></span>' +
      NC.STORES.slice().sort(function (a, b) { return a.reliability - b.reliability; }).map(function (s) {
        return '<button class="btn sm ' + (s.id === store.id ? 'primary' : '') + '" data-act="gotostore" data-store="' + s.id + '">' +
          esc(s.name.split(' ').slice(0, 3).join(' ')) + ' · ' + s.reliability + '</button>';
      }).join('') + '</div></div>' +

      '<div class="card" style="margin-bottom:16px"><div class="grid g4" style="align-items:center">' +
      '<div><div class="mini">Logging in as</div><div style="font-size:15px;font-weight:700">' + esc(store.name) + '</div>' +
      '<div class="mini">' + store.category + ' · ' + esc(store.area) + ', ' + store.city + ' · ★ ' + store.rating + '</div></div>' +
      tile('Reliability score', store.reliability + ' / 100', 'rank ' + rank + ' of ' + peers.length + ' in ' + store.city, store.reliability >= 70 ? 'up-good' : 'up-bad', (store.touched ? 'updated by you' : 'not yet synced today')) +
      tile('Catalogue age', store.syncHours <= 2 ? 'live' : store.syncHours + ' h', store.syncHours <= 2 ? 'certified' : 'too old to promise', store.syncHours <= 6 ? 'up-good' : 'up-bad', store.syncPerDay + ' syncs/day') +
      tile('Revenue at risk this month', F.inr(st.exposure), 'from stock failures', 'up-bad', F.num(st.cancels) + ' cancelled orders')
      + '</div></div>' +

      '<div class="grid g23">' +
      '<div class="card"><h2>Verify your shelf — 8 items need you</h2>' +
      '<p class="sub">Tap one answer per item. That is the entire job. Nothing to type, nothing to upload, no spreadsheet.</p>' +
      (flagged.length ? flagged.map(function (x) {
        var k = x.k, a = x.a;
        return '<div class="planbox"><h4><span>' + esc(k.name) + '</span>' + bandBadge(a) + '</h4>' +
          '<p class="mini">' + esc(a.evidence) + '</p>' +
          '<div class="btnrow" style="margin-top:8px">' +
          '<button class="btn sm ok" data-act="sync" data-store="' + store.id + '" data-sku="' + k.id + '" data-state="in">✔ Plenty in stock</button>' +
          '<button class="btn sm" data-act="sync" data-store="' + store.id + '" data-sku="' + k.id + '" data-state="low">⚠ Only a few left</button>' +
          '<button class="btn sm" data-act="sync" data-store="' + store.id + '" data-sku="' + k.id + '" data-state="out">✖ Out of stock</button>' +
          '</div></div>';
      }).join('') : '<p class="mini">Every item on this shelf is verified and fresh. Nothing to do — the app will tell you before the evening peak.</p>') +
      '</div>' +

      '<div>' +
      '<div class="card"><h2>What the store gets</h2>' +
      '<div class="kv"><span>Orders you can actually fulfil</span><b class="up-good">+ more, not fewer</b></div>' +
      '<div class="kv"><span>Angry customer calls</span><b class="up-good">' + F.num(Math.round(st.tickets * 0.45)) + ' fewer/mo</b></div>' +
      '<div class="kv"><span>Ranking in ' + store.city + '</span><b>' + rank + ' of ' + peers.length + ' → up as you sync</b></div>' +
      '<div class="kv"><span>Your commission</span><b>unchanged — NOVA CART never touches your price</b></div>' +
      '<div class="rule"></div>' +
      '<h3>Why partners leave (case §6)</h3>' +
      barRows(NC.CASE.partnerSurvey.slice(1).map(function (p, i) {
        var cols = ['#d0342c', '#e2932b', '#6b3fd4', '#e2683c', '#d0342c'];
        return { label: p.text, value: p.pct, display: p.pct + '%', colour: cols[i % 5] };
      })) +
      '<div class="quote">"NOVA CART gives us orders, but sometimes maintaining the online catalogue takes more effort than the additional business is worth." — case §6</div>' +
      '<p class="mini">The old answer was to ask stores to try harder. The new answer is to make the job 15 seconds and show them, in rupees, what it is worth.</p>' +
      '</div>' +
      '<div class="card" style="margin-top:16px"><h2>Peak-hour capacity</h2>' +
      '<p class="sub">Case §6: 23% of stores sometimes reject orders in busy periods. The app now asks before the rush, not during it.</p>' +
      '<div class="kv"><span>Tonight\'s forecast (this store)</span><b>' + Math.round(store.monthlyOrders / 30) + ' orders</b></div>' +
      '<div class="kv"><span>Your confirmed capacity</span><b>' + Math.round(store.monthlyOrders / 30 * store.acceptRate) + '</b></div>' +
      '<div class="kv"><span>Honest acceptance rate</span><b>' + F.pct(store.acceptRate) + '</b></div>' +
      '<div class="mini" style="margin-top:8px">NOVA SURE will only send what you can accept. Rejections are logged as a capacity signal, not as a failure — which is how they stop being a failure.</div>' +
      '</div></div></div>';
  }

  /* ============================== OPS CONSOLE ============================ */
  function viewOps() {
    var A = NC.APP;
    var L = NC.leakMap(), R = NC.worldRates();
    var queue = NC.interventionQueue();
    var applied = NC.STATE.interventions || [];
    var cov = NC.coverageFromWorld();
    var appliedKeys = {};
    applied.forEach(function (i) { appliedKeys[i.storeId + '|' + i.actionId] = 1; });
    var top = queue.filter(function (q) { return !appliedKeys[q.storeId + '|' + q.id]; }).slice(0, 12);

    return '<div class="sec-title"><h2>Trust Console</h2>' +
      '<p>One screen for the failure the customer never sees: which stores are promising things they cannot deliver, and what fixing them is worth.</p>' +
      '<span class="pill grape">ops view</span></div>' +

      '<div class="grid g5" style="margin-bottom:16px">' +
      tile('Cancellation rate', F.pct(R.cancel, 1), (R.cancel < 0.11 ? '▼ ' + F.pct(0.11 - R.cancel, 1) : '▲ ' + F.pct(R.cancel - 0.11, 1)) + ' vs baseline', R.cancel <= 0.11 ? 'up-good' : 'up-bad', 'case §5 baseline 11%') +
      tile('Late >15 min', F.pct(R.late, 1), (R.late < 0.13 ? '▼ ' + F.pct(0.13 - R.late, 1) : '▲ ' + F.pct(R.late - 0.13, 1)), R.late <= 0.13 ? 'up-good' : 'up-bad', 'baseline 13%') +
      tile('Tickets / month', F.num(Math.round(38500 * R.ticket)), Math.round(38500 * R.ticket) < 5900 ? '▼ ' + F.num(5900 - Math.round(38500 * R.ticket)) : '▲ ' + F.num(Math.round(38500 * R.ticket) - 5900), Math.round(38500 * R.ticket) <= 5900 ? 'up-good' : 'up-bad', 'baseline 5,900') +
      tile('Direct leak / month', F.lakh(L.reliabilityLeak), applied.length ? 'recovered ' + F.inr(NC.STATE.recovered) + ' so far' : 'nothing recovered yet', applied.length ? 'up-good' : 'up-bad', F.cr(L.annualisedDirect) + ' annualised') +
      tile('Order volume covered by the fix', F.pct(cov, 0), cov >= 0.55 ? 'target 55% reached' : 'target 55% by month 6', cov >= 0.55 ? 'up-good' : 'flat', applied.length + ' interventions applied')
      + '</div>' +

      '<div class="grid g23">' +
      '<div class="card"><h2>The leak, line by line</h2><p class="sub">Ranked by owner. Every figure recomputes the moment you change a store.</p>' +
      '<div class="leakbar">' + L.lines.map(function (l, i) {
        var cols = ['#d0342c', '#e2683c', '#e2932b', '#6b3fd4', '#1b64f2'];
        return '<div style="width:' + (l.value / L.reliabilityLeak * 100).toFixed(1) + '%;background:' + cols[i % 5] + '">' + (l.value / L.reliabilityLeak > 0.13 ? F.lakh(l.value) : '') + '</div>';
      }).join('') + '</div>' +
      '<table style="margin-top:12px"><thead><tr><th>Line</th><th>Owner</th><th class="r">₹ / month</th><th>Lever</th></tr></thead><tbody>' +
      L.lines.map(function (l) {
        return '<tr><td><b>' + esc(l.label) + '</b><br><span class="mini">' + esc(l.detail) + '</span></td><td>' + esc(l.owner) + '</td>' +
          '<td class="r num">' + F.lakh(l.value) + '</td><td class="mini">' + esc(l.lever) + '</td></tr>';
      }).join('') +
      '</tbody></table></div>' +

      '<div class="card"><h2>Store league table</h2><p class="sub">Sorted by reliability. This is the ranked list ops works down.</p>' +
      '<div class="scroll"><table><thead><tr><th>Store</th><th class="r">Rel.</th><th class="r">Cat. age</th><th class="r">Cancel</th><th class="r">Exposure</th><th></th></tr></thead><tbody>' +
      NC.rankStores('reliability').map(function (s) {
        var st = NC.storeStats(s);
        var col = s.reliability >= 80 ? 'var(--ok)' : s.reliability >= 60 ? '#7cb518' : s.reliability >= 45 ? 'var(--warn)' : 'var(--dang)';
        return '<tr><td><b>' + esc(s.name) + '</b><br><span class="mini">' + s.city + ' · ' + s.category + (s.touched ? ' · <b style="color:var(--ok)">fixed</b>' : '') + '</span></td>' +
          '<td class="r num" style="color:' + col + ';font-weight:700">' + s.reliability + '</td>' +
          '<td class="r num">' + (s.syncHours <= 2 ? 'live' : s.syncHours + ' h') + '</td>' +
          '<td class="r num">' + F.pct(s.cancelRate, 1) + '</td>' +
          '<td class="r num">' + F.inr(st.exposure) + '</td>' +
          '<td class="r"><button class="btn sm" data-act="gotostore" data-store="' + s.id + '">Open</button></td></tr>';
      }).join('') + '</tbody></table></div></div></div>' +

      '<div class="sec-title"><h2>Intervention queue</h2><p>Generated from the live store data — not a static list. Value = cancelled revenue + ticket cost + substitution cost avoided; lifetime value is shown separately so it is never double-counted.</p></div>' +

      '<div class="card"><div class="btnrow" style="margin-bottom:12px">' +
      '<button class="btn primary" data-act="autoheal" data-n="20">⚡ Auto-heal top 20 interventions</button>' +
      '<button class="btn" data-act="autoheal" data-n="6">Auto-heal top 6</button>' +
      '<button class="btn" data-act="reset" >Reset ops state</button>' +
      '<span class="mini">Coverage now ' + F.pct(cov, 0) + ' of order volume · ' + applied.length + ' actions applied · ' + F.inr(NC.STATE.recovered) + ' of monthly value recovered</span>' +
      '</div>' +
      '<table><thead><tr><th style="width:34px">#</th><th>Action</th><th>Store</th><th class="r">Rel.</th><th class="r">Cat. age</th><th class="r">₹/month</th><th class="r">Effort</th><th class="r"></th></tr></thead><tbody>' +
      top.map(function (q) {
        return '<tr class="qrow"><td class="num">' + q.rank + '</td>' +
          '<td>' + esc(q.label) + '<br><span class="mini">cancels −' + Math.round(q.cutCancel * 100) + '% · subs −' + Math.round(q.cutSub * 100) + '% · tickets −' + Math.round(q.cutTicket * 100) + '% · lifetime value ' + F.inr(q.vRepeat) + '/mo</span></td>' +
          '<td>' + esc(q.storeName) + '<br><span class="mini">' + q.city + '</span></td>' +
          '<td class="r num">' + q.reliability + '</td>' +
          '<td class="r num">' + (q.syncHours <= 2 ? 'live' : q.syncHours + 'h') + '</td>' +
          '<td class="r num"><b>' + F.inr(q.gain) + '</b></td>' +
          '<td class="r num">' + '●'.repeat(q.effort) + '</td>' +
          '<td class="r"><button class="btn sm" data-act="apply" data-store="' + q.storeId + '" data-action="' + q.id + '">Apply</button></td></tr>';
      }).join('') + '</tbody></table>' +
      '<p class="mini" style="margin-top:10px">Total monthly value in the queue: <b>' + F.lakh(queue.totalMonthly) + '</b> · lifetime revenue protected: <b>' + F.lakh(queue.totalLifetime) + '</b>. Actions are priced incrementally per store, so two fixes on one store never double-count the same cancelled order.</p>' +
      '</div>' +

      '<div class="grid g3" style="margin-top:16px">' +
      '<div class="card"><h2>What the fix does to the business</h2>' +
      '<p class="sub">The scenario model reads the console\'s live coverage figure.</p>' +
      (function () {
        var sc = NC.scenarios(NC.DEFAULTS, Math.min(1, 0.55 + 0.45 * Math.min(1, cov)));
        A.opsScenarios = sc;
        return '<div class="kv"><span>Coverage used in the model</span><b>' + F.pct(sc.B.coverage, 0) + '</b></div>' +
          '<div class="kv"><span>Plan B orders, month 6</span><b>' + F.num(sc.B.m6.orders) + '</b></div>' +
          '<div class="kv"><span>Plan B orders, month 12</span><b>' + F.num(sc.B.m12.orders) + '</b></div>' +
          '<div class="kv"><span>Δ contribution vs today, month 12</span><b class="up-good">' + F.lakh(sc.B.m12.contribution) + '/mo</b></div>' +
          '<div class="kv"><span>12-month cumulative</span><b>' + F.lakh(sc.B.cumulative12) + '</b></div>' +
          '<div class="kv"><span>Cash payback month</span><b>' + (sc.B.paybackMonth ? 'M' + sc.B.paybackMonth : 'beyond M12') + '</b></div>' +
          '<div class="kv"><span>Repeat rate, month 12</span><b>' + F.pct(sc.B.m12.repeatRate, 1) + ' (today 27.0%)</b></div>';
      })() +
      '</div>' +
      '<div class="card"><h2>Activity log</h2>' +
      (applied.length ? '<div class="log">' + applied.slice().reverse().map(function (i) {
        var s = NC.storeById(i.storeId);
        return '<div class="e"><span class="pill mut">#' + i.n + '</span><span><b>' + esc(s ? s.name : i.storeId) + '</b>' + esc(i.label) + '</span><span class="g num">+' + F.inr(i.gain) + '/mo</span></div>';
      }).join('') + '</div>' : '<div class="log"><div class="empty">No actions yet. Apply one intervention — every screen in this app updates from the same live state.</div></div>') +
      '<div class="rule"></div>' +
      '<div class="kv"><span>Total value recovered</span><b class="up-good">' + F.inr(NC.STATE.recovered) + ' / month</b></div>' +
      '<div class="kv"><span>Actions remaining</span><b>' + (queue.length - applied.length) + '</b></div>' +
      '</div>' +
      '<div class="card"><h2>Where the failures concentrate</h2><p class="sub">Cancellation and substitution rate by store, live.</p>' +
      barRows(NC.STORES.slice().sort(function (a, b) { return b.cancelRate - a.cancelRate; }).slice(0, 7).map(function (s) {
        return { label: s.name + ' · ' + (s.syncHours <= 2 ? 'live' : s.syncHours + 'h'), value: s.cancelRate, display: F.pct(s.cancelRate, 1) + ' cancel', colour: s.cancelRate > 0.15 ? '#d0342c' : s.cancelRate > 0.10 ? '#e2932b' : '#0f9d58' };
      })) +
      '<p class="mini" style="margin-top:10px">The pattern in the data: the stores with the oldest catalogue have the highest cancellation rates. That is the whole thesis, visible in one chart.</p>' +
      '</div></div>';
  }

  /* ============================= DECISION ROOM =========================== */
  function viewDecision() {
    var A = NC.APP;
    var P = A.params || NC.DEFAULTS;
    var cov = Math.min(1, 0.55 + 0.45 * Math.min(1, NC.coverageFromWorld()));
    var sc = NC.scenarios(P, cov);
    var sens = A.sensitivity || (A.sensitivity = NC.sensitivity(P, cov));
    var C = NC.CASE;

    function fld(key, label, min, max, step, fmt, hint) {
      var v = P[key];
      return '<label class="fld"><span class="n"><span>' + label + '</span><b>' + fmt(v) + '</b></span>' +
        '<input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + v + '" data-act="param" data-param="' + key + '"/>' +
        (hint ? '<span class="hint">' + hint + '</span>' : '') + '</label>';
    }

    function planCard(s, tone) {
      return '<div class="card" style="border-top:4px solid ' + tone + '">' +
        '<h2>' + esc(s.plan.name) + '</h2><p class="sub">' + esc(s.plan.tagline) + '</p>' +
        '<table><tbody>' +
        '<tr><td>Orders, month 6</td><td class="r num"><b>' + F.num(s.m6.orders) + '</b><br><span class="mini">' + F.signed(s.m6.orders / 38500 - 1, 1) + ' vs today</span></td></tr>' +
        '<tr><td>Orders, month 12</td><td class="r num"><b>' + F.num(s.m12.orders) + '</b><br><span class="mini">' + F.signed(s.m12.orders / 38500 - 1, 1) + '</span></td></tr>' +
        '<tr><td>Revenue, month 12</td><td class="r num">' + F.lakh(s.m12.revenue) + '<br><span class="mini">' + F.signed(s.m12.revenue / C.kpi.revenue.now - 1, 1) + '</span></td></tr>' +
        '<tr><td>Marketing, month 12</td><td class="r num">' + F.lakh(s.m12.promo) + '</td></tr>' +
        '<tr><td>Tickets, month 12</td><td class="r num">' + F.num(s.m12.tickets) + '</td></tr>' +
        '<tr><td>Repeat rate, month 12</td><td class="r num">' + F.pct(s.m12.repeatRate, 1) + '<br><span class="mini">today 27.0%</span></td></tr>' +
        '<tr><td><b>Δ monthly contribution, M12</b></td><td class="r num"><b class="' + (s.m12.contribution >= 0 ? 'up-good' : 'up-bad') + '">' + F.signed(s.m12.contribution / s.m12.revenue || 0, 0) + '</b><br><b>' + F.lakh(s.m12.contribution) + '</b></td></tr>' +
        '<tr><td>12-month cumulative Δ</td><td class="r num"><b class="' + (s.cumulative12 >= 0 ? 'up-good' : 'up-bad') + '">' + F.lakh(s.cumulative12) + '</b></td></tr>' +
        '<tr><td>Programme spend</td><td class="r num">' + F.lakh(s.programSpent) + '</td></tr>' +
        '<tr><td>Cash payback</td><td class="r num">' + (s.paybackMonth ? '<b class="up-good">month ' + s.paybackMonth + '</b>' : '<span class="mini">n/a</span>') + '</td></tr>' +
        '</tbody></table></div>';
    }

    var months = sc.B.rows.map(function (r) { return 'M' + r.month; });
    var orderChart = lineChart([
      { name: 'Plan A — buy growth', colour: '#e2932b', values: sc.A.rows.map(function (r) { return r.orders; }), dashed: true },
      { name: 'Plan B — NOVA SURE', colour: '#1b64f2', values: sc.B.rows.map(function (r) { return r.orders; }), width: 3 },
      { name: 'Plan C — do nothing', colour: '#9aa8ba', values: sc.C.rows.map(function (r) { return r.orders; }) }
    ], { xlabels: months, fmt: function (v) { return Math.round(v / 1000) + 'k'; } });

    var contribChart = lineChart([
      { name: 'Plan A — buy growth', colour: '#e2932b', values: sc.A.rows.map(function (r) { return r.contribution; }), dashed: true },
      { name: 'Plan B — NOVA SURE', colour: '#0f9d58', values: sc.B.rows.map(function (r) { return r.contribution; }), width: 3, fill: true },
      { name: 'Plan C — do nothing', colour: '#9aa8ba', values: sc.C.rows.map(function (r) { return r.contribution; }) }
    ], { xlabels: months, zeroBase: true, fmt: function (v) { return F.lakh(v, 0); } });

    var heat = '<table class="heat"><thead><tr><th>Rollout coverage ⬇ / marketing spend →</th>' +
      sens.spends.map(function (s) { return '<th class="h r">' + (s.toFixed(1)) + '×</th>'; }).join('') + '</tr></thead><tbody>' +
      sens.grid.map(function (row, i) {
        return '<tr><td class="h">' + (sens.lifts[i] * 100) + '%</td>' + row.map(function (c) {
          var v = c.contribution6;
          var col = v > 1500000 ? '#0f9d58' : v > 500000 ? '#5aa832' : v > 0 ? '#e2932b' : '#d0342c';
          var bg = v > 1500000 ? '#e6f7ee' : v > 500000 ? '#f0f7e3' : v > 0 ? '#fdf6e8' : '#fdeceb';
          return '<td style="background:' + bg + ';color:' + col + '">' + F.lakh(v, 0) + '</td>';
        }).join('') + '</tr>';
      }).join('') + '</tbody></table>';

    var gap = sc.B.cumulative12 - sc.A.cumulative12;
    return '<div class="sec-title"><h2>Decision Room</h2>' +
      '<p>Take the argument the management team is having and put numbers on it. Every slider is an assumption you can defend or attack.</p>' +
      '<span class="pill">12-month model</span></div>' +

      '<div class="card" style="border-left:4px solid var(--acc);margin-bottom:16px">' +
      '<h2 style="font-size:18px">The decision, in one line</h2>' +
      '<p class="sub" style="margin:6px 0 0">Continuing the last six months (Plan A) ends the year <b class="up-bad">' + F.lakh(sc.A.cumulative12) + '</b> against today. ' +
      'Doing nothing (Plan C) ends <b class="up-bad">' + F.lakh(sc.C.cumulative12) + '</b>. NOVA SURE (Plan B) ends <b class="up-good">' + F.lakh(sc.B.cumulative12) + '</b>. ' +
      'The gap between the plan we are already running and the plan we could run is <b>' + F.lakh(gap) + '</b> — that is the number to argue with. ' +
      'Payback (month ' + (sc.B.paybackMonth || '—') + ') is the second-order fact underneath it.</p>' +
      '</div>' +

      '<div class="grid g4" style="margin-bottom:16px">' +
      tile('Plan B beats Plan A by', F.lakh(sc.B.cumulative12 - sc.A.cumulative12), 'over 12 months', 'up-good', 'after paying the full ₹25L') +
      tile('Plan B run-rate, M12', F.lakh(sc.B.m12.contribution) + '/mo', 'vs Plan A ' + F.lakh(sc.A.m12.contribution) + '/mo', 'up-good', 'both measured against today') +
      tile('Plan B payback', sc.B.paybackMonth ? 'Month ' + sc.B.paybackMonth : '—', 'cumulative cash turns positive', 'up-good', 'Plan A: never') +
      tile('Cost of doing nothing', F.lakh(sc.C.cumulative12), 'over 12 months', 'up-bad', 'orders ' + F.num(sc.C.m12.orders) + ' by M12') +
      '</div>' +

      '<div class="grid g23">' +
      '<div class="card"><h2>Monthly order volume — the three plans</h2><p class="sub">Plan A and Plan B end up in the same place on volume. Only one of them pays for it twice.</p>' + orderChart + '</div>' +
      '<div class="card"><h2>Δ Monthly contribution vs today</h2><p class="sub">Failure costs, promotion spend and programme spend all included. Positive = better than standing still.</p>' + contribChart + '</div>' +
      '</div>' +

      '<div class="grid g3" style="margin-top:16px">' + planCard(sc.C, '#9aa8ba') + planCard(sc.A, '#e2932b') + planCard(sc.B, '#1b64f2') + '</div>' +

      '<div class="grid g23" style="margin-top:16px">' +
      '<div class="card"><h2>Sensitivity — 6-month cumulative Δ contribution</h2>' +
      '<p class="sub">Rows: share of order volume on the fixed stack. Columns: marketing spend vs today. Green = better off than today. The diagonal question management is really asking: <i>can we buy our way out?</i> No — every column gets worse as spend rises.</p>' +
      heat +
      '<p class="mini" style="margin-top:10px">Read it two ways. (1) At any spend level, coverage moves contribution up. (2) At any coverage level, extra spend moves contribution down — because the marginal rupee of marketing returns ₹0.57. That is the entire argument between the marketing head and the finance head, settled with their own numbers.</p>' +
      '</div>' +
      '<div class="card"><h2>Assumptions you can change</h2><p class="sub">Nothing is hidden. Move any of these and every number in the app recomputes.</p>' +
      fld('reliabilityShare', 'Share of the repeat-rate collapse attributed to reliability', 0.2, 1, 0.05, function (v) { return F.pct(v, 0); }, 'The rest is attributed to the acquisition mix (discount-led cohorts retain worse). We split it 60/40 by default.') +
      fld('retentionResponse', 'Monthly churn reduction at full rollout', 0, 0.5, 0.05, function (v) { return F.pct(v, 0); }, 'How much of the returning base\'s churn the reliability fix removes.') +
      fld('firstOrderConv', 'First-order conversion of new users', 0.4, 0.7, 0.01, function (v) { return F.pct(v, 0); }, 'Case §4: 54%.') +
      fld('secondOrder30d', 'Second order within 30 days', 0.2, 0.5, 0.01, function (v) { return F.pct(v, 0); }, 'Case §4: 31%. The single most leveraged number in the funnel.') +
      fld('loyaltyMonths', 'Months an established (3+) customer keeps ordering', 6, 30, 1, function (v) { return v + ' months'; }, 'Case §4 gives 72% monthly repeat for this tier; this parameter is calibrated so the model reproduces NOVA CART\'s observed order volume.') +
      fld('sigmaBase', 'Delivery-time variability (minutes, 1σ)', 3, 14, 0.5, function (v) { return v + ' min'; }, 'Drives the late-rate tail. Today\'s 13% late rate implies about 8 minutes.') +
      fld('promiseOffset', 'Promised time vs the honest estimate', -6, 6, 1, function (v) { return (v > 0 ? '+' : '') + v + ' min'; }, '−6 min is today\'s optimistic promise. NOVA SURE uses 0 or slightly positive.') +
      '<div class="rule"></div>' +
      '<div class="btnrow"><button class="btn" data-act="resetparams">Reset to case defaults</button></div>' +
      assumptionsBox('decision') +
      '<p class="mini" style="margin-top:10px">Calibration note: the disclosed funnel (54% → 31% → 72%) does not, read literally, reproduce the disclosed 38,500 orders from 3,420 new buyers a month. Rather than hide that, we calibrate two aggregate parameters — monthly retention of the active base and the lifetime of an established customer — so the model reproduces the observed P&amp;L, and keep the funnel rates for their marginal effect. Both are sliders above.</p>' +
      '</div></div>' +

      '<div class="card" style="margin-top:16px"><h2>What has to be true for Plan B to work</h2>' +
      '<div class="grid g3">' +
      '<div><h3>1. Coverage</h3><p class="mini">55% of order volume on the fixed stack by month 6, 100% by month 12. This is an operations commitment, not a technology one — it is 2 taps a day in 620 stores.</p></div>' +
      '<div><h3>2. Attribution</h3><p class="mini">At least 40% of the repeat-rate collapse is reliability-driven. Below that, the same ₹25L spent on retention marketing alone would be competitive — the sensitivity grid shows the break-even row.</p></div>' +
      '<div><h3>3. Promise honesty</h3><p class="mini">Management accepts a longer, keepable window instead of a shorter, missed one. If the ETA promise stays optimistic, the late-rate gains halve.</p></div>' +
      '</div></div>';
  }

  /* =============================== COPILOT =============================== */
  function viewCopilot() {
    var A = NC.APP;
    var ans = A.asked;
    return '<div class="sec-title"><h2>NOVA SURE Copilot</h2>' +
      '<p>A reasoning partner, not an oracle: every answer is computed from the case data and the live model, and shows its arithmetic.</p>' +
      '<span class="pill grape">prompt · validate</span></div>' +

      '<div class="grid g32">' +
      '<div class="card"><h2>Ask the evidence</h2><p class="sub">These are the questions the management team is actually arguing about.</p>' +
      '<div class="chips">' + NC.copilotPrompts.map(function (q, i) {
        return '<button class="chip" data-act="ask-chip" data-i="' + i + '">' + esc(q) + '</button>';
      }).join('') + '</div>' +
      '<div class="rule"></div>' +
      '<form data-act="ask-form"><div class="btnrow">' +
      '<input type="text" id="qbox" placeholder="Or type your own question…" value="' + esc(A.question) + '" style="flex:1;min-width:180px" data-act="qbox"/>' +
      '<button class="btn primary" data-act="ask">Ask</button></div></form>' +
      '<div class="rule"></div>' +
      '<h3>How this copilot works</h3>' +
      '<p class="mini">It is a deterministic reasoning layer, not a chat wrapper: each question triggers a computation over the case pack and the live model (leak map, funnel simulation, scenario engine) and returns the headline, the evidence, the method and a confidence level. That is deliberate — in a business case, a wrong number costs more than a slow answer, so nothing is generated that cannot be recomputed.</p>' +
      '<div class="rule"></div>' +
      '<h3>The prompt journey</h3>' +
      '<p class="mini">The four prompts that changed the product direction, kept in the written submission:</p>' +
      '<div class="promptcard"><div class="q">1. “Compute the incremental ROAS and the promo-per-order for both periods.”</div>' +
      '<div class="a">→ ₹1 of extra marketing returned ₹0.57 of revenue, and promotions now consume 65% of net revenue per order. The marketing plan died here.</div></div>' +
      '<div class="promptcard"><div class="q">2. “If 61% of churners rated us 4★+, what kind of failure produces that?”</div>' +
      '<div class="a">→ Not a product failure — a broken-promise failure. It moved priority from features to fulfilment.</div></div>' +
      '<div class="promptcard"><div class="q">3. “Which single metric explains the most cancellations, tickets and delays?”</div>' +
      '<div class="a">→ Catalogue age. It is upstream of 53% of cancellations and it is the one thing a store can fix in 15 seconds.</div></div>' +
      '<div class="promptcard"><div class="q">4. “Challenge the conclusion: why isn\'t this just brand awareness or pricing?”</div>' +
      '<div class="a">→ Because we are already the cheapest-promise option, already discounting heavily, and still losing 4★ customers. Price was demoted from cause to symptom.</div></div>' +
      '</div>' +

      '<div class="card"><h2>Conversation</h2>' +
      '<div class="chat" id="chat">' +
      (ans ? '<div class="msg user">' + esc(ans.q) + '</div>' +
        '<div class="msg bot"><h4>' + esc(ans.headline) + '</h4>' +
        (ans.matched === false ? '<ul>' + ans.evidence.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul>' : '<ul>' + ans.evidence.map(function (e) { return '<li>' + e + '</li>'; }).join('') + '</ul>') +
        '<span class="tag">Method</span><div>' + esc(ans.method) + '</div>' +
        '<div class="rec">→ ' + esc(ans.recommendation) + '</div>' +
        '<span class="tag">Confidence</span><div>' + esc(ans.confidence) + '</div>' +
        '</div>'
        : '<div class="msg bot"><h4>Ask something.</h4><p class="sub" style="margin:0">Pick a question on the left, or type your own. Answers are computed live — if you fix a store in the Ops Console, the answers here change.</p></div>') +
      '</div></div></div>';
  }

  /* ============================== RENDER ================================= */
  function trustStrip() {
    var R = NC.worldRates(), L = NC.leakMap();
    return '<div class="topmeta">' +
      '<div>Cancellations<b>' + F.pct(R.cancel, 1) + '</b></div>' +
      '<div>Late &gt;15 min<b>' + F.pct(R.late, 1) + '</b></div>' +
      '<div>Tickets / mo<b>' + F.num(Math.round(38500 * R.ticket)) + '</b></div>' +
      '<div>Leak / mo<b>' + F.lakh(L.reliabilityLeak) + '</b></div>' +
      '<div>Fixed volume<b>' + F.pct(NC.coverageFromWorld(), 0) + '</b></div>' +
      '</div>';
  }

  NC.trustStrip = trustStrip;

  NC.views = { diagnosis: viewDiagnosis, customer: viewCustomer, store: viewStore, ops: viewOps, decision: viewDecision, copilot: viewCopilot };

  NC.renderApp = function () {
    var A = NC.APP;
    var tabs = [['diagnosis', 'Diagnosis'], ['customer', 'Customer app'], ['store', 'Store app'], ['ops', 'Ops Trust Console'], ['decision', 'Decision Room'], ['copilot', 'Copilot']];
    return '<div class="wrap">' +
      '<div class="sec-title" style="margin-top:0"></div>' +
      NC.views[A.tab]() +
      (A.toast ? '<div class="toast">' + esc(A.toast) + '</div>' : '') +
      '</div>';
  };

  /* ============================ DISPATCHER =============================== */
  NC.dispatch = function (act, el, ev) {
    var A = NC.APP, d = el.dataset || {};
    switch (act) {
      case 'tab': A.tab = d.tab; break;
      case 'city': A.city = d.city; A.storeId = (NC.STORES.filter(function (s) { return s.city === d.city; })[0] || {}).id; A.step = 1; A.seedDone = false; break;
      case 'store': A.storeId = d.store; A.seedDone = false; A.step = 2; break;
      case 'gotostore': A.storeId = d.store; A.city = NC.storeById(d.store).city; A.tab = 'store'; break;
      case 'step': A.step = +d.step; if (+d.step === 2) A.seedDone = false; break;
      case 'qty': {
        var id = d.sku, delta = +d.d;
        var line = A.cart.filter(function (l) { return l.skuId === id; })[0];
        if (line) { line.qty += delta; if (line.qty <= 0) A.cart = A.cart.filter(function (l) { return l.skuId !== id; }); }
        else if (delta > 0) A.cart.push({ skuId: id, qty: 1 });
        break;
      }
      case 'sync': {
        var s = NC.storeSync(d.store, d.sku, d.state);
        A.toast = (s ? s.name : 'Store') + ': verified. Reliability ' + (s ? s.reliability : '') + ', exposure now ' + F.inr(NC.storeStats(s).exposure) + '/mo.';
        break;
      }
      case 'apply': {
        var q = NC.interventionQueue().filter(function (x) { return x.storeId === d.store && x.id === d.action; })[0];
        var r = NC.applyIntervention(d.store, d.action);
        if (r) { NC.logIntervention(d.store, d.action, q ? q.label : d.action, q ? q.gain : 0); A.toast = 'Applied: ' + (q ? q.label.slice(0, 46) + '…' : d.action) + ' → ' + F.inr(q ? q.gain : 0) + '/mo of value.'; }
        break;
      }
      case 'autoheal': {
        var res = NC.autoHeal(+d.n || 20);
        A.toast = res.applied + ' interventions applied · ' + F.inr(res.gain) + '/month of value unlocked · coverage ' + F.pct(NC.coverageFromWorld(), 0);
        break;
      }
      case 'reset': NC.resetWorld(); A.toast = 'Ops state reset to the baseline network.'; A.sensitivity = null; break;
      case 'resetparams': A.params = Object.assign({}, NC.DEFAULTS); A.sensitivity = null; A.toast = 'Assumptions reset to the case defaults.'; break;
      case 'ask': {
        var box = (typeof document !== 'undefined') ? document.getElementById('qbox') : null;
        A.question = box ? box.value : (A.question || '');
        A.asked = NC.copilot(A.question);
        break;
      }
      case 'ask-chip': A.question = NC.copilotPrompts[+d.i]; A.asked = NC.copilot(A.question); break;
      default: break;
    }
    return A.tab;
  };

  /* live parameter sliders */
  NC.setParam = function (key, value) {
    NC.APP.params = Object.assign({}, NC.APP.params || NC.DEFAULTS);
    NC.APP.params[key] = parseFloat(value);
    NC.APP.sensitivity = null;
  };

})(typeof window !== 'undefined' ? window : globalThis);
