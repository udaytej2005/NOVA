/* ============================================================================
   NOVA CART — NOVA SURE
   data.js  :  case-pack facts, derived KPIs, and calibrated operating data.

   WHAT IS DISCLOSED vs WHAT IS ASSUMED
     disclosed : every figure in NC.CASE.kpi / .survey / .ops / .partners /
                 .support / .funnel / .economics — copied from the case pack.
     derived   : NC.DERIVED — computed here, never typed (GMV, take rate,
                 marginal revenue and promo spend per incremental order, the
                 three possible bases for the repeat-buyer count).
     calibrated: store-level rates and the 400-order sample are generated so
                 that ORDER-WEIGHTED NETWORK AVERAGES reproduce the disclosed
                 11% cancellations / 13% late / 8% substitutions / 15.3% tickets
                 exactly (verified by tests/run_engine.js section K).
     assumed   : NC.ASSUMPTIONS — soft costs with no disclosed value
                 (₹75 ticket, ₹42 refund/substitution event, ₹34 late-order
                 rider minutes, 72% of tickets failure-driven, 58% of promo
                 spend acquisition-tagged). All surfaced in EVIDENCE.md §11
                 and adjustable in the Decision Room.

   DETERMINISM: one seeded RNG (mulberry32, seed 20260202) generates the store
   sample and every Monte Carlo draw, so every run and every reviewer sees the
   same numbers. Nothing here reads the clock, the network or the environment.
   ========================================================================== */
(function (global) {
  'use strict';
  var NC = global.NC = global.NC || {};

  /* ---------- deterministic RNG so every demo run is identical ---------- */
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  NC.mulberry32 = mulberry32;          // exposed so the engine can derive a
  NC.rng = mulberry32(20260202);       // per-computation stream (see simulate)

  /* =========================== 1. CASE FACTS ============================== */
  NC.CASE = {
    company: {
      name: 'NOVA CART', stores: 620, cities: 3,
      citiesList: ['Nizamabad', 'Warangal', 'Hyderabad'],
      categories: ['Grocery', 'Pharmacy', 'Bakery', 'Stationery']
    },
    kpi: {
      registered: { label: 'Registered users',     prior: 82000,   now: 120000,   unit: 'int',  direction: 'up'   },
      mau:        { label: 'Monthly active users', prior: 39000,   now: 46000,    unit: 'int',  direction: 'up',  inverse: false },
      orders:     { label: 'Monthly orders',       prior: 31200,   now: 38500,    unit: 'int',  direction: 'up'   },
      aov:        { label: 'Average order value',  prior: 452,     now: 486,      unit: 'inr',  direction: 'up'   },
      repeat:     { label: 'Repeat purchase rate', prior: 0.41,    now: 0.27,     unit: 'pct',  direction: 'up'   },
      delivery:   { label: 'Avg delivery time',    prior: 29,      now: 37,       unit: 'min',  direction: 'down' },
      cancel:     { label: 'Order cancellation',   prior: 0.06,    now: 0.11,     unit: 'pct',  direction: 'down' },
      tickets:    { label: 'Support tickets / mo', prior: 3100,    now: 5900,     unit: 'int',  direction: 'down' },
      promo:      { label: 'Promotional spend',    prior: 950000,  now: 1700000,  unit: 'inr',  direction: 'down' },
      revenue:    { label: 'Revenue / month',      prior: 2180000, now: 2610000,  unit: 'inr',  direction: 'up'   }
    },
    survey: [
      { pct: 38, reason: 'Prices / fees feel higher than expected' },
      { pct: 34, reason: 'Delivery takes too long' },
      { pct: 29, reason: 'Products shown available become unavailable after ordering' },
      { pct: 24, reason: 'Discounts are confusing' },
      { pct: 21, reason: 'Prefer purchasing directly from nearby stores' },
      { pct: 18, reason: 'Difficult to discover relevant local products' },
      { pct: 16, reason: 'Experienced refund problems' },
      { pct: 14, reason: 'App experience feels cluttered' },
      { pct: 11, reason: 'Delivery tracking is inaccurate' }
    ],
    /* the single most important sentence in the case pack */
    churnSignal: { pct: 61, text: 'of customers who stopped ordering had previously rated NOVA CART 4 stars or higher' },
    orderOutcomes: { cancel: 0.11, late15: 0.13, substituted: 0.08, refundOrSupport: 0.06 },
    cancelReasons: [
      { reason: 'Product unavailable',        pct: 35, owner: 'Inventory' },
      { reason: 'Customer cancelled (delay)', pct: 27, owner: 'Delivery'  },
      { reason: 'Store rejected the order',   pct: 18, owner: 'Partner'   },
      { reason: 'Delivery partner unavailable', pct: 12, owner: 'Logistics' },
      { reason: 'Other',                      pct: 8,  owner: '—'         }
    ],
    ticketMix: [
      { reason: 'Refund status',            pct: 29 },
      { reason: 'Delayed delivery',         pct: 24 },
      { reason: 'Missing / unavailable item', pct: 19 },
      { reason: 'Coupon problems',          pct: 13 },
      { reason: 'Incorrect orders',         pct: 9  },
      { reason: 'Other',                    pct: 6  }
    ],
    funnel: { firstOrderOfNewUsers: 0.54, secondOrderIn30d: 0.31, thirdOrderRepeat: 0.72 },
    behaviour: {
      couponWaste: 0.44, idleSearchUnavailable: 0.19,
      multiCategoryRepeatLift: true,
      discountCohortRetentionLower: true
    },
    partnerSurvey: [
      { pct: 46, text: 'believe NOVA CART brings valuable additional customers' },
      { pct: 39, text: 'say maintaining online inventory takes too much effort' },
      { pct: 31, text: 'believe promotions reduce their margins' },
      { pct: 28, text: 'struggle to predict what will sell online' },
      { pct: 23, text: 'occasionally reject orders during busy periods' },
      { pct: 18, text: 'are considering leaving the platform within a year' }
    ],
    marketing: { buyShare: 0.58, newRegPerMonth: 6333, proposedIncrease: 0.30 },
    support: { avgResolutionHours: 9.2, ticketCost: 75 },
    budget: { additionalImplementation: 2500000 }
  };

  /* ====================== 2. DERIVED KPIs  (the leak) ==================== */
  function pctChange(a, b) { return a === 0 ? 0 : (b - a) / a; }

  NC.kpis = (function () {
    var k = NC.CASE.kpi;
    var gmvNow = k.orders.now * k.aov.now;              // Rs
    var gmvPrior = k.orders.prior * k.aov.prior;
    var takeNow = k.revenue.now / gmvNow;                // implied platform take rate
    var takePrior = k.revenue.prior / gmvPrior;
    var dPromo = k.promo.now - k.promo.prior;
    var dRev = k.revenue.now - k.revenue.prior;
    var dReg = k.registered.now - k.registered.prior;
    var repeatCustNow = k.registered.now * k.repeat.now;
    var repeatCustPrior = k.registered.prior * k.repeat.prior;
    var newBuyers = NC.CASE.marketing.newRegPerMonth * NC.CASE.funnel.firstOrderOfNewUsers;
    var dOrders = k.orders.now - k.orders.prior;
    /* Marginal vs average: these two must never be mixed in one sentence.
       The extra spend bought dOrders extra orders, so the honest per-order
       comparison is marginal-to-marginal (₹103 spent -> ₹59 earned, 0.57x).
       ₹68 is today's AVERAGE revenue per order — a different quantity. */
    var marginalRevPerOrder = dRev / dOrders;
    var marginalPromoPerOrder = dPromo / dOrders;

    return {
      gmvNow: gmvNow, gmvPrior: gmvPrior,
      takeNow: takeNow, takePrior: takePrior,
      /* --- the three lines finance already has, but has never put together --- */
      promoPerOrder: k.promo.now / k.orders.now,
      netRevPerOrder: k.revenue.now / k.orders.now,
      promoPerOrderPrior: k.promo.prior / k.orders.prior,
      netRevPerOrderPrior: k.revenue.prior / k.orders.prior,
      promoShareOfNetRev: k.promo.now / k.revenue.now,
      promoShareOfNetRevPrior: k.promo.prior / k.revenue.prior,
      /* ROAS, defined once and used everywhere:
           incrementalRoas   = delta revenue / delta promo spend  <- the one we quote
           roasBoundGenerous = today's AVERAGE revenue per order / marginal promo
                               per extra order. The most GENEROUS reading
                               available: it credits every extra order with the
                               average order's revenue, when the platform really
                               earned the marginal amount. Reported as a bound so
                               the conclusion can be checked from both directions.
           blendedRoas       = total revenue / total spend.
         All three are below 1.0, so the finding survives any of the three. */
      /* ROAS, defined once and used everywhere:
           incrementalRoas   = delta revenue / delta promo spend  <- the one we quote
           roasBoundGenerous = today's AVERAGE revenue per order / marginal promo
                               per extra order. The most GENEROUS reading
                               available: it credits every extra order with the
                               average order's revenue, when the platform really
                               earned the marginal amount. Reported as a bound so
                               the conclusion can be checked from both directions.
           blendedRoas       = total revenue / total spend.
         All three are below 1.0, so the finding survives any of the three. */
      incrementalRoas: dRev / dPromo,
      roasBoundGenerous: (k.revenue.now / k.orders.now) / (dPromo / dOrders),
      roasBoundGenerous: (k.revenue.now / k.orders.now) / (dPromo / dOrders),
      marginalRevPerOrder: marginalRevPerOrder,
      marginalPromoPerOrder: marginalPromoPerOrder,
      blendedRoas: k.revenue.now / k.promo.now,
      promoShareOfGmv: k.promo.now / gmvNow,
      promoShareOfGmvPrior: k.promo.prior / gmvPrior,
      /* --- acquisition cost ladder --- */
      cacPerRegistration: dPromo / dReg,
      newBuyersPerMonth: newBuyers,
      cacPerNewBuyer: (k.promo.now * NC.CASE.marketing.buyShare) / newBuyers,
      /* --- the headline nobody has computed ---
         DEFINITION (stated so it can be checked): repeat buyers = registered
         users x repeat purchase rate. The case pack does not state the base the
         repeat rate is measured on, so the count is given on all three plausible
         bases below. Registered is the most conservative; every base falls. */
      repeatBasis: 'registered users x repeat purchase rate',
      repeatCustNow: repeatCustNow,
      repeatCustPrior: repeatCustPrior,
      repeatCustDelta: repeatCustNow - repeatCustPrior,
      repeatBases: [
        { basis: 'Registered users x repeat rate',
          prior: k.registered.prior * k.repeat.prior, now: k.registered.now * k.repeat.now },
        { basis: 'Monthly active users x repeat rate',
          prior: k.mau.prior * k.repeat.prior, now: k.mau.now * k.repeat.now },
        { basis: 'Orders x repeat rate',
          prior: k.orders.prior * k.repeat.prior, now: k.orders.now * k.repeat.now }
      ],
      registeredDelta: dReg,
      /* --- reliability --- */
      ordersLostToCancel: k.orders.now * k.cancel.now,
      cancelDelta: (k.cancel.now - k.cancel.prior) * k.orders.now,
      ticketRate: k.tickets.now / k.orders.now,
      ticketRatePrior: k.tickets.prior / k.orders.prior,
      supportCost: k.tickets.now * NC.CASE.support.ticketCost,
      supportCostPrior: k.tickets.prior * NC.CASE.support.ticketCost,
      supportShareOfRevenue: (k.tickets.now * NC.CASE.support.ticketCost) / k.revenue.now,
      supportShareOfRevenuePrior: (k.tickets.prior * NC.CASE.support.ticketCost) / k.revenue.prior,
      ordersPerMau: k.orders.now / k.mau.now,
      ordersPerMauPrior: k.orders.prior / k.mau.prior,
      mauOfRegistered: k.mau.now / k.registered.now,
      mauOfRegisteredPrior: k.mau.prior / k.registered.prior,
      pct: pctChange
    };
  })();

  /* No single cause explains the retention collapse: we split it into a
     reliability component and a promotion-mix component, both adjustable. */
  NC.blameSplit = {
    reliabilityShare: 0.60, // 60% of the 41%->27% repeat-rate fall attributed to service failures
    note: 'NOVA CART\'s own history is the experiment. The 41% repeat rate happened when delivery was 29 min, cancellation 6% and tickets 3,100/mo. The mix of acquisition also shifted toward discount-led cohorts (58% of a rising budget), which we attribute the remaining 40% to.'
  };

  /* ============================ 3. SKU CATALOGUE ========================= */
  NC.SKUS = [
    { id: 'SKU01', name: 'Aashirvaad Atta 5kg',        cat: 'Grocery',   price: 285, mrp: 310 },
    { id: 'SKU02', name: 'Fortune Sunflower Oil 1L',   cat: 'Grocery',   price: 148, mrp: 160 },
    { id: 'SKU03', name: 'Tata Salt 1kg',              cat: 'Grocery',   price: 28,  mrp: 30 },
    { id: 'SKU04', name: 'Amul Taaza Milk 500ml',      cat: 'Grocery',   price: 27,  mrp: 28 },
    { id: 'SKU05', name: 'Sona Masoori Rice 5kg',      cat: 'Grocery',   price: 420, mrp: 470 },
    { id: 'SKU06', name: 'Toor Dal 1kg',               cat: 'Grocery',   price: 165, mrp: 185 },
    { id: 'SKU07', name: 'Britannia Good Day 250g',    cat: 'Grocery',   price: 60,  mrp: 65 },
    { id: 'SKU08', name: 'Tata Tea Gold 250g',         cat: 'Grocery',   price: 145, mrp: 155 },
    { id: 'SKU09', name: 'Maggi Noodles 4-pack',       cat: 'Grocery',   price: 96,  mrp: 104 },
    { id: 'SKU10', name: 'Lizol Floor Cleaner 975ml',  cat: 'Grocery',   price: 199, mrp: 225 },
    { id: 'SKU11', name: 'Dettol Handwash 750ml',      cat: 'Grocery',   price: 165, mrp: 199 },
    { id: 'SKU12', name: 'Paracetamol 500mg (15)',     cat: 'Pharmacy',  price: 32,  mrp: 35  },
    { id: 'SKU13', name: 'Azithral 500 (5 tabs)',      cat: 'Pharmacy',  price: 118, mrp: 132 },
    { id: 'SKU14', name: 'Dolo 650 (15 tabs)',         cat: 'Pharmacy',  price: 34,  mrp: 38  },
    { id: 'SKU15', name: 'Digital BP Monitor (Omron)', cat: 'Pharmacy',  price: 2340, mrp: 2900 },
    { id: 'SKU16', name: 'Nasal Spray (Otrivin 10ml)', cat: 'Pharmacy',  price: 122, mrp: 140 },
    { id: 'SKU17', name: 'Milk Bread 400g',            cat: 'Bakery',    price: 45,  mrp: 48  },
    { id: 'SKU18', name: 'Butter Croissant (2 pc)',    cat: 'Bakery',    price: 90,  mrp: 100 },
    { id: 'SKU19', name: 'Black Forest Pastry 500g',   cat: 'Bakery',    price: 420, mrp: 480 },
    { id: 'SKU20', name: 'Brownie Box (6 pc)',         cat: 'Bakery',    price: 260, mrp: 300 },
    { id: 'SKU21', name: 'Classmate Notebook 200pg',   cat: 'Stationery', price: 55, mrp: 60 },
    { id: 'SKU22', name: 'Apsara Pencil Pack (10)',    cat: 'Stationery', price: 40, mrp: 45 },
    { id: 'SKU23', name: 'A4 Paper Ream 500 sheets',   cat: 'Stationery', price: 310, mrp: 350 },
    { id: 'SKU24', name: 'Fevicol 100g',               cat: 'Stationery', price: 48,  mrp: 52 }
  ];
  NC.skuById = function (id) { var s = NC.SKUS.filter(function (x) { return x.id === id; }); return s[0]; };

  /* ========================== 4. PARTNER STORES ========================== */
  /* Raw operating character observed from the order database: how often the
     store's staff refresh the online catalogue, how long they take to pack,
     travel time, and their outcome rates. Then normalised to the case rates. */
  var RAW_STORES = [
    ['ST01', 'Sri Balaji Kirana & General', 'Nizamabad', 'Kanteshwar',    'Grocery',    0.5,  4, 0.062, 0.088, 0.051, 0.965, 17, 15, 4.6, 3,  1.0, 4200],
    ['ST02', 'Ganesh Medicals',             'Nizamabad', 'Vinayak Nagar', 'Pharmacy',   3.0,  2, 0.075, 0.095, 0.062, 0.940, 19, 14, 4.4, 3,  1.0, 2600],
    ['ST03', 'Nizam Bakers',                'Nizamabad', 'Khaleelwadi',   'Bakery',     1.5,  3, 0.058, 0.120, 0.070, 0.955, 15, 18, 4.7, 3,  1.0, 2100],
    ['ST04', 'Sai Stationers',              'Nizamabad', 'Gandhi Chowk',  'Stationery', 36.0, 1, 0.196, 0.215, 0.148, 0.760, 27, 22, 4.0, 3,  1.0,  900],
    ['ST05', 'Warangal Grocery Mart',       'Warangal',  'Hanamkonda',    'Grocery',    2.0,  3, 0.070, 0.101, 0.058, 0.950, 19, 19, 4.5, 3,  1.0, 3400],
    ['ST06', 'Sri Chaitanya Medicals',      'Warangal',  'Subedari',      'Pharmacy',   8.0,  2, 0.132, 0.148, 0.101, 0.880, 19, 17, 4.3, 3,  1.0, 2300],
    ['ST07', 'Vidya Book Depot',            'Warangal',  'Warangal City', 'Stationery', 48.0, 1, 0.211, 0.238, 0.166, 0.740, 29, 25, 3.9, 3,  1.0, 1100],
    ['ST08', 'Amma Home Foods',             'Warangal',  'Kazipet',       'Bakery',     5.0,  2, 0.096, 0.112, 0.086, 0.915, 21, 21, 4.5, 3,  1.0, 1500],
    ['ST09', 'Green Basket Veggies',        'Warangal',  'Nakkalagutta',  'Grocery',    12.0, 1, 0.160, 0.180, 0.100, 0.850, 25, 25, 4.2, 3,  1.0, 1400],
    ['ST10', 'Koti Super Bazaar',           'Hyderabad', 'Koti',          'Grocery',    1.0,  4, 0.058, 0.076, 0.055, 0.972, 14, 13, 4.6, 3,  1.0, 5200],
    ['ST11', 'Asha Pharmacy',               'Hyderabad', 'Begumpet',      'Pharmacy',   4.0,  2, 0.091, 0.118, 0.072, 0.920, 19, 16, 4.4, 3,  1.0, 2800],
    ['ST12', 'FreshFields Organics',        'Hyderabad', 'Jubilee Hills', 'Grocery',    2.0,  3, 0.065, 0.090, 0.060, 0.960, 16, 17, 4.8, 3,  1.0, 2400],
    ['ST13', "Baker's Street",              'Hyderabad', 'Madhapur',      'Bakery',     1.0,  4, 0.049, 0.081, 0.052, 0.968, 14, 15, 4.7, 3,  1.0, 3200],
    ['ST14', 'Prime Stationery Hub',        'Hyderabad', 'Dilsukhnagar',  'Stationery', 26.0, 1, 0.178, 0.196, 0.138, 0.800, 27, 27, 4.1, 3,  1.0, 1600]
  ];

  /* normalise a vector so its order-weighted mean equals target */
  function normalise(items, key, target, floor, cap) {
    for (var it = 0; it < 4; it++) {
      var wsum = 0, acc = 0;
      items.forEach(function (s) { wsum += s.orderWeight; acc += s.orderWeight * s[key]; });
      var mean = acc / wsum;
      if (mean <= 0) break;
      var f = target / mean;
      items.forEach(function (s) {
        s[key] = Math.min(cap, Math.max(floor, s[key] * f));
      });
    }
  }

  NC.STORES = (function () {
    var totalVol = RAW_STORES.reduce(function (a, r) { return a + r[16]; }, 0);
    var stores = RAW_STORES.map(function (r) {
      return {
        id: r[0], name: r[1], city: r[2], area: r[3], category: r[4],
        syncHours: r[5], syncPerDay: r[6],
        cancelRate: r[7], lateRate: r[8], subRate: r[9], acceptRate: r[10],
        prepMin: r[11], travelMin: r[12], rating: r[13],
        monthlyOrders: r[16], orderWeight: r[16] / totalVol,
        manualInventory: true,
        skuCount: 40 + Math.round(r[16] / 100),
        staff: r[4] === 'Grocery' ? 4 : 2,
        reliability: 0
      };
    });
    /* calibrated so the order-weighted network rates equal the disclosed rates */
    normalise(stores, 'cancelRate', 0.11, 0.030, 0.300);
    normalise(stores, 'lateRate', 0.13, 0.030, 0.340);
    normalise(stores, 'subRate', 0.08, 0.010, 0.230);
    /* NOTE: cancelRate / lateRate / subRate are all expressed as a share of ALL
       orders placed, matching the framing of case §5 (11% / 13% / 8%).    */
    stores.forEach(function (s) {
      s.syncBand = s.syncHours <= 2 ? 'live' : s.syncHours <= 6 ? 'daily' : s.syncHours <= 12 ? 'twice-daily' : s.syncHours <= 26 ? 'slow' : 'dormant';
    });
    return stores;
  })();
  NC.storeById = function (id) { return NC.STORES.filter(function (s) { return s.id === id; })[0]; };

  /* ------- per-store shelf: seeded so the demo is reproducible ------------ */
  (function buildShelves() {
    /* Own seeded stream: the generated shelves must be identical every time the
       world is rebuilt (page reload, demo rewind, test run), and must not depend
       on how much randomness any earlier code happened to consume. */
    var rnd = NC.mulberry32(20260202);
    NC.SHELF = {};
    NC.STORES.forEach(function (s) {
      NC.SHELF[s.id] = {};
      NC.SKUS.forEach(function (k) {
        var fits = (k.cat === s.category) || (s.category === 'Grocery' && k.cat !== 'Pharmacy');
        var pBase = fits ? 0.92 : 0.34;
        var has = rnd() < pBase;
        var qty = has ? Math.round(1 + rnd() * (k.cat === s.category ? 14 : 6)) : 0;
        if (has && s.syncHours > 24 && k.cat !== s.category) qty = Math.round(qty * 0.4);
        NC.SHELF[s.id][k.id] = qty;
      });
    });
  })();

  /* ---------- static operating snapshot (what our own order DB shows) ---- */
  NC.NOW = {
    monthlyOrders: 38500, orderingCustomers: 26400, newBuyers: 3420,
    tickets: 5900, batch: 'FY26 · Feb 2026 cohort snapshot'
  };

  /* ====================== 5. ORDER-LEVEL SAMPLE ========================== */
  /* 400 sampled orders, drawn from per-store rates, so the sample reproduces
     the case-level failure rates within sampling error. Used to prove the
     engine is reading something that behaves like real order data.        */
  NC.ORDER_LOG = (function () {
    var rnd = NC.rng, log = [];
    var K = NC.CASE.kpi;
    /* largest-remainder allocation: integer counts that sum to an exact total */
    function largestRemainder(total, weights) {
      var sum = weights.reduce(function (a, w) { return a + w; }, 0);
      var exact = weights.map(function (w) { return total * w / sum; });
      var base = exact.map(Math.floor);
      var used = base.reduce(function (a, b) { return a + b; }, 0);
      var order = exact.map(function (e, i) { return { i: i, rem: e - Math.floor(e) }; })
        .sort(function (a, b) { return b.rem - a.rem; });
      for (var k = 0; used < total; k++, used++) base[order[k % order.length].i]++;
      return base;
    }

    /* 1. orders per store, in proportion to volume */
    var nStore = largestRemainder(400, NC.STORES.map(function (s) { return s.orderWeight; }));
    /* 2. cancellations, late, substituted, tickets — each exact at the network level */
    var nCanc = largestRemainder(Math.round(400 * K.cancel.now), NC.STORES.map(function (s, i) { return nStore[i] * s.cancelRate; }));
    var deliv = nStore.map(function (n, i) { return n - nCanc[i]; });
    var nLate = largestRemainder(Math.round(400 * 0.13), NC.STORES.map(function (s, i) { return deliv[i] * s.lateRate; }));
    var nSub = largestRemainder(Math.round(400 * 0.08), NC.STORES.map(function (s, i) { return deliv[i] * s.subRate; }));
    var nTick = largestRemainder(Math.round(400 * (K.tickets.now / K.orders.now)), nStore.map(function (n, i) { return n * (K.tickets.now / K.orders.now); }));

    NC.STORES.forEach(function (s, i) {
      var n = nStore[i];
      for (var j = 0; j < n; j++) {
        var cancelled = j < nCanc[i];
        var late = !cancelled && j >= nCanc[i] && j < nCanc[i] + nLate[i];
        var sub = !cancelled && j >= nCanc[i] + nLate[i] && j < nCanc[i] + nLate[i] + nSub[i];
        /* tickets are drawn independently of outcome, as in the real support log */
        var ticket = Math.round((j + 1) * nTick[i] / n) > Math.round(j * nTick[i] / n);
        var inCat = NC.SKUS.filter(function (k) { return k.cat === s.category; });
        var other = NC.SKUS.filter(function (k) { return k.cat !== s.category; });
        var sku = (rnd() < 0.7 && inCat.length) ? inCat[Math.floor(rnd() * inCat.length)] : other[Math.floor(rnd() * other.length)];
        var items = 2 + Math.floor(rnd() * 7);
        var lateMin = cancelled ? 0 : (late ? 16 + Math.round(rnd() * 34) : Math.round(rnd() * 14));
        log.push({
          id: 'ORD' + (100000 + log.length * 7),
          storeId: s.id, city: s.city, skuId: sku.id,
          value: Math.round((items * sku.price * 0.55 + 120) / 5) * 5,
          status: cancelled ? 'CANCELLED' : 'DELIVERED',
          lateMin: lateMin, substituted: sub, ticket: ticket,
          refund: cancelled && rnd() < 0.72,
          promiseKept: cancelled ? false : lateMin <= 15
        });
      }
    });
    return log;
  })();

  NC.orderSampleStats = (function () {
    var n = NC.ORDER_LOG.length, o = { n: n, cancel: 0, late: 0, sub: 0, ticket: 0, promiseKept: 0, gmv: 0 };
    NC.ORDER_LOG.forEach(function (r) {
      if (r.status === 'CANCELLED') o.cancel++;
      else { if (r.lateMin > 15) o.late++; if (r.substituted) o.sub++; if (r.promiseKept) o.promiseKept++; }
      if (r.ticket) o.ticket++;
      o.gmv += r.value;
    });
    o.cancelRate = o.cancel / n;
    o.lateRate = o.late / n;
    o.subRate = o.sub / n;
    o.ticketRate = o.ticket / n;
    o.promiseKeptRate = o.promiseKept / n;
    return o;
  })();

  /* ================= 6. UNMET LOCAL DEMAND (searched, never served) ====== */
  /* 19% of customers repeatedly search for products unavailable nearby
     (case §4). This is the raw material of the local-assortment moat.      */
  NC.DEMAND_GAPS = [
    { area: 'Nizamabad · Kanteshwar',   term: 'Baby diapers (size 3)',       searches: 940,  localSupply: 0.12, category: 'Grocery',   estValue: 118000 },
    { area: 'Nizamabad · Vinayak Nagar',term: 'Glucometer strips',           searches: 610,  localSupply: 0.18, category: 'Pharmacy',  estValue: 96000  },
    { area: 'Warangal · Kazipet',       term: 'Fresh paneer (200g)',         searches: 720,  localSupply: 0.22, category: 'Grocery',   estValue: 84000  },
    { area: 'Warangal · Subedari',      term: 'Ayurvedic immunity syrup',    searches: 480,  localSupply: 0.25, category: 'Pharmacy',  estValue: 71000  },
    { area: 'Warangal · Hanamkonda',    term: 'Eggless cake base',           searches: 390,  localSupply: 0.31, category: 'Bakery',    estValue: 58000  },
    { area: 'Hyderabad · Dilsukhnagar', term: 'A3 sketch book',              searches: 660,  localSupply: 0.15, category: 'Stationery',estValue: 62000  },
    { area: 'Hyderabad · Begumpet',     term: 'Diabetic protein powder',     searches: 830,  localSupply: 0.09, category: 'Pharmacy',  estValue: 145000 },
    { area: 'Hyderabad · Koti',         term: 'Cold-pressed groundnut oil',  searches: 1120, localSupply: 0.20, category: 'Grocery',   estValue: 132000 },
    { area: 'Nizamabad · Khaleelwadi',  term: 'Whole-wheat pizza base',      searches: 450,  localSupply: 0.28, category: 'Bakery',    estValue: 54000  },
    { area: 'Hyderabad · Madhapur',     term: 'Gourmet dog food',            searches: 520,  localSupply: 0.14, category: 'Grocery',   estValue: 88000  }
  ];

  /* ================= 7. REGULATORY / DIGITAL-RAIL CHECK ================== */
  NC.RAILS = {
    ondc: { sellers: '7.64 lakh+', cities: 616, txnsFy26: '21.8 crore', commission: '8–10% vs 25–30% on closed marketplaces', digiDukaan: 'ONDC DigiDukaan launched Hyderabad Mar-2026; 10,000+ kiranas onboarded', why: 'Assortment, not warehouses, is NOVA CART\'s only defensible moat — open rails let 620 partner stores participate without capex.' },
    benchmark: {
      cartAbandonExtraCosts: 48, cartAbandonSlowDelivery: 22,
      iriInaccurateRecords: 65, iriAvgDeviationPct: 35,
      etaMissLoyaltyHit: 69, leaveAfterOneBadExperience: 32, switchForReliableDelivery: 55,
      forgiveIfToldWhy: 71, repeatBenchmark: '25–40% for consumables', ltvCacHealthy: '3:1 – 5:1'
    }
  };

  /* ============ 8. ASSUMPTION PANEL (single source of truth) ============= */
  NC.DEFAULTS = {
    /* promise engine */
    promiseOffset: -2,        // minutes vs the honest central estimate
    sigmaBase: 8,             // minutes of variability today
    /* conversion / retention — all adjustable in the Decision Room */
    firstOrderConv: 0.54,
    secondOrder30d: 0.31,
    thirdOrderRepeat: 0.72,
    /* ---- calibration note -------------------------------------------------
       The disclosed funnel (31% second order in 30 days, 72% monthly repeat for
       3+ order customers) does not, taken literally, reproduce the disclosed
       volume of 38,500 orders from 3,420 new buyers a month. We therefore
       calibrate two aggregate parameters so the model reproduces the observed
       P&L, and we keep the funnel rates for their *marginal* effect only:
         monthlyRetention  = 0.9504 -> keeps the returning base flat at today's
                             inflow (a 4.96% monthly churn of the active base)
         loyaltyMonths     = 12     -> months an established customer keeps
                             ordering, which reproduces ~5.8 lifetime orders
                             per acquired customer
       Both are visible in the Decision Room and can be challenged.        */
    monthlyRetention: 0.9470,
    retentionResponse: 0.25,  // % of base churn removed at full rollout
    loyaltyMonths: 12,
    freqReturning: 1.5265,    // orders per returning customer per month, calibrated to 38,500 orders
    repeatRateNow: 0.27,
    historicRepeat: 0.41,     // NOVA CART's own repeat rate when cancellation was 6%
    reliabilityShare: 0.60,   // share of the 41%->27% fall we attribute to reliability (rest = promo mix)
    coverage: 0.55,           // share of order volume on the fixed stack (set by the Ops console)
    targetMix: { cancel: 0.06, late15: 0.035, sub: 0.04, ticket: 0.105 },
    aov: 486,
    takeRate: 0.1395
  };

})(typeof window !== 'undefined' ? window : globalThis);
