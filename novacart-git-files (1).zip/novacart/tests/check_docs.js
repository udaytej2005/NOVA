/* check_docs.js — cross-checks every number quoted in the written pack against
   what the engine actually computes. If the app and the docs ever disagree,
   this fails. Run:  node tests/check_docs.js                        */

const fs = require('fs'), path = require('path');
const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
const NC = g.NC, F = NC.F, d = NC.kpis, K = NC.CASE.kpi;
const ROOT = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');

let fails = 0, checks = 0;

/* canonical figures, all computed here — never typed into this file by hand */
NC.initWorld();
const L = NC.leakMap();
const sc55 = NC.scenarios(NC.DEFAULTS, 0.55);
const scFull = NC.scenarios(NC.DEFAULTS, 1.0);
const bc = NC.businessCase();
const C = {
  leak: F.lakh(L.reliabilityLeak),
  leakHalf: F.lakh(L.reliabilityLeakSoftHalf),
  cohort: F.lakh(L.cohortLifetimeRevenueGain),
  total: F.lakh(L.totalMonthlyValue),
  roas: d.incrementalRoas.toFixed(2) + '×',
  roasBound: d.roasBoundGenerous.toFixed(2) + '×',
  blended: d.blendedRoas.toFixed(2) + '×',
  promoMarginal: F.inr(d.marginalPromoPerOrder),
  revMarginal: F.inr(d.marginalRevPerOrder),
  revAverage: F.inr(d.netRevPerOrder),
  planA: F.lakh(sc55.A.cumulative12),
  planB: F.lakh(sc55.B.cumulative12),
  planC: F.lakh(sc55.C.cumulative12),
  gap: F.lakh(sc55.B.cumulative12 - sc55.A.cumulative12),
  fullB: F.lakh(scFull.B.cumulative12),
  repeatNow: F.num(d.repeatCustNow),
  repeatBases: d.repeatBases.map(b => F.num(b.now - b.prior)),
  ltvLegacy: F.inr(bc.ltvLegacy),
  ltvSure: F.inr(bc.ltvSure),
  ltvCac: bc.ltvCacLegacy.toFixed(2) + ':1',
  ltvCacSure: bc.ltvCacSure.toFixed(2) + ':1',
  payback: 'month ' + sc55.B.paybackMonth,
  paybackFull: 'month ' + scFull.B.paybackMonth,
  repeatM12: F.pct(sc55.B.m12.repeatRate, 1),
  promoWaste: F.lakh(L.promoWaste),
  m12orders: F.num(sc55.B.m12.orders),
  m12rev: F.lakh(sc55.B.m12.revenue)
};

/* Normalisation: documents use a typographic minus, non-breaking spaces and
   the rupee prefix in different positions. Compare the figure, not the glyph. */
function norm(t) {
  return String(t)
    .replace(/\u2212/g, '-')            // minus sign -> hyphen
    .replace(/\u00a0|\u202f/g, ' ')     // narrow/non-breaking spaces
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"');
}
/* Money figures are compared by magnitude; the direction is asserted separately
   (demo_path.js asserts Plan A < 0 and Plan B > 0 from the engine itself). */
function magnitude(t) { return norm(t).replace(/^\u20b9/, '').replace(/\u20b9-/g, '-').replace(/^-/, ''); }

function must(file, strings, label) {
  const raw = norm(read(file));
  strings.forEach(t => {
    checks++;
    const needle = /\d/.test(t) && /\u20b9|L$|\u00d7/.test(t) ? magnitude(t) : norm(t);
    if (raw.indexOf(needle) < 0) { console.log(`  FAIL ${file}: missing ${label} "${t}" (looked for "${needle}")`); fails++; }
  });
}
function mustNot(file, strings, label) {
  const raw = norm(read(file));
  strings.forEach(t => {
    checks++;
    if (raw.indexOf(norm(t)) >= 0) { console.log(`  FAIL ${file}: stale ${label} still present: "${t}"`); fails++; }
  });
}

const DOCS = ['SUBMISSION.md', 'README.md', 'docs/01-problem-diagnosis.md', 'docs/02-prompt-journey.md',
  'docs/03-solution-explanation.md', 'docs/04-demo-script.md', 'docs/05-business-impact.md',
  'docs/06-source-code.md'];
const EVID = ['EVIDENCE.md'];

console.log('canonical figures (computed now, from the engine)');
Object.keys(C).forEach(k => console.log('  ' + k.padEnd(15) + C[k]));

console.log('\ndocs — the diagnosis figures must match the engine');
must('docs/01-problem-diagnosis.md', [C.leak, C.roas, C.roasBound, C.blended, C.promoMarginal, C.revMarginal, C.revAverage], 'figure');
must('docs/01-problem-diagnosis.md', [C.repeatBases[0], C.repeatBases[2], C.repeatBases[1]], 'repeat base');
must('SUBMISSION.md', [C.leak, C.roas, C.roasBound, C.repeatBases[0], C.repeatBases[1], C.repeatBases[2]], 'figure');
must('docs/02-prompt-journey.md', [C.roas, C.revMarginal], 'figure');
must('docs/04-demo-script.md', [C.leak, C.roas], 'figure');

console.log('\ndocs — the plan figures must match the engine at the stated coverage');
must('docs/05-business-impact.md', [C.planA, C.planB, C.gap, C.fullB, C.payback, C.repeatM12], 'plan figure');
must('SUBMISSION.md', [C.planA, C.planB, C.planC, C.gap, C.fullB], 'plan figure');
must('docs/04-demo-script.md', [C.planA, C.planB, C.gap], 'plan figure');

console.log('\nEVIDENCE.md — generated, so it must contain the same canonical figures');
must('EVIDENCE.md', [C.leak, C.leakHalf, C.roas, C.planA, C.planB, C.gap, C.ltvLegacy, C.ltvSure, 'M' + sc55.B.paybackMonth], 'figure');
must('EVIDENCE.md', [C.repeatBases[0], C.repeatBases[1], C.repeatBases[2]], 'repeat base');

console.log('\ndocs — the demo script must quote the leak sensitivity and both coverage cases');
must('docs/04-demo-script.md', [F.lakh(scFull.B.cumulative12)], 'full-rollout figure');
must('docs/01-problem-diagnosis.md', [C.leakHalf], 'sensitivity figure');

console.log('\nstale figures — these must be gone everywhere');
const STALE = ['₹1.25L', '₹11.28L', '₹388', '₹419', '1.45:1', '5.73', '6.17', '167 KB', '2,482', '104 checks',
  'returned ₹68 of platform revenue', 'incremental ROAS of 0.57×. 0.66', '₹9.84L', '16.8%'];
DOCS.concat(EVID).forEach(f => mustNot(f, STALE, 'figure'));

console.log('\ncounts — test tallies quoted in the docs must match reality');
const smokeOut = require('child_process').execSync('node ' + JSON.stringify(path.join(__dirname, 'smoke_ui.js')), { encoding: 'utf8' });
const smokeChecks = (smokeOut.match(/(\d+) checks, (\d+) failures \(final\)/) || [])[1];
const demoOut = require('child_process').execSync('node ' + JSON.stringify(path.join(__dirname, 'demo_path.js')), { encoding: 'utf8' });
const demoChecks = (demoOut.match(/(\d+) demo-path checks/) || [])[1];
console.log('  smoke_ui.js reports ' + smokeChecks + ' checks · demo_path.js reports ' + demoChecks + ' checks');
checks++;
if (read('README.md').indexOf(smokeChecks + ' ') < 0) { console.log('  FAIL README.md does not quote the real check count (' + smokeChecks + ')'); fails++; }
checks++;
if (read('docs/06-source-code.md').indexOf(smokeChecks + ' ') < 0) { console.log('  FAIL docs/06 does not quote the real check count (' + smokeChecks + ')'); fails++; }

/* the app itself must show the same headline figures the docs quote */
console.log('\napp — the rendered views must contain the same figures');
require('../src/ui.js');
NC.APP.tab = 'diagnosis';
const html = NC.views.diagnosis();
must('docs/05-business-impact.md', [C.gap], 'impact figure');
checks++;
if (html.indexOf(C.roas) < 0) { console.log('  FAIL diagnosis view does not show incremental ROAS ' + C.roas); fails++; }
checks++;
if (html.indexOf(C.roasBound) < 0) { console.log('  FAIL diagnosis view does not show the generous ROAS bound ' + C.roasBound); fails++; }
checks++;
if (html.indexOf(C.leak) < 0) { console.log('  FAIL diagnosis view does not show the leak ' + C.leak); fails++; }
checks++;
if (html.indexOf('Assumptions &amp; sensitivity') < 0 && html.indexOf('Assumptions & sensitivity') < 0) {
  console.log('  FAIL diagnosis view is missing the assumptions box'); fails++;
}

console.log('\n' + checks + ' doc-consistency checks, ' + fails + ' failures');
process.exit(fails ? 1 : 0);
