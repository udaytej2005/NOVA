/* demo_path.js — walks the exact sequence in docs/04-demo-script.md, in order,
   through the same engine and views the browser runs, and asserts what the
   script says the screen shows at each beat. If the app and the script ever
   drift apart, this fails. Run:  node tests/demo_path.js   */

const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
require('../src/ui.js');
const NC = g.NC, F = NC.F;

let fails = 0, checks = 0;
function ok(label, cond, detail) {
  checks++;
  console.log((cond ? '  OK   ' : '  FAIL ') + label + (detail ? '  →  ' + detail : ''));
  if (!cond) fails++;
}
function near(label, actual, expected, tol) {
  const d = Math.abs(actual - expected);
  ok(label, d <= tol, actual.toFixed(2) + ' (script says ' + expected + ' ± ' + tol + ')');
}
function beat(n, title) { console.log('\n--- BEAT ' + n + ' · ' + title); }

NC.initWorld();
NC.resetCache();
NC.APP.tab = 'customer'; NC.APP.city = 'Nizamabad'; NC.APP.storeId = 'ST07'; NC.APP.step = 2; NC.APP.cart = [];

const STORE = NC.storeById('ST07');
console.log('Demo store: ' + STORE.name + ' · ' + STORE.city + ' · reliability ' + STORE.reliability + ' · catalogue ' + STORE.syncHours + 'h');

beat(1, 'Diagnosis');
NC.APP.tab = 'diagnosis';
let html = NC.views.diagnosis();
ok('leak line quoted', html.indexOf(F.lakh(NC.leakMap().reliabilityLeak) + ' per month') >= 0, F.lakh(NC.leakMap().reliabilityLeak));
ok('assumptions box present', html.indexOf('Assumptions &amp; sensitivity') >= 0 || html.indexOf('Assumptions & sensitivity') >= 0);
ok('ROAS shown with its bound', html.indexOf('most generous reading') >= 0);

beat(2, 'Customer app — the basket at an unverified store');
NC.APP.step = 2;
html = NC.views.customer();
ok('shelf shows unverified items', /Unverified|Not sellable/.test(html));
NC.APP.step = 3;
html = NC.views.customer();                       // renders and seeds A.plan / A.promise
const before = {
  riskBefore: NC.APP.plan.riskBefore, riskAfter: NC.APP.plan.riskAfter,
  fixed: NC.APP.plan.lines.filter(l => l.action !== 'sell').length,
  lines: NC.APP.plan.lines.length,
  legacyLate: NC.APP.promise.legacy.late15, smartLate: NC.APP.promise.smart.late15,
  legacyPromise: NC.APP.promise.legacy.promise, smartPromise: NC.APP.promise.smart.promise,
  legacyKept: NC.APP.promise.legacy.kept, smartKept: NC.APP.promise.smart.kept
};
console.log('  before: miss risk ' + F.pct(before.riskBefore, 1) + ' → ' + F.pct(before.riskAfter, 1)
  + ' · ' + before.fixed + '/' + before.lines + ' lines need fixing'
  + ' · late >15 min old ' + F.pct(before.legacyLate, 1) + ' → NOVA SURE ' + F.pct(before.smartLate, 1)
  + ' · promised ' + before.legacyPromise + ' → ' + before.smartPromise + ' min');
near('script: "0 of 4 lines can be promised at this store"', before.fixed, 4, 0);
near('script: miss risk 100% before re-planning (no line promisable)', before.riskBefore * 100, 100, 0.5);
near('script: old-engine late risk 18.0%', before.legacyLate * 100, 18.0, 0.5);
near('script: NOVA SURE late risk 3.1%', before.smartLate * 100, 3.1, 0.5);
near('script: promised 56 min (old) / 60 min (NOVA SURE)', before.legacyPromise, 56, 1);
near('script: promised 60 min (NOVA SURE)', before.smartPromise, 60, 1);

beat(3, 'Store app — four taps');
NC.APP.tab = 'store';
html = NC.views.store();
ok('three-button sync present', html.indexOf('Plenty in stock') >= 0 && html.indexOf('Out of stock') >= 0);
const taps = NC.APP.cart.length ? NC.APP.cart.map(l => l.skuId) : ['SKU23', 'SKU21', 'SKU24', 'SKU22'];
taps.forEach(id => NC.storeSync('ST07', id, 'in'));
ok('store reliability rose', STORE.reliability > 38, '38 → ' + STORE.reliability);
ok('catalogue age collapsed to 0.5h', STORE.syncHours === 0.5, 'first verified SKU resets it');

beat(3, 'Customer app again — same basket, same store');
NC.APP.tab = 'customer'; NC.APP.step = 3;
html = NC.views.customer();
const after = {
  riskBefore: NC.APP.plan.riskBefore, riskAfter: NC.APP.plan.riskAfter,
  fixed: NC.APP.plan.lines.filter(l => l.action !== 'sell').length,
  legacyLate: NC.APP.promise.legacy.late15, smartLate: NC.APP.promise.smart.late15,
  smartPromise: NC.APP.promise.smart.promise, smartKept: NC.APP.promise.smart.kept
};
console.log('  after : miss risk ' + F.pct(after.riskBefore, 1) + ' → ' + F.pct(after.riskAfter, 1)
  + ' · ' + after.fixed + '/' + before.lines + ' lines need fixing'
  + ' · late >15 min old ' + F.pct(after.legacyLate, 1) + ' → NOVA SURE ' + F.pct(after.smartLate, 1)
  + ' · promised ' + after.smartPromise + ' min');
near('script: 4 of 4 lines promisable after the taps', after.fixed, 0, 0);
near('script: miss risk 13.3% after', after.riskBefore * 100, 13.3, 0.5);
near('script: NOVA SURE late risk 1.1% after', after.smartLate * 100, 1.1, 0.3);
near('script: promised 54 min after', after.smartPromise, 54, 1);
ok('verification improved the promise', after.smartLate < before.smartLate, F.pct(before.smartLate, 1) + ' → ' + F.pct(after.smartLate, 1));

beat(4, 'Ops Trust Console');
NC.APP.tab = 'ops';
const leakBefore = NC.leakMap().reliabilityLeak;
html = NC.views.ops();
ok('queue is rendered with ₹ values', /\u20b9[\d,]+/.test(html) && html.indexOf('Auto-heal') >= 0);
const heal = NC.autoHeal(20);
const leakAfter = NC.leakMap().reliabilityLeak;
console.log('  auto-heal top 20: applied ' + heal.applied + ' · gain ' + F.inr(heal.gain) + ' · leak ' + F.lakh(leakBefore) + ' → ' + F.lakh(leakAfter));
ok('auto-heal applied 20 interventions', heal.applied === 20);
near('script: leak ₹9.89L before auto-heal (one store already fixed in Beat 3)', leakBefore / 100000, 9.89, 0.02);
near('script: leak ₹8.76L after auto-heal', leakAfter / 100000, 8.76, 0.02);
ok('leak fell materially', leakAfter < leakBefore * 0.95, F.lakh(leakBefore) + ' → ' + F.lakh(leakAfter));
ok('coverage rose from the interventions', NC.coverageFromWorld() > 0.3, F.pct(NC.coverageFromWorld(), 1));

beat(5, 'Decision Room');
NC.APP.tab = 'decision';
html = NC.views.decision();
const sc = NC.scenarios(NC.DEFAULTS, Math.min(1, 0.55 + 0.45 * Math.min(1, NC.coverageFromWorld())));
console.log('  Plan A cum12 ' + F.lakh(sc.A.cumulative12) + ' · Plan C cum12 ' + F.lakh(sc.C.cumulative12) + ' · Plan B cum12 ' + F.lakh(sc.B.cumulative12) + ' · gap ' + F.lakh(sc.B.cumulative12 - sc.A.cumulative12));
ok('script: Plan A ends negative', sc.A.cumulative12 < 0, F.lakh(sc.A.cumulative12));
ok('script: Plan B ends positive', sc.B.cumulative12 > 0, F.lakh(sc.B.cumulative12));
ok('script: the gap is what the demo leads with', (sc.B.cumulative12 - sc.A.cumulative12) > 2000000, F.lakh(sc.B.cumulative12 - sc.A.cumulative12));
ok('decision view leads with the gap', html.indexOf('The decision, in one line') >= 0 && html.indexOf('gap between the plan we are already running') >= 0);
ok('assumptions box present in the Decision Room', html.indexOf('Assumptions &amp; sensitivity') >= 0);

beat(6, 'Copilot — backup screen');
NC.APP.tab = 'copilot';
NC.copilotPrompts.slice(0, 4).forEach(q => {
  const a = NC.copilot(q);
  ok('copilot answers: ' + q.slice(0, 40), !!(a && a.headline && a.evidence.length), a.headline.slice(0, 60));
});

console.log('\n' + checks + ' demo-path checks, ' + fails + ' failures');
process.exit(fails ? 1 : 0);
