/* smoke_demo.js — renders every scene of the scripted walkthrough (demo.html)
   and checks the captions and the numbers they claim. The demo is the backup
   for the live demo, so it gets the same scrutiny as the app.
   Run:  node tests/smoke_demo.js                                     */

const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
require('../src/ui.js');
require('../src/demo.js');          // pure part only; the DOM driver self-disables in Node
const NC = g.NC, F = NC.F;

let fails = 0, checks = 0;
function ok(label, cond, detail) {
  checks++;
  if (!cond) { console.log('  FAIL ' + label + (detail ? '  →  ' + detail : '')); fails++; }
}
function clean(html) {
  const open = (html.match(/<div\b/g) || []).length;
  const close = (html.match(/<\/div>/g) || []).length;
  return { open, close };
}

ok('demo exposes its scenes', NC.DEMO && NC.DEMO.total >= 10, 'scenes: ' + (NC.DEMO && NC.DEMO.total));
ok('demo is about three minutes', NC.DEMO.minutes === 3);
const totalSecs = NC.DEMO.scenes.reduce((a, s) => a + s.secs, 0);
ok('scene timings add up to about 3 minutes', totalSecs >= 180 && totalSecs <= 230, totalSecs + 's');

console.log('\nrendering every scene');
NC.DEMO.scenes.forEach((s, i) => {
  const r = NC.DEMO.apply(i);
  checks++;
  if (!r.html || r.html.length < 400) { console.log(`  FAIL scene ${i + 1} (${s.title}) rendered ${r.html ? r.html.length : 0} chars`); fails++; return; }
  const c = clean(r.html);
  checks++;
  if (c.open !== c.close) { console.log(`  FAIL scene ${i + 1} unbalanced divs ${c.open}/${c.close}`); fails++; }
  checks++;
  if (/undefined|NaN|\[object Object\]/.test(r.html)) {
    const m = r.html.match(/.{0,50}(undefined|NaN|\[object Object\]).{0,50}/);
    console.log(`  FAIL scene ${i + 1} contains "${m && m[0]}"`); fails++;
  }
  checks++;
  if (!r.caption || r.caption.length < 20 || !r.say || r.say.length < 60) { console.log(`  FAIL scene ${i + 1} missing caption/narration`); fails++; }
  console.log(`  · ${String(i + 1).padStart(2)} ${String(s.secs).padStart(2)}s  ${s.title}  — ${r.html.length} chars`);
});

console.log('\ndeterminism and rewind safety');
const a = NC.DEMO.apply(7).html, b = NC.DEMO.apply(7).html;
ok('same scene renders identically twice', a === b);
NC.DEMO.apply(10); const back = NC.DEMO.apply(3).html;
const fresh = (function () { const r = NC.DEMO.apply(3).html; return r; })();
ok('rewinding behind a world-changing scene reproduces the earlier state', back === fresh);

console.log('\nthe scenes must show what the captions claim');
const at = i => NC.DEMO.apply(i);
const storeScene = at(NC.DEMO.scenes.findIndex(s => s.title.indexOf('after') >= 0));
ok('store scene shows a live catalogue', /live/.test(storeScene.html), 'looking for "live"');
const opsScene = at(NC.DEMO.scenes.findIndex(s => s.tab === 'ops'));
ok('ops scene shows the leak after auto-heal', opsScene.html.indexOf(F.lakh(NC.leakMap().reliabilityLeak)) >= 0, F.lakh(NC.leakMap().reliabilityLeak));
const decScene = at(NC.DEMO.scenes.findIndex(s => s.tab === 'decision'));
ok('decision scene shows the gap argument', decScene.html.indexOf('gap between the plan we are already running') >= 0);
ok('decision caption quotes the plan gap', /67\.74L/.test(decScene.caption) && /10\.33L/.test(decScene.caption));
const copScene = at(NC.DEMO.scenes.length - 2);
ok('copilot scene renders an answer', copScene.tab === 'copilot' && copScene.html.length > 800);
const last = at(NC.DEMO.total - 1);
ok('closing scene states the ask', /42%/.test(last.caption) || /42%/.test(last.say));

console.log('\n' + checks + ' demo checks, ' + fails + ' failures');
process.exit(fails ? 1 : 0);
