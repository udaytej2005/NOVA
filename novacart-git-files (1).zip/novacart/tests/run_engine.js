/* node harness — prints the numbers the app will show, so we can sanity-check
   them before they ever reach a screen. */
const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
const NC = g.NC, F = NC.F;

function line(t) { console.log('\n' + '='.repeat(72) + '\n' + t + '\n' + '='.repeat(72)); }

line('A. DERIVED KPIs FROM THE CASE PACK');
const d = NC.kpis;
console.log('GMV now            ', F.lakh(d.gmvNow), ' prior', F.lakh(d.gmvPrior));
console.log('Implied take rate  ', F.pct(d.takeNow, 2), ' prior', F.pct(d.takePrior, 2));
console.log('Promo per order    ', F.inr(d.promoPerOrder), ' prior', F.inr(d.promoPerOrderPrior));
console.log('Net rev per order  ', F.inr(d.netRevPerOrder), ' prior', F.inr(d.netRevPerOrderPrior));
console.log('Promo % of net rev ', F.pct(d.promoShareOfNetRev), ' prior', F.pct(d.promoShareOfNetRevPrior));
console.log('Incremental ROAS   ', d.incrementalRoas.toFixed(3), ' blended', d.blendedRoas.toFixed(3));
console.log('CAC / registration ', F.inr(d.cacPerRegistration), ' CAC/new buyer', F.inr(d.cacPerNewBuyer));
console.log('Repeat customers   ', F.num(d.repeatCustPrior), '->', F.num(d.repeatCustNow), 'delta', F.num(d.repeatCustDelta));
console.log('Orders per MAU     ', d.ordersPerMau.toFixed(3), ' prior', d.ordersPerMauPrior.toFixed(3));
console.log('Ticket / 100 orders', (d.ticketRate * 100).toFixed(1), ' prior', (d.ticketRatePrior * 100).toFixed(1));
console.log('Support cost       ', F.lakh(d.supportCost), F.pct(d.supportShareOfRevenue), 'of net rev; prior', F.lakh(d.supportCostPrior));
console.log('Orders lost/cancel ', F.num(d.ordersLostToCancel));

line('B. AVAILABILITY ENGINE — worst and best store, same basket');
const basket = [{ skuId: 'SKU01', qty: 1 }, { skuId: 'SKU04', qty: 2 }, { skuId: 'SKU17', qty: 1 }, { skuId: 'SKU12', qty: 1 }];
['ST07', 'ST04', 'ST01', 'ST10'].forEach(id => {
  const s = NC.storeById(id);
  console.log('\n' + s.name + ' (' + s.city + ', sync ' + s.syncHours + 'h, rel ' + s.reliability + ')');
  basket.forEach(l => {
    const a = NC.availability(s, NC.skuById(l.skuId));
    console.log('   ' + NC.skuById(l.skuId).name.padEnd(28) + String(a.score).padStart(3) + '  ' + a.band.label.padEnd(11) + a.evidence);
  });
});

line('C. ROUTING / SUBSTITUTION (customer sees this at checkout)');
const r = NC.routeBasket(basket, 'Nizamabad', {primaryStoreId:'ST04'});
console.log('store:', r.primaryStore, '| basket ₹' + r.basketValue);
console.log('miss risk before:', F.pct(r.riskBefore, 1), '-> after:', F.pct(r.riskAfter, 1), '| extra min:', r.extraMin);
r.lines.forEach(l => console.log('  ' + l.name.padEnd(28) + l.score + ' -> ' + l.fixedScore + '   ' + l.actionLabel));

line('D. PROMISE ENGINE — legacy vs honest, best and worst store');
['ST01', 'ST07'].forEach(id => {
  const s = NC.storeById(id), p = NC.promise(s, basket, 'smart');
  console.log('\n' + s.name);
  console.log('  central', p.central + 'min', 'sigma', p.sigma);
  console.log('  legacy: promise ' + p.legacy.promise + 'min  late>15 ' + F.pct(p.legacy.late15, 1) + '  within±5 ' + F.pct(p.legacy.kept, 0));
  console.log('  smart : promise ' + p.smart.promise + 'min  late>15 ' + F.pct(p.smart.late15, 1) + '  within±5 ' + F.pct(p.smart.kept, 0));
});

line('E. NETWORK LEAK MAP (monthly)');
const L = NC.leakMap();
L.lines.forEach(l => console.log('  ' + l.label.padEnd(48) + F.lakh(l.value).padStart(9)));
console.log('  ' + 'DIRECT RELIABILITY LEAK'.padEnd(48) + F.lakh(L.reliabilityLeak).padStart(9));
console.log('  ' + 'Lifetime revenue lost per acquired cohort'.padEnd(48) + F.lakh(L.cohortLifetimeRevenueGain).padStart(9));
console.log('  ' + 'TOTAL VALUE / MONTH'.padEnd(48) + F.lakh(L.totalMonthlyValue).padStart(9));
console.log('  ' + 'ANNUALISED'.padEnd(48) + F.cr(L.annualised).padStart(9));
console.log('  weighted cancel ' + F.pct(L.rates.cancel) + '  late ' + F.pct(L.rates.late) + '  sub ' + F.pct(L.rates.sub));

line('F. MONTE CARLO FUNNEL');
const bc = NC.businessCase();
console.log('legacy  p2', F.pct(bc.legacy.p2, 1), 'orders/cust', bc.ordersLegacy.toFixed(2), 'LTV', F.inr(bc.ltvLegacy), 'LTV:CAC', bc.ltvCacLegacy.toFixed(3), ' months3+', bc.legacy.months3plus.toFixed(1));
console.log('sure    p2', F.pct(bc.sure.p2, 1), 'orders/cust', bc.ordersSure.toFixed(2), 'LTV', F.inr(bc.ltvSure), 'LTV:CAC', bc.ltvCacSure.toFixed(3));
console.log('LTV lift', F.pct(bc.ltvLift, 1), ' CAC/new buyer', F.inr(bc.cac));

line('G. TWELVE-MONTH SCENARIOS');
NC.initWorld();
const S = NC.scenarios(NC.DEFAULTS, 0.55);
['C', 'A', 'B'].forEach(k => {
  const s = S[k];
  console.log('\n' + s.plan.name);
  console.log('  M6  orders ' + F.num(s.m6.orders) + ' (' + F.signed(s.m6.orders/38500-1,1) + ')  revenue ' + F.lakh(s.m6.revenue) + '  tickets ' + F.num(s.m6.tickets));
  console.log('  M12 orders ' + F.num(s.m12.orders) + ' (' + F.signed(s.m12.orders/38500-1,1) + ')  revenue ' + F.lakh(s.m12.revenue) + '  tickets ' + F.num(s.m12.tickets));
  console.log('  delta vs today -> M6 ' + F.lakh(s.m6.contribution) + '/mo   M12 ' + F.lakh(s.m12.contribution) + '/mo   12-mo cumulative ' + F.lakh(s.cumulative12) + '   payback ' + (s.paybackMonth ? 'M' + s.paybackMonth : 'n/a'));
  console.log('  M6 repeat ' + F.pct(s.m6.repeatRate,1) + '  p2 ' + F.pct(s.m6.p2,1) + '  churn ' + F.pct(s.m6.churn,1) + '  program ' + F.lakh(s.programSpent));
});
console.log('\nB-A 6mo contribution delta:', F.lakh(S.B.cumulative6 - S.A.cumulative6));
console.log('B-A M6 orders delta:', F.num(S.B.m6.orders - S.A.m6.orders));
console.log('B-C M6 orders delta:', F.num(S.B.m6.orders - S.C.m6.orders));
console.log('targets: B M6 orders ~44k, repeat ~35%, C M6 ~37-38k');
console.log('derived planB:', JSON.stringify(S.B.derived, (k, v) => typeof v === 'number' ? +v.toFixed(3) : v));

line('H. SENSITIVITY (6-month cumulative contribution)');
const sen = NC.sensitivity();
console.log('            spend->  ' + sen.spends.map(s => (s + 'x').padStart(11)).join(''));
sen.grid.forEach((row, i) => {
  console.log('lift ' + (sen.lifts[i] * 100 + '%').padStart(6) + '  ' + row.map(c => F.lakh(c.contribution6).padStart(11)).join(''));
});

line('I. INTERVENTION QUEUE — top 8 by value/effort');
NC.interventionQueue().slice(0, 8).forEach(a =>
  console.log('  #' + a.rank + ' ' + a.storeName.padEnd(30) + F.inr(a.gain).padStart(8) + '/mo  effort ' + a.effort + '  ' + a.label.slice(0, 52)));

line('J. COPILOT SPOT CHECKS');
['is the business getting better', 'what is reliability costing us', 'should we raise marketing spend by 30%', 'is inventory or delivery the bottleneck', 'what should we build'].forEach(q => {
  const a = NC.copilot(q);
  console.log('\nQ: ' + q + '   [matched: ' + a.matched + ']');
  console.log('   ' + a.headline);
});

line('K. ORDER SAMPLE FIDELITY (400 orders)');
const o = NC.orderSampleStats;
console.log('n=' + o.n, 'cancel', F.pct(o.cancelRate), '(case 11%)', 'late>15', F.pct(o.lateRate), '(case 13%)', 'sub', F.pct(o.subRate), '(case 8%)', 'tickets', F.pct(o.ticketRate), '(case 15.3%)');

line('L. STORE RESET + ONE INTERVENTION (state really changes)');
NC.initWorld();
console.log('before: ST07 sync', NC.storeById('ST07').syncHours + 'h rel', NC.storeById('ST07').reliability, 'cancel', F.pct(NC.storeById('ST07').cancelRate));
NC.applyIntervention('ST07', 'sync');
console.log('after : ST07 sync', NC.storeById('ST07').syncHours + 'h rel', NC.storeById('ST07').reliability, 'cancel', F.pct(NC.storeById('ST07').cancelRate));
const L2 = NC.leakMap();
console.log('leak before', F.lakh(L.reliabilityLeak), '-> after one store fixed', F.lakh(L2.reliabilityLeak));
const ah = NC.autoHeal(20);
console.log('autoHeal top 20:', JSON.stringify(ah), 'coverage now', F.pct(NC.coverageFromWorld(),1), 'leak now', F.lakh(NC.leakMap().reliabilityLeak));
const S2 = NC.scenarios(NC.DEFAULTS, NC.coverageFromWorld());
console.log('with fixes applied, Plan B M6 orders', F.num(S2.B.m6.orders), 'coverage', F.pct(NC.coverageFromWorld(),1));
NC.resetWorld();

line('M. CODE HYGIENE — modular source, build output, no secrets, no network');
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
let hygieneFails = 0;
function rule(ok, label, detail) {
  console.log((ok ? '  ok   ' : '  FAIL ') + label + (detail ? '  — ' + detail : ''));
  if (!ok) hygieneFails++;
}
const engine = read('src/engine.js'), ui = read('src/ui.js'), data = read('src/data.js'), built = read('index.html');
rule(!/\bdocument\.|\bwindow\.|innerHTML/.test(engine), 'engine.js is model-only (no DOM references)');
rule(!/innerHTML/.test(data), 'data.js is data-only (no DOM references)');
rule(!/require\(|process\.|module\.exports/.test(ui), 'ui.js renders HTML and nothing node-specific');
rule(/GENERATED FILE/.test(built), 'index.html carries a "generated, do not edit" banner');
const ext = [/<script[^>]+src=/i, /<link\b[^>]*\bhref=/i, /@import/i, /url\(\s*["']?https?:/i, /<img\b[^>]+src=["']https?:/i, /https?:\/\/[^"'\s)]+/i]
  .filter(re => re.test(built));
rule(ext.length === 0, 'index.html loads nothing external (no script src, link href, @import, remote url)', ext.join(' '));
rule(!/https?:\/\/[^"'\s)]+/.test(engine + ui + data), 'no network URLs anywhere in the source (no CDN, no API endpoint)');
rule(!/(sk-[A-Za-z0-9]{8,}|AIza[0-9A-Za-z_-]{10,}|api[_-]?key\s*[:=]\s*["'][^"']{8,})/i.test(engine + ui + data), 'no API keys or key-shaped secrets in the repo');
rule(/NC\._cache/.test(engine) && /NC\.debounce/.test(engine), 'memo cache and debounce live in the engine');
rule(/name="viewport"/.test(built) && /<meta charset/.test(built), 'built file declares charset and viewport');
/* dead code: every function exported onto NC must be referenced somewhere in the
   repo. This is how NC.view, NC.params, NC.mount and NC.snapshot got removed —
   the guard stops equivalents from creeping back in. */
(function () {
  const files = ['src/data.js', 'src/engine.js', 'src/ui.js', 'src/demo.js', 'src/shell.html', 'src/demo_shell.html',
    'tests/smoke_ui.js', 'tests/run_engine.js', 'tests/demo_path.js', 'tests/smoke_demo.js', 'tests/check_docs.js',
    'tools/dump_numbers.js'];
  const src = files.map(f => { try { return fs.readFileSync(path.join(root, f), 'utf8'); } catch (e) { return ''; } }).join('\n');
  const names = new Set();
  ['src/data.js', 'src/engine.js', 'src/ui.js', 'src/demo.js'].forEach(f => {
    const t = fs.readFileSync(path.join(root, f), 'utf8');
    for (const m of t.matchAll(/NC\.([A-Za-z_]\w*)\s*=\s*function/g)) names.add(m[1]);
  });
  const dead = [...names].filter(n => {
    const all = (src.match(new RegExp('NC\\.' + n + '\\b', 'g')) || []).length;
    const decls = (src.match(new RegExp('NC\\.' + n + '\\s*=\\s*function', 'g')) || []).length;
    return all - decls <= 0;
  });
  rule(dead.length === 0, 'no dead NC.* exports (every exported function is referenced)', dead.join(', '));
})();

console.log('\n  hygiene: ' + (hygieneFails ? hygieneFails + ' FAILURE(S)' : 'all checks passed'));
if (hygieneFails) process.exitCode = 1;
