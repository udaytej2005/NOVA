/* smoke test: render every view in every reachable state and check the HTML
   comes back non-empty and balanced. Catches runtime errors before the demo. */
const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
require('../src/ui.js');
const NC = g.NC;
let fails = 0, checks = 0;

/* Tag-aware detection. Escaped text is inert, so the question is not "does the
   string appear" but "is there a real tag or a real inline handler". Quoted
   attribute VALUES are stripped first, because a payload inside a value is text. */
function liveMarkup(html) {
  const stripped = html.replace(/"[^"]*"/g, '""').replace(/'[^']*'/g, "''");
  return {
    // tags the app never legitimately renders. <svg class="chart"> IS legitimate,
    // so svg is excluded here and covered by the handler check below.
    tag: /<(img|script|iframe|object|embed)\b/i.test(stripped),
    // any inline handler inside a real tag: <svg onload= ...> and <svg/onload= ...>
    handler: /<[a-zA-Z][^>]*?[\s\/]on[a-z]+\s*=/i.test(stripped)
  };
}

function balanced(html, label) {
  const open = (html.match(/<div\b/g) || []).length;
  const close = (html.match(/<\/div>/g) || []).length;
  checks++;
  if (open !== close) { console.log(`  ✗ ${label}: <div> ${open} vs </div> ${close}`); fails++; return false; }
  return true;
}

function check(label, fn) {
  try {
    const out = fn();
    if (typeof out !== 'string' || out.length < 40) { console.log(`  ✗ ${label}: empty output`); fails++; return; }
    balanced(out, label);
    if (/undefined|NaN|\[object Object\]/.test(out)) {
      const m = out.match(/.{0,60}(undefined|NaN|\[object Object\]).{0,60}/);
      console.log(`  ✗ ${label}: contains "${m && m[0]}"`); fails++;
    }
  } catch (e) {
    console.log(`  ✗ ${label}: threw ${e.message}`); fails++;
  }
}

NC.initWorld();
console.log('views — default state');
['diagnosis', 'customer', 'store', 'ops', 'decision', 'copilot'].forEach(t => {
  NC.APP.tab = t;
  check(`view ${t}`, () => NC.views[t]());
});

console.log('customer flow — every city, store and step');
NC.CASE.company.citiesList.forEach(city => {
  NC.APP.city = city; NC.APP.seedDone = false; NC.APP.step = 1;
  NC.STORES.filter(s => s.city === city).forEach(s => {
    NC.APP.storeId = s.id; NC.APP.seedDone = false;
    [1, 2, 3, 4].forEach(step => { NC.APP.step = step; check(`customer ${city}/${s.id}/step${step}`, () => NC.views.customer()); });
  });
});

console.log('customer flow — empty basket and every store category');
NC.APP.city = 'Hyderabad'; NC.APP.storeId = 'ST10'; NC.APP.cart = []; NC.APP.seedDone = true;
[1, 2, 3].forEach(step => { NC.APP.step = step; check(`empty cart step${step}`, () => NC.views.customer()); });

console.log('store app — after syncing every flagged item of the worst store');
NC.APP.tab = 'store'; NC.APP.storeId = 'ST07';
check('store ST07 before sync', () => NC.views.store());
const flagged = NC.SKUS.filter(k => NC.availability(NC.storeById('ST07'), k).score < 82).slice(0, 6);
flagged.forEach((k, i) => NC.storeSync('ST07', k.id, i % 3 === 0 ? 'out' : i % 3 === 1 ? 'low' : 'in'));
check('store ST07 after sync', () => NC.views.store());

console.log('ops console — apply things, watch the state move');
NC.APP.tab = 'ops';
const leak0 = NC.leakMap().reliabilityLeak;
check('ops before', () => NC.views.ops());
let opened = 0;
NC.interventionQueue().slice(0, 3).forEach(q => {
  const before = NC.storeById(q.storeId);
  const r = NC.applyIntervention(q.storeId, q.id);
  if (r) { NC.logIntervention(q.storeId, q.id, q.label, q.gain); NC.APP.toast = 'applied ' + q.id; opened++; }
});
check(`ops after ${opened} manual applies`, () => NC.views.ops());
const heal = NC.autoHeal(20);
check('ops after autoheal', () => NC.views.ops());
const leak1 = NC.leakMap().reliabilityLeak;
console.log(`  leak ${NC.F.lakh(leak0)} → ${NC.F.lakh(leak1)}  (autoheal reports ${NC.F.inr(heal.gain)}/mo of queued value, ${heal.applied} actions)`);
checks++; if (leak1 >= leak0) { console.log('  ✗ the leak did not fall after interventions'); fails++; }

console.log('decision room — every slider at its extremes');
NC.APP.tab = 'decision';
NC.APP.params = Object.assign({}, NC.DEFAULTS);
check('decision defaults', () => NC.views.decision());
[['reliabilityShare', 0.2], ['reliabilityShare', 1], ['retentionResponse', 0], ['retentionResponse', 0.5],
 ['sigmaBase', 3], ['sigmaBase', 14], ['promiseOffset', -6], ['promiseOffset', 6],
 ['loyaltyMonths', 6], ['loyaltyMonths', 30], ['secondOrder30d', 0.2], ['secondOrder30d', 0.5]].forEach(([k, v]) => {
  NC.APP.params = Object.assign({}, NC.DEFAULTS, { [k]: v });
  NC.APP.sensitivity = null;
  check(`decision ${k}=${v}`, () => NC.views.decision());
});

console.log('copilot — every preset question plus a miss');
NC.APP.tab = 'copilot';
NC.copilotPrompts.forEach(q => {
  NC.APP.asked = NC.copilot(q);
  check('copilot: ' + q.slice(0, 34), () => NC.views.copilot());
});
NC.APP.asked = NC.copilot('tell me about zebras');
check('copilot no-match', () => NC.views.copilot());

console.log('dispatcher — no crashes on any action');
['tab', 'city', 'store', 'gotostore', 'step', 'qty', 'sync', 'apply', 'autoheal', 'reset', 'resetparams'].forEach(a => {
  const el = { dataset: { tab: 'ops', city: 'Warangal', store: 'ST07', step: '2', sku: 'SKU01', d: '1', state: 'in', action: 'sync', n: '5' } };
  check('dispatch ' + a, () => { NC.dispatch(a, el, {}); return NC.renderApp(); });
});

console.log('security — user-typed text must never reach innerHTML unescaped');
NC.APP.tab = 'copilot';
[['script tag', '<script>alert(1)</script>'],
 ['img/onerror', '"><img src=x onerror=alert(1)>'],
 ['attribute break', '" onmouseover="alert(1)'],
 ['apostrophe', "it's a '; DROP TABLE orders;--"],
 ['markup close', '</div></textarea><svg/onload=alert(1)>']].forEach(([name, payload]) => {
  NC.APP.question = payload;
  NC.APP.asked = NC.copilot(payload);
  const html = NC.views.copilot();
  const attr = (html.match(/id="qbox"[^>]*?value="([^"]*)"/) || [])[1];
  checks++;
  const problems = [];
  if (html.includes(payload)) problems.push('raw payload present in output');
  const live = liveMarkup(html);
  if (live.tag) problems.push('live tag markup');
  if (live.handler) problems.push('inline event handler attribute');
  if (/<\/div><\/textarea|<\/textarea>/.test(html)) problems.push('markup break-out');
  if (attr === undefined) problems.push('question not echoed at all');
  else if (/[<>"']/.test(attr)) problems.push('unescaped character inside the value attribute');
  if (problems.length) { console.log(`  \u2717 escaping (${name}): ${problems.join('; ')}`); fails++; }
});
NC.APP.question = ''; NC.APP.asked = null;

console.log('security — data-derived strings (store names, SKUs) must be escaped too');
(function () {
  const payload = '"><img src=x onerror=alert(1)>';
  const keepStore = NC.STORES[0].name, keepSku = NC.SKUS[0].name, keepArea = NC.STORES[0].area;
  NC.STORES[0].name = payload; NC.SKUS[0].name = payload; NC.STORES[0].area = payload;
  ['diagnosis', 'customer', 'store', 'ops', 'decision', 'copilot'].forEach(tab => {
    NC.APP.tab = tab;
    const html = NC.renderApp();
    checks++;
    const live = liveMarkup(html);
    if (live.tag || live.handler) {
      const m = html.match(/.{0,90}(<img|<svg|onerror=|onload=).{0,90}/i);
      console.log(`  ✗ store/SKU name payload produced live markup in ${tab} :: ${m && m[0]}`);
      fails++;
    }
    if (html.includes(payload)) { console.log(`  ✗ store/SKU name payload survived raw in ${tab}`); fails++; }
  });
  NC.STORES[0].name = keepStore; NC.SKUS[0].name = keepSku; NC.STORES[0].area = keepArea;
  NC.initWorld();
})();

console.log('efficiency — memoised model, bounded Monte Carlo');
NC.resetCache();
NC.views.decision();
const first = NC.cacheStats();
NC.views.decision();
const second = NC.cacheStats();
checks++;
if (second.misses !== first.misses) { console.log(`  ✗ cache: re-render caused ${second.misses - first.misses} new model computations`); fails++; }
checks++;
if (second.hits <= first.hits) { console.log('  ✗ cache: no cache hits recorded'); fails++; }
checks++;
if (NC.simulate({ n: 5e6 }).n > 200000) { console.log('  ✗ Monte Carlo not bounded'); fails++; }
const t0 = Date.now();
for (let i = 0; i < 5; i++) NC.views.decision();
const warm = (Date.now() - t0) / 5;
checks++;
if (warm > 120) { console.log(`  ✗ warm decision render too slow: ${warm.toFixed(0)}ms`); fails++; }
else console.log(`  · warm decision render ${warm.toFixed(1)}ms, cache hits ${NC.cacheStats().hits}`);

console.log(`\n${checks} checks, ${fails} failures`);

/* debounce is asynchronous — verify it collapses a burst into one trailing call,
   then exit. Keeps the whole check suite runnable as one command. */
let debounceCalls = 0;
const debounced = NC.debounce(() => { debounceCalls++; }, 60);
for (let i = 0; i < 12; i++) debounced();          // a slider drag
setTimeout(() => {
  checks++;
  if (debounceCalls !== 1) { console.log(`  ✗ debounce: 12 rapid inputs produced ${debounceCalls} renders`); fails++; }
  else console.log('  · debounce: 12 rapid slider inputs -> 1 render');
  console.log(`\n${checks} checks, ${fails} failures (final)`);
  process.exit(fails ? 1 : 0);
}, 220);
