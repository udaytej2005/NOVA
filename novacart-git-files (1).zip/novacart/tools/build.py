#!/usr/bin/env python3
"""
build.py — inlines styles.css, data.js, engine.js and ui.js into a single
self-contained index.html so the app runs from a file:// URL, from the
workspace preview, or from any static host, with no network access at all.

Usage:  python3 tools/build.py
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
OUT = ROOT / "index.html"

def read(name: str) -> str:
    p = SRC / name
    if not p.exists():
        sys.exit(f"missing {p}")
    return p.read_text(encoding="utf-8")

def strip_comments_for_safety(js: str) -> str:
    """Remove the /* */ banner comments only when they would break inlining."""
    return js.replace("</script>", "<\\/script>")

styles = read("styles.css")
CORE = ("data.js", "engine.js", "ui.js")


def render(shell_name: str, out_name: str, extra_js: tuple = ()):
    """Inline the shared source into a shell. Both output files are generated
    from src/; neither is ever edited by hand."""
    shell = read(shell_name)
    scripts = "\n".join(strip_comments_for_safety(read(f)) for f in CORE + tuple(extra_js))
    banner = (
        "  <!-- GENERATED FILE — do not edit by hand.\n"
        "       Source of truth: src/{shell} + src/styles.css + src/".format(shell=shell_name)
        + " + src/".join(CORE + tuple(extra_js)) + "\n"
        "       Rebuild:  python3 tools/build.py\n"
        "       Verify:   node tests/smoke_ui.js  ·  node tests/demo_path.js  ·  node tests/check_docs.js -->\n"
    )
    html = shell.replace("/*{{STYLES}}*/", "\n" + styles + "\n")
    html = html.replace("<head>", "<head>\n" + banner, 1)
    # rebuild from the shell every run, so placeholders are never consumed
    html = html.replace("/*{{SCRIPTS}}*/", "\n" + scripts + "\n")
    out = ROOT / out_name
    out.write_text(html, encoding="utf-8")
    kb = out.stat().st_size / 1024
    print(f"built {out_name}  ({kb:.0f} KB, {html.count(chr(10))} lines)")
    return html


app = render("shell.html", "index.html")
render("demo_shell.html", "demo.html", extra_js=("demo.js",))
print("self-contained: no external css, js, fonts or images")
print("index.html and demo.html are build outputs — edit src/ and rebuild")
