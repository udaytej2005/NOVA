#!/usr/bin/env python3
"""
make_docx.py — turns the written pack (SUBMISSION.md + docs/*.md + EVIDENCE.md)
into ONE submission-ready .docx, because most submission portals want a document
rather than a folder of markdown.

Deliberately dependency-light: python-docx only, and a small markdown subset
(headings, paragraphs, bullets, numbered lists, pipe tables, blockquotes, fenced
code, bold/italic/`code` inline). Anything it does not understand is emitted as
plain text rather than dropped, so the document can never silently lose content.

Usage:  python3 tools/make_docx.py
"""
import pathlib
import re
import sys

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:  # pragma: no cover
    sys.exit("python-docx is required:  pip install python-docx")

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "NOVA-SURE-submission.docx"

PARTS = [
    ("SUBMISSION.md", "Submission pack"),
    ("docs/01-problem-diagnosis.md", "1 · Problem Diagnosis"),
    ("docs/02-prompt-journey.md", "2 · Prompt Journey"),
    ("docs/03-solution-explanation.md", "3 · Solution Explanation"),
    ("docs/04-demo-script.md", "4 · Demo Script"),
    ("docs/05-business-impact.md", "5 · Business Impact"),
    ("docs/06-source-code.md", "6 · Source Code"),
    ("EVIDENCE.md", "Appendix A · Evidence pack (generated from the engine)"),
    ("DEPLOY.md", "Appendix B · How to publish and verify"),
]

INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+`|\*[^*]+?\*|https?://\S+|`?[\w./-]+\.(?:md|html|js|py|css)`)")
LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def add_runs(par, text):
    """Render a markdown line into a paragraph, keeping bold/italic/code."""
    text = LINK.sub(r"\1 (\2)", text)
    for chunk in INLINE.split(text):
        if not chunk:
            continue
        if chunk.startswith("**") and chunk.endswith("**") and len(chunk) > 4:
            par.add_run(chunk[2:-2]).bold = True
        elif chunk.startswith("`") and chunk.endswith("`") and len(chunk) > 2:
            r = par.add_run(chunk[1:-1])
            r.font.name = "Consolas"
            r.font.size = Pt(9)
        elif chunk.startswith("*") and chunk.endswith("*") and len(chunk) > 2:
            par.add_run(chunk[1:-1]).italic = True
        else:
            par.add_run(chunk)


def is_table_row(line):
    return line.strip().startswith("|") and line.strip().endswith("|")


def split_row(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def add_table(doc, rows):
    head = split_row(rows[0])
    body = [split_row(r) for r in rows[2:] if not re.match(r"^\|[\s:|-]+\|$", r.strip())]
    t = doc.add_table(rows=1, cols=len(head))
    t.style = "Light Grid Accent 1"
    for i, h in enumerate(head):
        cell = t.rows[0].cells[i]
        cell.text = ""
        add_runs(cell.paragraphs[0], h)
        for r in cell.paragraphs[0].runs:
            r.bold = True
            r.font.size = Pt(8.5)
    for row in body:
        cells = t.add_row().cells
        for i, val in enumerate(row[:len(head)]):
            cells[i].text = ""
            add_runs(cells[i].paragraphs[0], val)
            for r in cells[i].paragraphs[0].runs:
                r.font.size = Pt(8.5)
    doc.add_paragraph()


def render(doc, md, part_title):
    lines = md.split("\n")
    i = 0
    first_heading_seen = False
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped.startswith("```"):
            block = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                block.append(lines[i])
                i += 1
            p = doc.add_paragraph()
            r = p.add_run("\n".join(block))
            r.font.name = "Consolas"
            r.font.size = Pt(8)
            p.paragraph_format.left_indent = Inches(0.2)
            i += 1
            continue

        if is_table_row(line) and i + 1 < len(lines) and re.match(r"^\|[\s:|-]+\|$", lines[i + 1].strip()):
            rows = []
            while i < len(lines) and is_table_row(lines[i]):
                rows.append(lines[i])
                i += 1
            add_table(doc, rows)
            continue

        if stripped.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.25)
            add_runs(p, stripped.lstrip("> ").strip())
            for r in p.runs:
                r.italic = True
                r.font.color.rgb = RGBColor(0x33, 0x44, 0x55)
            i += 1
            continue

        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level, txt = len(m.group(1)), m.group(2)
            if level == 1:
                if not first_heading_seen:
                    first_heading_seen = True
                    doc.add_heading(part_title, level=1)
                    if txt.strip().lower() != part_title.lower():
                        doc.add_heading(txt, level=2)
                else:
                    doc.add_heading(txt, level=2)
            else:
                doc.add_heading(txt, level=min(level, 4))
            i += 1
            continue

        if re.match(r"^[-*]\s+", stripped):
            p = doc.add_paragraph(style="List Bullet")
            add_runs(p, re.sub(r"^[-*]\s+", "", stripped))
            i += 1
            continue

        if re.match(r"^\d+\.\s+", stripped):
            p = doc.add_paragraph(style="List Number")
            add_runs(p, re.sub(r"^\d+\.\s+", "", stripped))
            i += 1
            continue

        if stripped in ("---", "***", "___"):
            doc.add_paragraph()
            i += 1
            continue

        if stripped:
            p = doc.add_paragraph()
            add_runs(p, stripped)
            if stripped.startswith("*") and stripped.endswith("*"):
                for r in p.runs:
                    r.italic = True
        i += 1


def main():
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10)

    # ---- title page ----
    t = doc.add_heading("NOVA SURE", level=0)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_runs(sub, "**An availability-and-promise layer for NOVA CART**")
    sub2 = doc.add_paragraph()
    sub2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_runs(sub2, "Submission for the NOVA CART business-innovation challenge\n"
                   "AI-powered Business Innovation Team\n\n"
                   "*Problem Diagnosis · Prompt Journey · Solution Explanation · Functional Prototype · "
                   "Source Code · Demo · Business Impact*")
    doc.add_paragraph()
    note = doc.add_paragraph()
    add_runs(note, "This document is generated from the same repository that contains the working application. "
                   "Every figure quoted here is produced by that application's engine — "
                   "`node tools/dump_numbers.js` regenerates the evidence pack in Appendix A — so the written "
                   "submission and the prototype cannot disagree.")
    doc.add_page_break()

    for idx, (rel, title) in enumerate(PARTS):
        path = ROOT / rel
        if not path.exists():
            print("  (missing, skipped) " + rel)
            continue
        if idx:
            doc.add_page_break()
        render(doc, path.read_text(encoding="utf-8"), title)
        print("  added " + rel)

    doc.save(OUT)
    kb = OUT.stat().st_size / 1024
    print(f"\nwrote {OUT.name}  ({kb:.0f} KB)")
    print("Open it in Word/Google Docs to check pagination before submitting.")


if __name__ == "__main__":
    main()
