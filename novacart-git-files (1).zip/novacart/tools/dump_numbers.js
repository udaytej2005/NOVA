/* dump_numbers.js — emits EVIDENCE.md straight out of the engine, so the
   written submission and the running application can never disagree.
   run:  node tools/dump_numbers.js  */
const fs = require('fs');
const path = require('path');
const g = globalThis;
require('../src/data.js');
require('../src/engine.js');
const NC = g.NC, F = NC.F, K = NC.CASE.kpi, d = NC.kpis;

const L = [];
function w(s) { L.push(s); }
function h1(t) { w('\n## ' + t + '\n'); }
function tbl(headers, rows) {
  w('| ' + headers.join(' | ') + ' |');
  w('|' + headers.map(() => '---').join('|') + '|');
  rows.forEach(r => w('| ' + r.join(' | ') + ' |'));
  w('');
}

NC.initWorld();
const leak = NC.leakMap();
const bc = NC.businessCase();
const S = NC.scenarios(NC.DEFAULTS, 0.55);

w('# NOVA SURE — evidence pack (generated)');
w('');
w('> Every figure below is produced by `tools/dump_numbers.js` from the same engine the');
w('> application runs (`src/engine.js`). Nothing in the written submission is typed by hand.');
w('> Regenerate with `node tools/dump_numbers.js`.');
w('');
w('Generated: ' + new Date().toISOString().slice(0, 10) + ' · order sample n=' + NC.orderSampleStats.n + ' · stores ' + NC.STORES.length + ' · SKUs ' + NC.SKUS.length);

h1('1. Derived from the case pack');
tbl(['Metric', '6 months ago', 'Today', 'Change'], [
  ['Registered users', F.num(K.registered.prior), F.num(K.registered.now), F.signed(K.registered.now / K.registered.prior - 1, 1)],
  ['Monthly active users', F.num(K.mau.prior), F.num(K.mau.now), F.signed(K.mau.now / K.mau.prior - 1, 1)],
  ['Monthly orders', F.num(K.orders.prior), F.num(K.orders.now), F.signed(K.orders.now / K.orders.prior - 1, 1)],
  ['Average order value', F.inr(K.aov.prior), F.inr(K.aov.now), F.signed(K.aov.now / K.aov.prior - 1, 1)],
  ['Repeat purchase rate', F.pct(K.repeat.prior, 0), F.pct(K.repeat.now, 0), F.signed(K.repeat.now / K.repeat.prior - 1, 1)],
  ['Repeat buyers (absolute)', F.num(d.repeatCustPrior), F.num(d.repeatCustNow), F.num(d.repeatCustDelta)],
  ['Average delivery time', K.delivery.prior + ' min', K.delivery.now + ' min', F.signed(K.delivery.now / K.delivery.prior - 1, 1)],
  ['Cancellation rate', F.pct(K.cancel.prior, 0), F.pct(K.cancel.now, 0), '+' + ((K.cancel.now - K.cancel.prior) * 100).toFixed(0) + ' pts'],
  ['Support tickets / month', F.num(K.tickets.prior), F.num(K.tickets.now), F.signed(K.tickets.now / K.tickets.prior - 1, 1)],
  ['Promotional spend / month', F.lakh(K.promo.prior), F.lakh(K.promo.now), F.signed(K.promo.now / K.promo.prior - 1, 1)],
  ['Revenue / month', F.lakh(K.revenue.prior), F.lakh(K.revenue.now), F.signed(K.revenue.now / K.revenue.prior - 1, 1)]
]);
w('Derived (not disclosed, computed here):');
w('');
tbl(['Derived metric', '6 months ago', 'Today'], [
  ['GMV at the disclosed AOV', F.lakh(d.gmvPrior), F.lakh(d.gmvNow)],
  ['Implied platform take rate (revenue ÷ GMV)', F.pct(d.takePrior, 2), F.pct(d.takeNow, 2)],
  ['Promotional spend per order', F.inr(d.promoPerOrderPrior), F.inr(d.promoPerOrderNow || d.promoPerOrder)],
  ['Platform revenue per order', F.inr(d.netRevPerOrderPrior), F.inr(d.netRevPerOrder)],
  ['Promotions as a share of platform revenue', F.pct(d.promoShareOfNetRevPrior), F.pct(d.promoShareOfNetRev)],
  ['Support cost as a share of platform revenue', F.pct(d.supportShareOfRevenuePrior), F.pct(d.supportShareOfRevenue)],
  ['Tickets per 100 orders', (d.ticketRatePrior * 100).toFixed(1), (d.ticketRate * 100).toFixed(1)],
  ['Orders per monthly active user', d.ordersPerMauPrior.toFixed(3), d.ordersPerMau.toFixed(3)]
]);
w('Headline economics of the last six months:');
w('');
w('- Incremental revenue / incremental promotional spend = ' + F.lakh(K.revenue.now - K.revenue.prior) + ' / ' + F.lakh(K.promo.now - K.promo.prior) +
  ' = **' + d.incrementalRoas.toFixed(2) + '×** (blended ' + d.blendedRoas.toFixed(2) + '×).');
w('- Each of the ' + F.num(K.orders.now - K.orders.prior) + ' incremental monthly orders cost **' +
  F.inr(d.marginalPromoPerOrder) + ' of promotions** and added **' + F.inr(d.marginalRevPerOrder) +
  ' of platform revenue**. Marginal-to-marginal: ' + F.inr(d.marginalRevPerOrder) + ' / ' + F.inr(d.marginalPromoPerOrder) +
  ' = ' + (d.marginalRevPerOrder / d.marginalPromoPerOrder).toFixed(3) + '× — identical to ₹4.30L / ₹7.50L, as it must be.');
w('- Deliberately **not** compared against today\'s *average* revenue per order (' + F.inr(d.netRevPerOrder) +
  '). An average is not what the extra spend bought; mixing the two is the classic way to make a marginal-ROAS argument wrong.');
w('- Cost per newly registered user: ' + F.inr(d.cacPerRegistration) + ' up to ' + F.inr(K.promo.now / NC.CASE.marketing.newRegPerMonth) + ' depending on whether all promo spend is charged to acquisition.');
w('- Cost per first-order customer: ' + F.inr(d.cacPerNewBuyer) + ' (58% acquisition-tagged spend ÷ ' + F.num(Math.round(d.newBuyersPerMonth)) + ' first orders a month).');
w('- Lifetime platform revenue per acquired customer at today\'s experience mix: ' + F.inr(bc.ltvLegacy) + ' → LTV:CAC **' + bc.ltvCacLegacy.toFixed(2) + ':1** (healthy D2C benchmark: 3:1).');

w('The repeat-buyer count, defined so a reviewer can check it. The case pack does not state the base the repeat rate is measured on, so it is given on all three plausible bases:');
w('');
tbl(['Basis', '6 months ago', 'Today', 'Change'], d.repeatBases.map(b => [b.basis, F.num(b.prior), F.num(b.now), F.num(b.now - b.prior)]));
w('The headline uses **registered users x repeat rate** — the most conservative of the three. Every basis falls, so the direction of the finding does not depend on which denominator the case pack had in mind.');
w('');
w('ROAS, all three definitions side by side (the app quotes the first and shows the second as a bound):');
w('');
tbl(['Definition', 'Value', 'What it compares'], [
  ['**Incremental ROAS (used everywhere)**', d.incrementalRoas.toFixed(3) + 'x', 'extra revenue (₹4.30L) / extra promo spend (₹7.50L) — the standard definition'],
  ['Most generous reading', d.roasBoundGenerous.toFixed(3) + 'x', "today's average revenue per order (" + F.inr(d.netRevPerOrder) + ') / marginal promo per extra order (' + F.inr(d.marginalPromoPerOrder) + ')'],
  ['Blended', d.blendedRoas.toFixed(3) + 'x', 'total revenue / total promo spend']
]);
w('All three are below 1. Whichever is chosen, the conclusion — the last six months of promotional spend did not pay for itself — is unchanged.');
w('');
h1('2. The reliability leak (monthly, at the disclosed rates)');
tbl(['Leak line', 'Owner', '₹ / month', 'Evidence'], leak.lines.map(l => [l.label, l.owner, F.lakh(l.value), l.evidence]));
w('**Direct reliability leak: ' + F.lakh(leak.reliabilityLeak) + ' / month = ' + F.cr(leak.annualisedDirect) + ' a year.**');
w('');
w('- Lifetime revenue lost from one month\'s acquired cohort: **' + F.lakh(leak.cohortLifetimeRevenueGain) + '/month** (' + F.inr(bc.ltvSure - bc.ltvLegacy) + ' per customer × ' + F.num(Math.round(d.newBuyersPerMonth)) + ' buyers).');
w('- Total monthly value at stake: **' + F.lakh(leak.totalMonthlyValue) + '** (' + F.cr(leak.annualised) + ' a year) — ' + F.pct(leak.reliabilityLeak / K.revenue.now, 0) + ' of monthly revenue for the direct part alone.');
w('- Coupons issued and never redeemed (case §4): ' + F.lakh(leak.promoWaste) + '/month — a redeployment pool, not a saving.');
w('- The assumed-cost component of the leak is ' + F.lakh(leak.softAssumedCost) + '/month (refunds, rider minutes, substitution friction). Formula used: leak - half of the assumed costs = ' + F.lakh(leak.reliabilityLeakSoftHalf) + '/month.');
w('- Sensitivity: halving both soft assumptions (₹42 per refund/substitution event, ₹34 per late order) still leaves ' +
  F.lakh(leak.reliabilityLeak - 0.5 * (leak.lines[2].value + leak.lines[3].value + leak.lines[4].value)) + '/month.');

h1('3. Funnel simulation (Monte Carlo over the disclosed funnel)');
tbl(['', 'Today\'s failure mix', 'With NOVA SURE\'s failure mix'], [
  ['Failure mix (cancel/late/sub/ticket)', Object.keys(NC.BASE_MIX).map(k => F.pct(NC.BASE_MIX[k], 1)).join(' / '), Object.keys(bc.targetMix).map(k => F.pct(bc.targetMix[k], 1)).join(' / ')],
  ['Second order within 30 days', F.pct(bc.p2Legacy, 1), F.pct(bc.p2Sure, 1)],
  ['Lifetime orders per acquired customer', bc.ordersLegacy.toFixed(2), bc.ordersSure.toFixed(2)],
  ['Lifetime platform revenue per customer', F.inr(bc.ltvLegacy), F.inr(bc.ltvSure)],
  ['LTV : CAC', bc.ltvCacLegacy.toFixed(2) + ':1', bc.ltvCacSure.toFixed(2) + ':1'],
  ['Incremental lifetime revenue per monthly cohort', '—', '+' + F.inr(bc.cohortMonthlyGain)]
]);
w('Outcome multipliers used to convert an experience into a churn risk. They are normalised so that today\'s failure mix reproduces the disclosed 31% second-order rate — measured at **' + F.pct(bc.p2Legacy, 1) + '** on a 200,000-customer run (the residual is Monte Carlo noise of about ±0.1pp):');
w('');
w('`' + Object.keys(NC.OUTCOME_MULT).map(k => k + ' ×' + NC.OUTCOME_MULT[k]).join('  ·  ') + '`');
w('');
w('Order-level funnel frequencies used: `' + JSON.stringify(NC.FREQ) + '` (orders per customer per month by lifecycle stage).');

h1('4. Twelve-month scenarios (default: rollout coverage ' + F.pct(0.55, 0) + ')');
tbl(['', 'Plan C — do nothing', 'Plan A — +30% marketing', 'Plan B — NOVA SURE'], [
  ['Orders, month 6', F.num(S.C.m6.orders), F.num(S.A.m6.orders), F.num(S.B.m6.orders)],
  ['Orders, month 12', F.num(S.C.m12.orders), F.num(S.A.m12.orders), F.num(S.B.m12.orders)],
  ['Revenue, month 12', F.lakh(S.C.m12.revenue), F.lakh(S.A.m12.revenue), F.lakh(S.B.m12.revenue)],
  ['Marketing spend, month 12', F.lakh(S.C.m12.promo), F.lakh(S.A.m12.promo), F.lakh(S.B.m12.promo)],
  ['Tickets, month 12', F.num(S.C.m12.tickets), F.num(S.A.m12.tickets), F.num(S.B.m12.tickets)],
  ['Repeat rate, month 12', F.pct(S.C.m12.repeatRate, 1), F.pct(S.A.m12.repeatRate, 1), F.pct(S.B.m12.repeatRate, 1)],
  ['Δ monthly contribution, M6', F.lakh(S.C.m6.contribution), F.lakh(S.A.m6.contribution), F.lakh(S.B.m6.contribution)],
  ['Δ monthly contribution, M12', F.lakh(S.C.m12.contribution), F.lakh(S.A.m12.contribution), F.lakh(S.B.m12.contribution)],
  ['12-month cumulative Δ', F.lakh(S.C.cumulative12), F.lakh(S.A.cumulative12), F.lakh(S.B.cumulative12)],
  ['Programme spend', F.lakh(S.C.programSpent), F.lakh(S.A.programSpent), F.lakh(S.B.programSpent)],
  ['Cash payback', 'n/a', S.A.paybackMonth ? 'M' + S.A.paybackMonth : 'never', S.B.paybackMonth ? 'M' + S.B.paybackMonth : 'beyond M12']
]);
w('**Plan B − Plan A over 12 months: ' + F.lakh(S.B.cumulative12 - S.A.cumulative12) + '.**');
w('At month 12, Plan B is worth ' + F.lakh(S.B.m12.contribution - S.A.m12.contribution) + '/month more than Plan A, ' +
  'and ' + F.lakh(S.B.m12.contribution - S.C.m12.contribution) + '/month more than doing nothing — having already paid back the full ₹25L.');
w('');
w('All figures are **deltas against the month we are standing in** (revenue, promotional spend, failure-driven support/refund/rider/substitution costs, programme spend).');
w('No absolute profit is claimed anywhere, because NOVA CART\'s rider base pay, commission structure and technology costs are not disclosed.');

h1('5. With the ops console actually used (coverage ' + F.pct(Math.min(1, 0.55 + 0.45), 0) + ')');
const S2 = NC.scenarios(NC.DEFAULTS, 1.0);
tbl(['Plan B at full rollout', 'Value'], [
  ['Orders, month 6', F.num(S2.B.m6.orders)],
  ['Orders, month 12', F.num(S2.B.m12.orders)],
  ['Δ monthly contribution, M12', F.lakh(S2.B.m12.contribution)],
  ['12-month cumulative Δ', F.lakh(S2.B.cumulative12)],
  ['Cash payback', S2.B.paybackMonth ? 'month ' + S2.B.paybackMonth : 'beyond M12'],
  ['Repeat rate, month 12', F.pct(S2.B.m12.repeatRate, 1)]
]);

h1('6. Sensitivity — 6-month cumulative Δ contribution');
const sens = NC.sensitivity(NC.DEFAULTS, 0.55);
w('Rows: share of order volume on the fixed stack. Columns: marketing spend vs today.');
w('');
w('| Coverage ↓ / spend → | ' + sens.spends.map(s => s.toFixed(1) + '×').join(' | ') + ' |');
w('|' + '---|'.repeat(sens.spends.length + 1));
sens.grid.forEach((row, i) => w('| ' + (sens.lifts[i] * 100) + '% | ' + row.map(c => F.lakh(c.contribution6)).join(' | ') + ' |'));
w('');
w('Reading: at every coverage level, extra marketing spend lowers contribution (marginal ROAS ' + d.incrementalRoas.toFixed(2) + '×); at every spend level, coverage raises it.');

h1('7. Store-level data actually used by the app');
tbl(['Store', 'City', 'Category', 'Catalogue age', 'Cancels', 'Late', 'Sub', 'Reliability', 'Orders/mo', 'Exposure ₹/mo'],
  NC.rankStores('reliability').map(s => {
    const st = NC.storeStats(s);
    return [s.name, s.city, s.category, s.syncHours + ' h', F.pct(s.cancelRate, 1), F.pct(s.lateRate, 1), F.pct(s.subRate, 1), String(s.reliability), F.num(s.monthlyOrders), F.inr(st.exposure)];
  }));
w('The store-level rates are calibrated so that the order-weighted network averages reproduce the disclosed 11% / 13% / 8% exactly.');
w('');
w('Sample fidelity of the 400-order log the app reads (stratified so the disclosed rates are reproduced by construction):');
w('');
tbl(['Outcome', 'Sample', 'Case pack'], [
  ['Cancelled', F.pct(NC.orderSampleStats.cancelRate, 1), '11%'],
  ['Late > 15 min', F.pct(NC.orderSampleStats.lateRate, 1), '13%'],
  ['Contained a substitute', F.pct(NC.orderSampleStats.subRate, 1), '8%'],
  ['Raised a support ticket', F.pct(NC.orderSampleStats.ticketRate, 1), '15.3% (5,900 ÷ 38,500)'],
  ['Delivered within ±15 min of the promise', F.pct(NC.orderSampleStats.promiseKeptRate, 1), 'not disclosed — the case gives lateness only']
]);

h1('8. The promise engine, on a real basket');
const store = NC.storeById('ST01');
const cart = [{ skuId: 'SKU04', qty: 2 }, { skuId: 'SKU01', qty: 1 }, { skuId: 'SKU17', qty: 1 }, { skuId: 'SKU03', qty: 1 }];
const p = NC.promise(store, cart, {});
tbl(['', 'Today\'s promise', 'NOVA SURE'], [
  ['Advertised time', p.legacy.promise + ' min', 'best case ' + (p.smart.promise - 6) + ' min · promised ' + p.smart.promise + ' min'],
  ['Honest central estimate', p.central + ' min (± ' + p.sigma + ' min)', p.central + ' min (± ' + p.smart.sigma + ' min)'],
  ['Probability of arriving >15 min late', F.pct(p.legacy.late15, 1), F.pct(p.smart.late15, 1)],
  ['Probability of landing within ±5 min', F.pct(p.legacy.kept, 0), F.pct(p.smart.kept, 0)]
]);
w('Store: ' + store.name + ' (' + store.city + ', catalogue age ' + store.syncHours + ' h, reliability score ' + store.reliability + ').');
w('Basket: ' + cart.map(l => l.qty + ' × ' + NC.skuById(l.skuId).name).join(', ') + ' = ₹' + F.num(p.value) + '.');
w('');
w('On this basket the same store promises ' + p.legacy.promise + ' minutes if we keep today\'s flat promise, and misses by more than 15 minutes ' +
  F.pct(p.legacy.late15, 1) + ' of the time. Saying ' + p.smart.promise + ' minutes — four minutes longer, argued from the store\'s own ' +
  'reliability, catalogue age and prep-time data — cuts that miss rate to ' + F.pct(p.smart.late15, 1) + '.');

h1('9. Intervention queue (generated from live store data)');
const q = NC.interventionQueue();
w('Total monthly value in the queue: **' + F.lakh(q.totalMonthly) + '** across ' + q.length + ' actions, of which ' + F.lakh(q.totalLifetime) + ' is repeat-purchase value.');
w('Each action\'s gain is recomputed on the world *after* the actions above it, so applying the queue top-down shows diminishing returns.');
w('The Ops console applies actions one tap at a time; free-running it over the top 20 actions moves the direct leak from ₹10.03L to ₹8.74L (a top-20 gain of ₹1.69L/month) (see tests/run_engine.js).');
w('');
tbl(['#', 'Store', 'Action', '₹/month', 'Effort'],
  q.slice(0, 10).map(x => [x.rank, x.storeName, x.label, F.inr(x.gain), '●'.repeat(x.effort)]));

h1('10. Copilot sanity check');
['Is NOVA CART getting better or just bigger?', 'What is unreliable fulfilment costing us every month?',
 'Should we increase marketing spend by another 30%?', 'Is inventory accuracy really the bottleneck, or is it delivery?',
 'If we could build only one product, what should it be?'].forEach(question => {
  const a = NC.copilot(question);
  w('**Q: ' + question + '**');
  w('');
  w('> **' + a.headline + '**');
  w('');
  a.evidence.slice(0, 3).forEach(e => w('- ' + e));
  w('');
  w('*Method: ' + a.method + ' · Confidence: ' + a.confidence + '*');
  w('');
});

h1('11. Calibration anchors (all adjustable in the app)');
tbl(['Parameter', 'Value', 'Source / role'], [
  ['monthlyRetention', NC.DEFAULTS.monthlyRetention, 'aggregate monthly retention of the returning base; calibrated so the model reproduces 38,500 orders from today\'s inflow. The disclosed 72% applies only to the 3+ order tier.'],
  ['loyaltyMonths', NC.DEFAULTS.loyaltyMonths, 'months an established customer keeps ordering; calibrated so lifetime orders per acquired customer are consistent with the observed order/new-buyer ratio'],
  ['retentionResponse', NC.DEFAULTS.retentionResponse, 'share of base churn removed at full rollout (assumption)'],
  ['reliabilityShare', NC.DEFAULTS.reliabilityShare, 'share of the 41%→27% repeat collapse attributed to reliability rather than acquisition mix (assumption, 60/40)'],
  ['secondOrder30d', NC.DEFAULTS.secondOrder30d, 'case §4: 31%'],
  ['thirdOrderRepeat', NC.DEFAULTS.thirdOrderRepeat, 'case §4: 72%'],
  ['firstOrderConv', NC.DEFAULTS.firstOrderConv, 'case §4: 54%'],
  ['aov / takeRate', '₹' + NC.DEFAULTS.aov + ' / ' + F.pct(NC.DEFAULTS.takeRate, 2), 'disclosed'],
  ['ticketCost', '₹' + NC.CASE.support.ticketCost, 'assumption (₹75 per ticket)'],
  ['refundCost', '₹42 per refund/substitution event', 'assumption'],
  ['riderIdleCost', '₹34 per late order', 'assumption'],
  ['programmeCost', F.lakh(NC.CASE.budget.additionalImplementation), 'stated ceiling: ₹25 lakh'],
  ['programme phasing', NC.programPhase.map(p => F.pct(p, 0)).join(' / '), 'month 1 → month 6 spend split']
]);

fs.writeFileSync(path.join(__dirname, '..', 'EVIDENCE.md'), L.join('\n'), 'utf8');
console.log('wrote EVIDENCE.md —', L.length, 'lines');

/* the headline numbers, for quick reference in the terminal */
console.log('\nHEADLINES');
console.log('  incremental ROAS            ', d.incrementalRoas.toFixed(2) + '×');
console.log('  promo per incremental order ', F.inr(d.marginalPromoPerOrder) + ' spent -> ' + F.inr(d.marginalRevPerOrder) + ' earned (marginal; average rev/order is ' + F.inr(d.netRevPerOrder) + ')');
console.log('  repeat buyers               ', F.num(d.repeatCustPrior) + ' → ' + F.num(d.repeatCustNow));
console.log('  direct reliability leak     ', F.lakh(leak.reliabilityLeak) + '/mo = ' + F.cr(leak.annualisedDirect) + '/yr');
console.log('  LTV:CAC                     ', bc.ltvCacLegacy.toFixed(2) + ':1 → ' + bc.ltvCacSure.toFixed(2) + ':1');
console.log('  Plan B vs A (12 months)     ', F.lakh(S.B.cumulative12 - S.A.cumulative12));
console.log('  Plan B M12 run-rate vs today', F.lakh(S.B.m12.contribution) + '/mo   payback ' + (S.B.paybackMonth ? 'M' + S.B.paybackMonth : 'n/a'));
console.log('  Plan C (do nothing) 12-mo   ', F.lakh(S.C.cumulative12));
