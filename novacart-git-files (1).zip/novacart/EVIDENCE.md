# NOVA SURE — evidence pack (generated)

> Every figure below is produced by `tools/dump_numbers.js` from the same engine the
> application runs (`src/engine.js`). Nothing in the written submission is typed by hand.
> Regenerate with `node tools/dump_numbers.js`.

Generated: 2026-10-02 · order sample n=400 · stores 14 · SKUs 24

## 1. Derived from the case pack

| Metric | 6 months ago | Today | Change |
|---|---|---|---|
| Registered users | 82,000 | 1,20,000 | +46.3% |
| Monthly active users | 39,000 | 46,000 | +17.9% |
| Monthly orders | 31,200 | 38,500 | +23.4% |
| Average order value | ₹452 | ₹486 | +7.5% |
| Repeat purchase rate | 41% | 27% | -34.1% |
| Repeat buyers (absolute) | 33,620 | 32,400 | -1,220 |
| Average delivery time | 29 min | 37 min | +27.6% |
| Cancellation rate | 6% | 11% | +5 pts |
| Support tickets / month | 3,100 | 5,900 | +90.3% |
| Promotional spend / month | ₹9.50L | ₹17.00L | +78.9% |
| Revenue / month | ₹21.80L | ₹26.10L | +19.7% |

Derived (not disclosed, computed here):

| Derived metric | 6 months ago | Today |
|---|---|---|
| GMV at the disclosed AOV | ₹141.02L | ₹187.11L |
| Implied platform take rate (revenue ÷ GMV) | 15.46% | 13.95% |
| Promotional spend per order | ₹30 | ₹44 |
| Platform revenue per order | ₹70 | ₹68 |
| Promotions as a share of platform revenue | 43.6% | 65.1% |
| Support cost as a share of platform revenue | 10.7% | 17.0% |
| Tickets per 100 orders | 9.9 | 15.3 |
| Orders per monthly active user | 0.800 | 0.837 |

Headline economics of the last six months:

- Incremental revenue / incremental promotional spend = ₹4.30L / ₹7.50L = **0.57×** (blended 1.54×).
- Each of the 7,300 incremental monthly orders cost **₹103 of promotions** and added **₹59 of platform revenue**. Marginal-to-marginal: ₹59 / ₹103 = 0.573× — identical to ₹4.30L / ₹7.50L, as it must be.
- Deliberately **not** compared against today's *average* revenue per order (₹68). An average is not what the extra spend bought; mixing the two is the classic way to make a marginal-ROAS argument wrong.
- Cost per newly registered user: ₹20 up to ₹268 depending on whether all promo spend is charged to acquisition.
- Cost per first-order customer: ₹288 (58% acquisition-tagged spend ÷ 3,420 first orders a month).
- Lifetime platform revenue per acquired customer at today's experience mix: ₹390 → LTV:CAC **1.35:1** (healthy D2C benchmark: 3:1).
The repeat-buyer count, defined so a reviewer can check it. The case pack does not state the base the repeat rate is measured on, so it is given on all three plausible bases:

| Basis | 6 months ago | Today | Change |
|---|---|---|---|
| Registered users x repeat rate | 33,620 | 32,400 | -1,220 |
| Monthly active users x repeat rate | 15,990 | 12,420 | -3,570 |
| Orders x repeat rate | 12,792 | 10,395 | -2,397 |

The headline uses **registered users x repeat rate** — the most conservative of the three. Every basis falls, so the direction of the finding does not depend on which denominator the case pack had in mind.

ROAS, all three definitions side by side (the app quotes the first and shows the second as a bound):

| Definition | Value | What it compares |
|---|---|---|
| **Incremental ROAS (used everywhere)** | 0.573x | extra revenue (₹4.30L) / extra promo spend (₹7.50L) — the standard definition |
| Most generous reading | 0.660x | today's average revenue per order (₹68) / marginal promo per extra order (₹103) |
| Blended | 1.535x | total revenue / total promo spend |

All three are below 1. Whichever is chosen, the conclusion — the last six months of promotional spend did not pay for itself — is unchanged.


## 2. The reliability leak (monthly, at the disclosed rates)

| Leak line | Owner | ₹ / month | Evidence |
|---|---|---|---|
| Revenue lost on cancelled orders | Inventory accuracy | ₹2.87L | Case §5 order outcomes |
| Support cost caused by fulfilment failures | Support | ₹3.19L | Case §8 ticket mix |
| Refunds & goodwill compensations | Refunds | ₹0.97L | Case §5 · ₹42 per case assumed |
| Rider minutes burnt on re-tries and waits | Delivery | ₹1.70L | Case §5 · ₹34 per case assumed |
| Substitution friction (calls, swaps, comps) | Store ops | ₹1.29L | Case §5 · ₹42 per case assumed |

**Direct reliability leak: ₹10.03L / month = ₹1.20cr a year.**

- Lifetime revenue lost from one month's acquired cohort: **₹1.09L/month** (₹32 per customer × 3,420 buyers).
- Total monthly value at stake: **₹11.12L** (₹1.33cr a year) — 38% of monthly revenue for the direct part alone.
- Coupons issued and never redeemed (case §4): ₹7.48L/month — a redeployment pool, not a saving.
- The assumed-cost component of the leak is ₹3.97L/month (refunds, rider minutes, substitution friction). Formula used: leak - half of the assumed costs = ₹8.05L/month.
- Sensitivity: halving both soft assumptions (₹42 per refund/substitution event, ₹34 per late order) still leaves ₹8.05L/month.

## 3. Funnel simulation (Monte Carlo over the disclosed funnel)

|  | Today's failure mix | With NOVA SURE's failure mix |
|---|---|---|
| Failure mix (cancel/late/sub/ticket) | 11.0% / 13.0% / 8.0% / 15.3% | 6.0% / 3.5% / 4.0% / 10.5% |
| Second order within 30 days | 31.0% | 34.8% |
| Lifetime orders per acquired customer | 5.75 | 6.22 |
| Lifetime platform revenue per customer | ₹390 | ₹421 |
| LTV : CAC | 1.35:1 | 1.46:1 |
| Incremental lifetime revenue per monthly cohort | — | +₹1,08,874 |

Outcome multipliers used to convert an experience into a churn risk. They are normalised so that today's failure mix reproduces the disclosed 31% second-order rate — measured at **31.0%** on a 200,000-customer run (the residual is Monte Carlo noise of about ±0.1pp):

`clean ×1.15  ·  late ×0.72  ·  substituted ×0.86  ·  cancelled ×0.45  ·  compensated ×0.58`

Order-level funnel frequencies used: `{"m1":1,"m2":1.3,"m3":1.6,"m3plus":1.64}` (orders per customer per month by lifecycle stage).

## 4. Twelve-month scenarios (default: rollout coverage 55%)

|  | Plan C — do nothing | Plan A — +30% marketing | Plan B — NOVA SURE |
|---|---|---|---|
| Orders, month 6 | 37,225 | 39,866 | 39,761 |
| Orders, month 12 | 36,309 | 40,731 | 40,644 |
| Revenue, month 12 | ₹24.62L | ₹26.53L | ₹27.85L |
| Marketing spend, month 12 | ₹17.00L | ₹22.10L | ₹17.00L |
| Tickets, month 12 | 5,573 | 6,252 | 5,032 |
| Repeat rate, month 12 | 27.0% | 27.0% | 31.6% |
| Δ monthly contribution, M6 | ₹-0.83L | ₹-5.86L | ₹-0.69L |
| Δ monthly contribution, M12 | ₹-1.18L | ₹-5.55L | ₹3.72L |
| 12-month cumulative Δ | ₹-10.10L | ₹-67.74L | ₹10.33L |
| Programme spend | ₹0.00L | ₹0.00L | ₹25.00L |
| Cash payback | n/a | never | M10 |

**Plan B − Plan A over 12 months: ₹78.07L.**
At month 12, Plan B is worth ₹9.27L/month more than Plan A, and ₹4.90L/month more than doing nothing — having already paid back the full ₹25L.

All figures are **deltas against the month we are standing in** (revenue, promotional spend, failure-driven support/refund/rider/substitution costs, programme spend).
No absolute profit is claimed anywhere, because NOVA CART's rider base pay, commission structure and technology costs are not disclosed.

## 5. With the ops console actually used (coverage 100%)

| Plan B at full rollout | Value |
|---|---|
| Orders, month 6 | 41,939 |
| Orders, month 12 | 44,521 |
| Δ monthly contribution, M12 | ₹8.18L |
| 12-month cumulative Δ | ₹49.21L |
| Cash payback | month 5 |
| Repeat rate, month 12 | 35.4% |


## 6. Sensitivity — 6-month cumulative Δ contribution

Rows: share of order volume on the fixed stack. Columns: marketing spend vs today.

| Coverage ↓ / spend → | 0.9× | 1.0× | 1.1× | 1.2× | 1.3× |
|---|---|---|---|---|---|
| 0% | ₹-19.14L | ₹-27.36L | ₹-35.62L | ₹-43.89L | ₹-52.19L |
| 25% | ₹-11.98L | ₹-20.09L | ₹-28.23L | ₹-36.39L | ₹-44.57L |
| 50% | ₹-4.57L | ₹-12.55L | ₹-20.57L | ₹-28.61L | ₹-36.67L |
| 75% | ₹3.11L | ₹-4.74L | ₹-12.63L | ₹-20.54L | ₹-28.48L |
| 100% | ₹11.06L | ₹3.35L | ₹-4.40L | ₹-12.18L | ₹-19.99L |

Reading: at every coverage level, extra marketing spend lowers contribution (marginal ROAS 0.57×); at every spend level, coverage raises it.

## 7. Store-level data actually used by the app

| Store | City | Category | Catalogue age | Cancels | Late | Sub | Reliability | Orders/mo | Exposure ₹/mo |
|---|---|---|---|---|---|---|---|---|---|
| Vidya Book Depot | Warangal | Stationery | 48 h | 26.4% | 27.2% | 18.0% | 38 | 1,100 | ₹32,514 |
| Sai Stationers | Nizamabad | Stationery | 36 h | 24.5% | 24.6% | 16.1% | 46 | 900 | ₹24,655 |
| Prime Stationery Hub | Hyderabad | Stationery | 26 h | 22.3% | 22.4% | 15.0% | 46 | 1,600 | ₹40,466 |
| Green Basket Veggies | Warangal | Grocery | 12 h | 20.0% | 20.6% | 10.9% | 65 | 1,400 | ₹30,846 |
| Sri Chaitanya Medicals | Warangal | Pharmacy | 8 h | 16.5% | 16.9% | 11.0% | 69 | 2,300 | ₹44,473 |
| Amma Home Foods | Warangal | Bakery | 5 h | 12.0% | 12.8% | 9.3% | 80 | 1,500 | ₹22,771 |
| Asha Pharmacy | Hyderabad | Pharmacy | 4 h | 11.4% | 13.5% | 7.8% | 81 | 2,800 | ₹39,602 |
| Ganesh Medicals | Nizamabad | Pharmacy | 3 h | 9.4% | 10.9% | 6.7% | 84 | 2,600 | ₹31,340 |
| Warangal Grocery Mart | Warangal | Grocery | 2 h | 8.8% | 11.6% | 6.3% | 92 | 3,400 | ₹38,958 |
| FreshFields Organics | Hyderabad | Grocery | 2 h | 8.1% | 10.3% | 6.5% | 92 | 2,400 | ₹26,424 |
| Nizam Bakers | Nizamabad | Bakery | 1.5 h | 7.3% | 13.7% | 7.6% | 93 | 2,100 | ₹23,256 |
| Sri Balaji Kirana & General | Nizamabad | Grocery | 0.5 h | 7.8% | 10.1% | 5.5% | 94 | 4,200 | ₹43,251 |
| Koti Super Bazaar | Hyderabad | Grocery | 1 h | 7.3% | 8.7% | 6.0% | 95 | 5,200 | ₹52,138 |
| Baker's Street | Hyderabad | Bakery | 1 h | 6.1% | 9.3% | 5.6% | 96 | 3,200 | ₹29,113 |

The store-level rates are calibrated so that the order-weighted network averages reproduce the disclosed 11% / 13% / 8% exactly.

Sample fidelity of the 400-order log the app reads (stratified so the disclosed rates are reproduced by construction):

| Outcome | Sample | Case pack |
|---|---|---|
| Cancelled | 11.0% | 11% |
| Late > 15 min | 13.0% | 13% |
| Contained a substitute | 8.0% | 8% |
| Raised a support ticket | 15.3% | 15.3% (5,900 ÷ 38,500) |
| Delivered within ±15 min of the promise | 76.0% | not disclosed — the case gives lateness only |


## 8. The promise engine, on a real basket

|  | Today's promise | NOVA SURE |
|---|---|---|
| Advertised time | 28 min | best case 26 min · promised 32 min |
| Honest central estimate | 34 min (± 8 min) | 34 min (± 5.8 min) |
| Probability of arriving >15 min late | 13.7% | 1.3% |
| Probability of landing within ±5 min | 44% | 68% |

Store: Sri Balaji Kirana & General (Nizamabad, catalogue age 0.5 h, reliability score 94).
Basket: 2 × Amul Taaza Milk 500ml, 1 × Aashirvaad Atta 5kg, 1 × Milk Bread 400g, 1 × Tata Salt 1kg = ₹412.

On this basket the same store promises 28 minutes if we keep today's flat promise, and misses by more than 15 minutes 13.7% of the time. Saying 32 minutes — four minutes longer, argued from the store's own reliability, catalogue age and prep-time data — cuts that miss rate to 1.3%.

## 9. Intervention queue (generated from live store data)

Total monthly value in the queue: **₹2.14L** across 32 actions, of which ₹0.22L is repeat-purchase value.
Each action's gain is recomputed on the world *after* the actions above it, so applying the queue top-down shows diminishing returns.
The Ops console applies actions one tap at a time; free-running it over the top 20 actions moves the direct leak from ₹10.03L to ₹8.74L (a top-20 gain of ₹1.69L/month) (see tests/run_engine.js).

| # | Store | Action | ₹/month | Effort |
|---|---|---|---|---|
| 1 | Prime Stationery Hub | Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day | ₹21,138 | ● |
| 2 | Sri Chaitanya Medicals | Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day | ₹20,241 | ● |
| 3 | Vidya Book Depot | Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day | ₹18,225 | ● |
| 4 | Green Basket Veggies | Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day | ₹14,028 | ● |
| 5 | Sai Stationers | Enable NOVA SURE Sync — store verifies its list in 15 seconds, twice a day | ₹12,906 | ● |
| 6 | Sri Chaitanya Medicals | Availability-gate the riskiest SKUs until the store verifies them | ₹10,384 | ● |
| 7 | Prime Stationery Hub | Availability-gate the riskiest SKUs until the store verifies them | ₹8,615 | ● |
| 8 | Sri Balaji Kirana & General | Turn on the pre-peak stock nudge — 3 SKUs likely to run out this evening | ₹8,117 | ● |
| 9 | Green Basket Veggies | Availability-gate the riskiest SKUs until the store verifies them | ₹7,270 | ● |
| 10 | Warangal Grocery Mart | Turn on the pre-peak stock nudge — 3 SKUs likely to run out this evening | ₹7,245 | ● |


## 10. Copilot sanity check

**Q: Is NOVA CART getting better or just bigger?**

> **Bigger, and worse on every quality axis that predicts repeat purchase.**

- Orders 31,200 → 38,500 (+23.4%); revenue ₹21.80L → ₹26.10L (+19.7%)
- Promotional spend ₹9.50L → ₹17.00L (+78.9%) — spend grew 4.0× faster than revenue
- Repeat 41% → 27% · delivery 29 → 37 min · cancellation 6% → 11% · tickets 3,100 → 5,900

*Method: Case-pack figures. Repeat buyers are defined as registered users x repeat purchase rate — the most conservative of the three possible bases (MAU x rate and orders x rate both fall by more), which is why the count is quoted as a floor rather than a point estimate. · Confidence: High — this is arithmetic, not inference.*

**Q: What is unreliable fulfilment costing us every month?**

> **₹10.03L/month of direct leak, on top of ₹1.09L/month of lifetime revenue lost from each new cohort.**

- Revenue lost on cancelled orders — ₹2.87L (4,235 orders/mo · 11.0% of demand)
- Support cost caused by fulfilment failures — ₹3.19L (5,910 tickets/mo · 72% are refund, delay or missing-item)
- Refunds & goodwill compensations — ₹0.97L (6% of orders need a refund or a support fix, ~₹42 of compensation each)

*Method: Leak = cancelled-order revenue + failure-driven support + refunds + wasted rider minutes + substitution friction. Cohort value comes from the Monte Carlo funnel, not from a rule of thumb. · Confidence: Medium-high. Order-level rates are disclosed; ₹42 refund and ₹34 rider-minute costs are stated assumptions and can be replaced in one line.*

**Q: Should we increase marketing spend by another 30%?**

> **No. Every incremental order bought in the last six months cost more than it earned.**

- Incremental promo spend ₹7.50L/mo bought 7,300 incremental orders = ₹103 of promo per EXTRA order, and those extra orders added ₹59 of platform revenue each. (Today's average revenue per order is ₹68 — an average is not what the extra spend bought. Marginal-to-marginal is the like-for-like comparison: 59 / 103 = 0.57x.)
- ROAS, one definition: extra revenue / extra spend = 0.57×. Even on the most generous reading — today's *average* revenue per order divided by the marginal promo cost of an extra order (₹68 / ₹103) — it is 0.66×. Blended, the whole business runs at 1.54×. All three are below 1, so the conclusion survives any of them.
- The experiment has already run: +38,000 registered users and 1,220 fewer repeat buyers.

*Method: Marginal ROAS, promo-per-order and repeat-buyer count come straight from the disclosed six-month numbers; LTV comes from the funnel simulation. · Confidence: High on the marginal ROAS; medium on the absolute LTV level.*

**Q: Is inventory accuracy really the bottleneck, or is it delivery?**

> **Inventory accuracy — because it is upstream of the cancellations and of the delay.**

- 35% of cancellations are "product unavailable" and 18% more are the store rejecting the order — 53% of cancellations start as a stock record that was wrong.
- 29% of surveyed customers were shown stock that did not exist; 19% repeatedly search for products no nearby store carries.
- Partner stores refresh the catalogue anywhere between 4× a day and once every 2 days. A 36-hour-old stock number is not a fact.

*Method: Cancellation-reason mix + customer survey + disclosed partner sync behaviour, cross-checked against published inventory-record-accuracy research. · Confidence: High on the mechanism; the size of the effect is proven store by store in the Store app.*

**Q: If we could build only one product, what should it be?**

> **NOVA SURE — an availability-and-promise layer that sits on top of the systems NOVA CART already owns.**

- It attacks one shared cause: 53% of cancellations (stock records that were wrong), 27% more (delay-driven cancellations) and the 29% of customers shown stock that did not exist.
- No warehouses, no new headcount at scale — a reliability layer over the existing customer app, partner dashboard and order database.
- The ₹25L budget covers the build once; the direct leak it removes is ₹10.03L/month before counting the ₹1.09L/month of lifetime revenue it protects.

*Method: Cross-checked against every symptom in the case pack: survey, funnel, operations, partner, support and finance. · Confidence: High.*


## 11. Calibration anchors (all adjustable in the app)

| Parameter | Value | Source / role |
|---|---|---|
| monthlyRetention | 0.947 | aggregate monthly retention of the returning base; calibrated so the model reproduces 38,500 orders from today's inflow. The disclosed 72% applies only to the 3+ order tier. |
| loyaltyMonths | 12 | months an established customer keeps ordering; calibrated so lifetime orders per acquired customer are consistent with the observed order/new-buyer ratio |
| retentionResponse | 0.25 | share of base churn removed at full rollout (assumption) |
| reliabilityShare | 0.6 | share of the 41%→27% repeat collapse attributed to reliability rather than acquisition mix (assumption, 60/40) |
| secondOrder30d | 0.31 | case §4: 31% |
| thirdOrderRepeat | 0.72 | case §4: 72% |
| firstOrderConv | 0.54 | case §4: 54% |
| aov / takeRate | ₹486 / 13.95% | disclosed |
| ticketCost | ₹75 | assumption (₹75 per ticket) |
| refundCost | ₹42 per refund/substitution event | assumption |
| riderIdleCost | ₹34 per late order | assumption |
| programmeCost | ₹25.00L | stated ceiling: ₹25 lakh |
| programme phasing | 10% / 16% / 20% / 20% / 18% / 16% | month 1 → month 6 spend split |
