# 3 · Solution Explanation

> **NOVA SURE is an availability-and-promise layer that sits on top of the systems NOVA CART already owns.**
> It verifies what a nearby store actually has, quotes a delivery time that the store's own data supports, and turns the resulting failures into one-tap interventions for the people who can fix them.

Positioning, in one line: **not "10 minutes" — "verified nearby."**

The design principle that everything else follows from: **verification beats prediction.** NOVA CART does not have a forecasting problem it can solve with a model; it has a truth problem it can solve by asking a shopkeeper a question with three possible answers. Everything in the prototype exists to move one verified fact to the exact moment a promise is made.

---

## 1 · Who it is for, and what they get

| User | Their problem today | What NOVA SURE gives them |
|---|---|---|
| **The customer** | Orders a basket that the store may not have; gets a 10-minute promise the network cannot keep; if it goes wrong, spends 9.2 hours chasing a refund | An honest delivery window, unverified items flagged *before* the order is placed, substitutes prepared in advance, and a failure that resolves itself instead of becoming homework |
| **The partner store** | 39% say catalogue upkeep costs too much effort; 28% cannot predict online sales; 23% reject orders when busy; 18% are considering leaving | A 15-second, three-button stock check twice a day — no counts, no scanning, no integration. Pre-peak nudges that tell them what to stock, and a capacity cap they can set so busy periods stop turning into cancellations |
| **The category / ops manager** | Six systems, no single view of what is leaking money, and nothing they can do about it during a shift | The leak map by owner, the store league table by exposure, and a ranked intervention queue they apply with one tap and watch move the number |
| **Management** | Six seats, six different readings of the same six months | One deterministic copilot that answers the disputed questions from the same numbers, and a Decision Room where the disagreement is expressed as sliders instead of opinions |

## 2 · Why this addresses the diagnosis — mechanism by mechanism

| Diagnosis | Mechanism | Where it lives in the product |
|---|---|---|
| The promise is made before the shelf is checked | **Availability gate.** Every SKU carries a scored availability with a band, a freshness label, a confidence level and the drivers behind it; unverified items are shown as unverified, not as available | Customer app, shelf and basket (`NC.availability`) |
| 35% of cancellations are product-unavailable | **Verification.** One tap sets a SKU's state and writes it into the world: catalogue age drops to 30 minutes, the store's cancel and substitute rates fall, reliability rises, and that SKU's availability score gains +6 with the driver "Verified by the store just now" | Store app (`NC.storeSync`) |
| 13% of orders are >15 minutes late | **Honest promise.** The promised time is derived from the store's own prep/dispatch/reliability distribution with a variance-scaled buffer; the customer sees the honesty window, not just a number | Customer app, promise step (`NC.promise`) |
| 8% of orders contain a substitute, unprepared | **Substitution SOP.** The highest-probability swaps for that store are pushed in advance with a two-tap acceptance flow, so a swap is a choice, not a surprise | Store app / intervention queue |
| 5,900 tickets, 9.2-hour resolution, 29% refund status | **Recovery as prevention.** Failures are cut at the source, and the console makes the remaining ones visible with their owner and their cost, so support stops being the place where the company meets its own mistakes | Ops Trust Console; intervention queue |
| Repeat 41% → 27%, 1,220 fewer repeat buyers (registered × repeat rate) | **Retention by reliability.** Every failure mode with a measured churn multiplier is cut; the model then reports repeat rate, orders and revenue as a consequence — not a media plan | Decision Room (`NC.scenarios`) |
| 18% of partners considering leaving | **Partner effort as a first-class constraint.** Verification is designed to take fifteen seconds, and the queue includes churn-risk partner calls | Store app; intervention queue |
| Management disagrees about what to fix | **One arithmetic.** Leak map, plans and copilot all draw on the same deterministic engine; the disagreement becomes a parameter | Copilot; Decision Room |

## 3 · How the prototype works, end to end

**Input → logic → output**, for the core journey:

1. **Input.** City, store, basket. A store's shelf state is whatever its last verification said; anything unverified carries its catalogue age.
2. **Logic — availability.** `NC.availability(store, sku)` starts from the store's composite score adjustment (catalogue age, reliability, cancellation behaviour), subtracts for thin stock and for that item's own failure history at that store, caps the result, and labels it with a band, a confidence level, a freshness string and the exact drivers. A fresh verification overrides: +6 and "Verified by the store just now".
3. **Logic — routing and substitution.** `NC.routeBasket()` decides per line whether to sell, substitute, move to a different nearby store, or gate; it returns the plan, the risk removed, and the change in expected cancellation.
4. **Logic — the promise.** `NC.promise()` builds a per-store distribution over central time and sigma from prep, dispatch and reliability, then reports the flat-promise miss rate against the honest one. On Vidya Book Depot, Nizamabad: flat promise 50 minutes with a 17.6% chance of >15 minutes late; NOVA SURE says 54 minutes and cuts that to 3.0% — and after the store verifies its list, to **1.3%**.
5. **Output — to the customer.** An honest window, the flagged items with reasons, the prepared swaps, and (on request) a 1,000-order Monte Carlo of the very basket they are buying, showing late and kept rates before and after.
6. **Output — to operations.** The same event, aggregated: the leak line it belongs to, the store it came from, the action that removes it, its ₹/month value, and the effort — one tap to apply, and the leak bar moves.

**World model.** The prototype carries one explicit mutable world (`NC.world`) with shelf state, verification records, applied interventions and logged outcomes. `NC.storeSync()` and `NC.dispatch('apply')` mutate it; `NC.leakMap()`, `NC.coverageFromWorld()`, `NC.interventionQueue()` and the plans all read from it. That is why the numbers move on screen when the user acts — the application is not replaying a prepared animation, it is recomputing from the changed state.

**Determinism.** A fixed seed (`20260202`) drives every stochastic element, and the same files run in the browser and in Node. `tools/dump_numbers.js` writes `EVIDENCE.md` from that same engine — so the written submission cannot claim anything the application does not compute.

## 4 · What we deliberately did not build

| Not built | Why |
|---|---|
| A demand-forecasting model | The failure is not that NOVA CART cannot predict demand; it is that it does not know today's shelf. A forecast on top of unverified inventory would add confidence without adding truth. |
| A dark-store or 10-minute promise | Outside the ₹25L ceiling and the brief's infrastructure constraint; the market leaders already own that race, and NOVA CART's asset is 620 stores that are genuinely close. |
| Another discount or loyalty programme | Reproducing the last six months as a plan costs ₹67.74L over twelve months and leaves repeat rate at 27.0%. |
| A customer-facing chatbot | The customer does not need conversation; they need the right promise, the right items, and no reason to contact support. The copilot is for the people making decisions. |
| A new rider fleet or workforce expansion | Excluded by the brief, and it addresses delay, not the availability that causes both delay and cancellation. |
| A black-box "AI prediction" of which orders will fail | The engine's leak map, availability scores and interventions are all rule-based and inspectable, because they end in money and in a shopkeeper's actions. Explainability was a design requirement, not a feature. |

## 5 · How ₹25L is spent, and what each phase must prove

Programme cost ₹25,00,000 over six months, phased 10 / 16 / 20 / 20 / 18 / 16%, with a gate at each phase. Nothing here requires new physical infrastructure, hundreds of new employees, or a discount.

| Phase | Spend | Buys | Gate to the next phase |
|---|---|---|---|
| M1 | ₹2.5L | Instrumentation: link `order_id` → store `last_verified_at` → coded cancellation reason → first-resolution time → next order date. Calibrate the promise engine against four weeks of real prep/dispatch data in the two worst-performing city cohorts | Reconciled leak map; promise model error within ±15% |
| M2 | ₹4.0L | Partner sync app in the pilot cohort (~120 stores in the two worst cohorts): three-button check, reminders, field support | ≥60% of pilot stores completing two verifications a day |
| M3 | ₹5.0L | Customer-side availability gate and honest promise live in the pilot cities; prepared substitutions | Cancellations on unverified SKUs down ≥25% vs control stores |
| M4 | ₹5.0L | Ops Trust Console: leak map, league table, ranked queue, one-tap apply; refund-status visibility into support | ≥50% of queued interventions actioned; failure-driven ticket share falling |
| M5 | ₹4.5L | Scale to the remaining cities and store cohorts; pre-peak nudges; partner capacity caps | Verified-store cancellations and lateness within target bands at 620-store volume |
| M6 | ₹4.0L | Copilot and Decision Room as standing management instruments; audit of promise accuracy vs actual delivery | Promise kept rate ≥90% network-wide; repeat rate trending up for two consecutive months |

Budget ceiling: the case pack states ₹25 lakh for the next six months; the model uses exactly that, and payback lands at **month 10** at 55% rollout — **month 5** if the ops console is used to full coverage, because the console needs no customer behaviour change to start paying.

## 6 · Prototype versus production

Honest about the seam:

- **Real in the prototype:** the case-pack data, the derived economics, the leak map, the store-level model (calibrated so the weighted averages reproduce the disclosed 11% / 13% / 8% exactly), the promise engine, the availability gate, the verification mechanic, the intervention queue, the 12-month plans, the sensitivity analysis and the copilot's answers. Every number on screen is computed, not printed.
- **Simulated in the prototype:** the partner stores' shelves and the 400-order sample log are generated from the case pack's disclosed rates (a fidelity fixture, stratified so the rates reproduce exactly), because the case pack does not publish store-level data. The world responds to actions the way the model says it should; in production those responses would be measured from live orders.
- **Would be wired in production:** order events from the existing OMS; store confirmation at checkout (the partner app replacing a phone call); rider ETA signals from the delivery app; ticket and refund events from support; the same engine, fed by real streams. No new physical infrastructure, no paid APIs, no custom ML training — the case pack's technology constraint is met by construction.
