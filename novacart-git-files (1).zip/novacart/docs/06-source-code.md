# 6 · Source Code

The repository **is** the submission: one self-contained application, its source, its tests, and the generator that keeps the written report and the running code in agreement.

## Layout

```
novacart/
├── index.html              ← BUILD OUTPUT: the whole app, one file, 186 KB, zero dependencies
├── demo.html               ← BUILD OUTPUT: the scripted 3-minute walkthrough
├── DEPLOY.md               ← GitHub Pages / Vercel / anywhere
├── SUBMISSION.md           ← the seven deliverables, indexed
├── EVIDENCE.md             ← every number quoted in the submission, generated from the engine
├── README.md               ← how to run, how to verify, how it is built, honesty notes
├── docs/
│   ├── 01-problem-diagnosis.md
│   ├── 02-prompt-journey.md
│   ├── 03-solution-explanation.md
│   ├── 04-demo-script.md
│   ├── 05-business-impact.md
│   └── 06-source-code.md   ← this file
├── src/
│   ├── data.js             ← case pack, 14 stores across 3 cities, 24-SKU catalogue, 400-order sample
│   ├── engine.js           ← the deterministic model (economics, leak map, promise, availability,
│   │                          verification, routing, Monte Carlo, plans, sensitivity, queue, copilot)
│   ├── ui.js               ← six surfaces as pure HTML-string functions + one dispatcher + one state
│   ├── styles.css          ← the stylesheet (no external fonts, images or stylesheets)
│   └── shell.html          ← HTML skeleton with /*{{STYLES}}*/ and /*{{SCRIPTS}}*/ placeholders
├── tools/
│   ├── build.py            ← inlines shell + styles + data + engine + ui → index.html
│   └── dump_numbers.js     ← generates EVIDENCE.md from the same engine the app runs
└── tests/
    ├── smoke_ui.js         ← 120 checks: every view/city/store/step/state, XSS escaping (user text and
    │                          data strings), memo cache, Monte-Carlo bound, warm-render budget, debounce
    ├── demo_path.js        ← 33 checks: walks docs/04 and asserts what each screen shows
    ├── smoke_demo.js       ← 55 checks: every scene of demo.html, determinism and rewind
    ├── check_docs.js       ← 181 checks: every figure in the written pack against the engine
    └── run_engine.js       ← model invariants (funnel fidelity, leak map, plans, queue, copilot)
                               + code hygiene: engine has no DOM, build output is bounded, no keys
```

## Run, build, verify

```bash
# the application — just open the file; no server, no install, no API keys, no network
open index.html                     # (or double-click it)

# checks (Node 18+, no dependencies)
node tests/smoke_ui.js              # 120 checks, exits non-zero on failure
node tests/demo_path.js             # walks the demo script and asserts what each screen shows
node tests/smoke_demo.js            # every scene of the backup walkthrough
node tests/check_docs.js            # every doc figure against the engine
node tests/run_engine.js            # model + code-hygiene assertions, and prints the economics
node tools/dump_numbers.js          # regenerates EVIDENCE.md from the engine
python3 tools/build.py              # rebuilds index.html from src/
```

## Separation of model and views (checked by a test)

| Layer | File | Owns |
|---|---|---|
| Model | `src/engine.js` | every formula and every number the app shows — no DOM, no I/O |
| Data | `src/data.js` | the case pack, derived figures, calibrated store data |
| Views | `src/ui.js` | HTML strings only — it renders the model, it never computes it |
| Shell | `src/shell.html` | delegated events, paint, debounced slider handling |

`tests/run_engine.js` asserts the boundary (`engine.js is model-only`, `index.html loads nothing external`, `no API keys … in the repo`) rather than trusting convention, and `tests/smoke_ui.js` covers escaping, caching, the Monte-Carlo bound, a warm-render time budget and debounce behaviour.

## Engineering notes

- **One language, two runtimes.** `src/*.js` are plain ES5 IIFEs attached to a single global, `NC`. The same files run inlined in the browser and under `require()` in Node — which is why the report (`EVIDENCE.md`) and the prototype can never disagree.
- **Deterministic.** Fixed seed `20260202`. Every stochastic path (the 400-order sample, the 15,000-run Monte Carlo) reproduces exactly.
- **No framework, no build step beyond concatenation.** `tools/build.py` inlines the stylesheet and the three scripts into the shell. It escapes `</script>` sequences inside JS and reports the size and line count of the artefact it writes.
- **The UI is a pure function of state.** `NC.APP = {tab, city, storeId, cart, step, plan, promise, asked, question, sensitivity}`; a single delegated listener routes clicks, inputs, keys and submits into `NC.dispatch()`, and `NC.renderApp()` redraws. Rendering is a pure string operation, which is what makes the 104-check headless harness possible.
- **The world is explicit and mutable.** `NC.world` holds shelf state, verification records, applied interventions and logged outcomes; `NC.resetWorld()` restores the baseline. Every figure the Ops console displays is recomputed from that world after each action — the numbers move because the state changed, not because an animation was authored.
- **Nothing external.** No CDN, no font, no image request, no analytics, no network call of any kind — the prototype runs identically offline and inside a sandboxed iframe. This is also why the demo cannot fail on conference Wi-Fi.
- **Security-relevant behaviour is minimal by construction.** No network calls, no storage, no credentials; user-typed text is escaped before it reaches `innerHTML`, with five injection payloads asserted in the test suite. `README.md` states precisely what was and was not done here.
- **Every assumption is a named parameter.** Calibration constants (retention, frequency, outcome multipliers) and soft costs (₹42 / ₹34 / ₹75) live in one defaults object, are disclosed in `EVIDENCE.md` §11, and are adjustable in the Decision Room rather than buried in the code.

## Code size

| File | Lines |
|---|---|
| `src/engine.js` | 1,078 |
| `src/ui.js` | 864 |
| `src/data.js` | 465 |
| `src/styles.css` | 195 |
| `src/shell.html` | 92 |
| `src/demo_shell.html` | 44 |
| `src/demo.js` | 194 |
| `tools/dump_numbers.js` | 244 |
| `tools/make_docx.py` | 190 |
| `tools/build.py` | 57 |
| `tests/check_docs.js` | 142 |
| `tests/smoke_ui.js` | 194 |
| `tests/smoke_demo.js` | 69 |
| `tests/demo_path.js` | 124 |
| `tests/run_engine.js` | 161 |
| **Total source** | **≈3,900** |
| Built artefacts | `index.html` 2,705 lines · 185 KB — `demo.html` 2,852 lines · 194 KB |
