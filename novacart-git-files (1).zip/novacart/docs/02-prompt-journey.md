# 2 · Prompt Journey

**What qualified as a key prompt:** one that changed a decision, killed an idea, or produced an artefact that is in the submission today. This is not a transcript of every conversation — it is the seventeen prompts that moved the work, in the order they moved it. Each entry records what we asked, why we asked it, what came back, and what we did with it.

The working method throughout: **the AI was never asked to have an opinion the case data could not support.** It was asked to build chains, cost counterfactuals, attack our own conclusions, and turn reasoning into arithmetic that an operator can argue with.

---

### P1 — Reconstruct the case as one causal chain, cited
> *"Here is the case pack. Do not propose anything yet. Reconstruct these six months as a single causal chain. Every arrow must cite a specific disclosed number. If an arrow has no number under it, mark it as an assumption and say so."*

**Why:** the brief's failure mode is a beautiful solution to the wrong problem, and the fastest way into it is to jump to features from the symptom list.

**What it produced:** growth → discount acquisition → unverified promise → failure → 9.2-hour recovery → churn among 4★ customers → more discount acquisition. It also marked one arrow as unsupported: nothing in the case pack says customers leave *because* of price.

**What it changed:** this became §3 of the diagnosis and the spine of the whole submission. The first candidate idea (a loyalty/rewards programme) died here — you cannot reward customers into staying when 11% of their orders fail.

### P2 — Steelman the opposite
> *"Now argue the opposite case, as strongly as the data allows: that this is a demand and pricing problem, not an operations problem, and that the repeat-rate fall is just a mix effect from discount-acquired cohorts."*

**Why:** to avoid building a fulfilment product for a demand problem — the more expensive mistake of the two.

**What it produced:** the mix effect is real and material (discount cohorts retain worse; 44% of coupons are never redeemed) — but the argument collapsed on three facts: cancellations doubled to 11%, the *absolute* number of repeat buyers fell by 1,220, and 61% of churned customers had rated NOVA CART 4★ or better. Mix changes who arrives; it does not explain 4,235 cancelled orders a month.

**What it changed:** we stopped treating "reliability vs mix" as a settled question and made it an explicit parameter (`reliabilityShare`, default 60%) that a reviewer can move inside the Decision Room. Honest disagreement became a slider instead of a buried assumption.

### P3 — Cost the counterfactual the business is already running
> *"Marketing wants to raise spend another 30%. Model that exactly as the last six months actually behaved — using the case pack's own incremental ROAS — over twelve months. Show me the cumulative number and what happens to repeat rate."*

**Why:** the strongest argument in the submission is the case pack's own arithmetic, not our model's.

**What it produced:** incremental ROAS 0.57× — ₹103 of promotions per incremental order returning **₹59** of *marginal* platform revenue (₹4.30L ÷ ₹7.50L). Today's average revenue per order is ₹68; that number belongs to a different question, and the two must not be divided by each other. Twelve months of +30% marketing: orders 40,731, revenue ₹26.53L in month 12, repeat rate unchanged at **27.0%**, cumulative Δ contribution **−₹67.74L**, no payback.

**What it changed:** Plan A exists as the honest benchmark, and it is the case pack's own behaviour extrapolated. Every credibility claim we make is now measured against it. It also produced the sentence the CEO can use: *"more marketing does not raise repeat rate by one point."*

### P4 — Find the failure mode that is upstream of the others
> *"Across cancellations, lateness, substitutions, tickets and refunds: which single failure mode sits upstream of the most of the others? Show which case-pack figures place it there, and which do not."*

**Why:** six symptoms, ₹25L, six months — we can only address one mechanism properly.

**What it produced:** product unavailability. It is 35% of cancellations directly, it is upstream of delay (a store hunting for a missing item is the delay), upstream of substitution (8% of orders), upstream of the largest ticket category (29% refund status), and upstream of partner friction (39% say catalogue upkeep costs too much).

**What it changed:** the product's centre of gravity moved from delivery speed to **availability verification**. Speed became an output of being able to promise honestly, not a target in itself.

### P5 — Try to falsify our own conclusion
> *"Design the cheapest test that would prove the inventory-accuracy diagnosis wrong. What would you measure in week one, and what result would make you abandon the idea?"*

**Why:** we had a favourite hypothesis within an hour of reading the brief. That is exactly when it needs attacking.

**What it produced:** four falsification tests — concentration of "product unavailable" cancellations, whether verified stores actually improve, whether lateness is information or capacity, and whether fast recovery neutralises churn.

**What it changed:** these became §7 of the diagnosis and, more importantly, the instrumentation plan: link `order_id` → store `last_verified_at` → coded cancellation reason → first-resolution time → next order date. We are declaring in advance what would prove us wrong.

### P6 — Get external evidence on how wrong inventory records really are
> *"Find published evidence on retail inventory record accuracy: how inaccurate records actually are, what causes it, what it costs, and what has been shown to fix it. Give me figures with sources, and tell me where the evidence is weak."*

**Why:** if NOVA CART's 35%-unavailable cancellation mix were unusual, it would suggest something specific is broken. If it is the industry default, it is a structural problem with a known shape.

**What it produced:** DeHoratius & Raman's audit — **65% of inventory records inaccurate** across ~370,000 SKUs, ~35% average deviation, ~4% of sales lost, phantom-stock replenishment failures, and RFID correction cutting stockouts 21–36%. Also the weakness: much of this literature predates quick commerce, so magnitudes transfer cautiously.

**What it changed:** the diagnosis stopped being "NOVA CART has a data problem" and became "NOVA CART is carrying the retail industry's default data problem, and it is the specific thing its business model cannot survive." It also justified the design constraint: verification is cheaper than prediction.

### P7 — What does the evidence say a late delivery actually costs?
> *"What is the measured relationship between a late delivery and customer retention? Separate promises kept from raw speed. Include how customers respond to being told early about a delay."*

**Why:** to decide whether to sell faster deliveries or honest ones.

**What it produced:** 69% less likely to shop again after a late delivery (Voxware); 32% stop after one bad experience (PwC); 55% switch for reliability (Capgemini); late deliveries lengthen the next interpurchase interval 40–60% (Harter, Stich & Spann 2024); and 71% forgive a delay if told why, with a new ETA.

**What it changed:** the entire promise design. NOVA SURE does not promise faster — on the Sri Balaji basket it promises **longer** (32 min instead of 28) and cuts the >15-minute-late probability from **13.7% to 1.3%**. Without this evidence that would have looked absurd. With it, it is the pitch.

### P8 — Benchmark our "bad" number
> *"Is a 27% repeat purchase rate actually bad for Indian quick commerce, or is it normal? Give me benchmark ranges with sources and tell me what the specific alarm thresholds are."*

**Why:** "27% is bad" is an assertion; we wanted it to be a finding.

**What it produced:** average repeat purchase rates 25–30% (consumables 25–40%, top D2C 45%+); 77% of repeat purchases happen within 30 days; a second-order rate under 15% is an alarm; discount-acquired cohorts repeat at under half the full-price rate. So NOVA CART is *inside* the broad range and *outside* its own history — and the composition is the problem: a falling repeat rate with rising volumes and rising discounts is the signature of expiring acquisition, not a healthy funnel.

**What it changed:** we stopped quoting the repeat rate alone and started quoting the **absolute count** of repeat buyers: 33,620 → 32,400 on the conservative base (registered users × repeat rate). That single number (1,220 fewer) is harder to argue with than any percentage, and it appears in the copilot's first answer — which now also prints the definition and the two alternative bases, so a reviewer can check it.

### P9 — Generate interventions, then kill most of them
> *"Generate eight distinct interventions for this diagnosis: from discounts to dark stores to loyalty to hiring to ML forecasting. Score each on expected monthly value, cost inside ₹25L, time to first evidence, whether it needs new infrastructure, and whether it depends on data NOVA CART does not have. Kill the ones that fail the brief's constraints, and be blunt about why."*

**Why:** to make the scope decision explicit and auditable rather than tasteful.

**What it produced:** a kill list. Dark stores and speed-matching died on capex and the brief's infrastructure constraint. Discounts died on 0.57× incremental ROAS. A loyalty programme died because it rewards people who are already being failed. Custom ML forecasting died because the data is the problem, not the algorithm — and without paid APIs or training data it could not be honest anyway. Rider hiring was real but outside the brief's constraint of no hundreds of new employees and did not address the root cause.

**What it changed:** three survivors, one product: verification (store sync), honesty (promise engine), and operations (the console + copilot). The kill list is why the build is small.

### P10 — What is the smallest thing a store will actually do twice a day?
> *"39% of partners say inventory upkeep costs too much effort and 18% are considering leaving. Design the lightest possible verification behaviour — measured in seconds — that a shopkeeper with a customer at the counter will do reliably, twice a day, without training."*

**Why:** the elegant version of this product is a full inventory-management integration. That version fails on partner effort, which the case pack already tells us.

**What it produced:** three buttons per SKU — ✔ plenty / ⚠ only a few / ✖ out — sorted so the phone shows the handful of items that matter most to online orders, with one thumb, and no typing, no scanning, no counts. Fifteen seconds. The AI's framing that survived: *"never ask a shopkeeper for an inventory number; ask for a state."*

**What it changed:** `NC.storeSync()` in the product does precisely this, and the world model responds to it — a single verified SKU lifts that SKU's availability score, cuts the store's cancellation and substitution rates, drops catalogue age to 30 minutes, and raises reliability. Effort was treated as a first-class constraint, not an implementation detail.

### P11 — Write the availability rule as a decision rule, not a vibe
> *"Turn 'don't promise what you can't deliver' into a precise rule: when do we show a product as available, when do we show it as uncertain, and when do we hide it? Give thresholds, and state what each threshold is trading off."*

**Why:** "smart availability" is the sort of phrase that means nothing and ships as nothing.

**What it produced:** a scored availability function over catalogue age, verification state, store reliability, SKU velocity and stockout history, with the verification event overriding everything else (+6 score, freshness "verified now", driver "Verified by the store just now"). The trade-off is stated in the product itself: hiding an item costs a sale now; showing it and failing costs the customer.

**What it changed:** the availability gate is real code in `NC.availability()`, visible per SKU in the customer app and re-scored the instant a store verifies. It is also what makes the promise engine's inputs truthful.

### P12 — Design a promise that cannot be more confident than its data
> *"Design the delivery promise so it is structurally incapable of promising more than the data supports. The store's own preparation time, dispatch record and reliability must all bind it. Show me a flat promise versus this one on a real basket."*

**Why:** the case pack has 13% of orders more than 15 minutes late, which means the current promise is not a forecast — it is a marketing number.

**What it produced:** a per-store distribution over prep → dispatch → travel, with the promise set at the central estimate plus a buffer scaled by that store's variance, and a customer-facing honesty window. On the Sri Balaji basket (central 34 min, σ 8): flat promise 28 min with a **13.7%** chance of being >15 minutes late; NOVA SURE 32 min with **1.3%**, and ±5-minute accuracy 44% → 68%.

**What it changed:** the promise engine is a first-class part of the customer app, with the before/after comparison on the same basket. It is also the clearest single demonstration in the demo script, because it shows the product deliberately *promising worse* and being right.

### P13 — Make the leak map something an operator can argue with
> *"Express the cost of unreliability as five lines of arithmetic. Every line must be traceable to a disclosed case figure plus at most one stated assumption, and the operator must be able to change any assumption and see the total move."*

**Why:** "₹10L" on a slide ends the conversation; five lines the ops head can dispute start one.

**What it produced:** cancellations ₹2.87L / support ₹3.19L / refunds & compensation ₹0.97L / rider minutes ₹1.70L / substitution friction ₹1.29L = **₹10.03L/month**, plus ₹1.09L/month of cohort lifetime revenue. Every line is labelled with its owner — inventory accuracy, support, refunds, delivery, store ops — so the leak lands on a desk, not in a deck.

**What it changed:** this is the leak bar in the Ops Trust Console, live and moving as interventions are applied. It is also the reason a ₹25L programme is an easy decision: it is recovered by about two and a half months of the leak.

### P14 — Turn this into one-tap action, not a dashboard
> *"The output of all this analysis must be something a category manager can act on during a shift. No charts to interpret. Rank interventions by value, tell them the effort, and let them apply it with one tap — then show the leak move."*

**Why:** this is the difference between an analytics exercise and an operating system. The case pack's complaint about siloed systems is a complaint about exactly this gap.

**What it produced:** an intervention queue over 32 concrete actions across 6 types (enable sync, gate risky SKUs, pre-peak stock nudge, demand forecast + capacity cap, substitution SOP, churn-risk partner call), each with a ₹/month value, an effort score, and one-tap apply. The store league table sorts worst-reliability-first with an "Open" button straight into that store's app. Auto-heal runs the top 6 or top 20.

**What it changed:** the console is the part of the prototype we would deploy first, because it needs no customer behaviour change to start paying: applying the top 20 actions moves the direct leak **₹10.03L → ₹8.74L** with a top-20 gain of ₹1.69L/month.

### P15 — A copilot that is not allowed to invent anything
> *"Design the Decision Copilot to be deterministic and auditable: it must answer only from the case pack, the leak map and the model; it must print the method and a confidence label with every answer; and when nothing matches the question it must say so rather than improvise."*

**Why:** management's disagreement in the case pack is not a data problem, it is a shared-language problem. And a generative copilot that invents a figure would destroy the credibility of the whole submission.

**What it produced:** keyword-scored retrieval over a corpus built from the same numbers the console uses, with eight preset questions covering the exact dispute (better or just bigger; what reliability costs; should we raise spend; inventory or delivery; what to build; why 4★ customers leave; why tickets outgrew orders; what can't be copied). Every answer carries evidence lines, a method string and a confidence label; an unmatched query gets an honest "I don't have that" plus the nearest presets.

**What it changed:** the copilot is in the prototype, and its answers are what management reads first. On "Is NOVA CART getting better or just bigger?" it answers: *"Bigger, and worse on every quality axis that predicts repeat purchase"* — with the four numbers that prove it.

### P16 — What would make this fail in production?
> *"Assume we ship this. List everything that breaks it — partner adoption, verification decay, cherry-picking, stores gaming the sync, promise buffers quietly widened by ops, category differences — and tell me the smallest version that still proves the mechanism."*

**Why:** the brief rewards a working mechanism over an impressive build, and we would rather name our own failure modes than have them named for us.

**What it produced:** the adoption risk (a store that never verifies stays as it is — which is *why* the console ranks stores by exposure and auto-heal exists), verification decay (the freshness mechanic makes stale verification visibly degrade the promise instead of silently lying), and the governance risk that buffers get widened to hit a promise KPI (which is why the console tracks leak and repeat rate, not just on-time %).

**What it changed:** the pilot design — Phase 1 in the two cities with the worst store cohort, measure cancellations and repeat orders per store, and scale to 620 stores only on evidence.

### P17 — Write the weakest version of our own claims
> *"Now write the section of the submission that undermines our own numbers: which inputs are assumptions, which conclusions are calibration, which are externally validated, and what would have to be true for this to be wrong."*

**Why:** the case pack itself is full of confident figures that do not reconcile. A submission that papers over its assumptions would repeat the crime it is diagnosing.

**What it produced:** the disclosure sections — ₹42/₹34/₹75 soft costs, `reliabilityShare` at 60%, the calibration choice in reconciling the disclosed 72% next-month repeat rate with 38,500 monthly orders, and the fact that halving both soft cost lines still leaves ₹8.05L/month of leak.

**What it changed:** every claim in the submission is now labelled as disclosed, derived, calibrated or assumed — and the assumption list is published in `EVIDENCE.md` §11 and adjustable in the Decision Room.

---

## Prompts we deliberately stopped using

Recorded because restraint was part of the method:

- **"Give me ten AI ideas for quick commerce."** Produces category-shaped answers with no relationship to the case pack's numbers. It is the path to the brief's stated failure mode: a generic AI idea turned into a website. Killed within the first hour.
- **"What is the best model for demand forecasting?"** Unfundable within ₹25L, unnecessary before availability is verified, and it would have mis-set expectations. Replaced with P10's question about what a shopkeeper will actually do.
- **"Estimate the market size and TAM for this idea."** Produced a large, invented number that changes nothing about the decision. Deleted.
- **"Write the submission document."** Rejected as a single step. Each section was generated from a question that had to be answered first (P1, P9, P13, P17) precisely so that the writing could not run ahead of the reasoning.
