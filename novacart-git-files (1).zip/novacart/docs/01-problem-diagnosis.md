# 1 · Problem Diagnosis

> **NOVA CART's growth is converting into churn because it makes a promise of availability and speed that nobody in the chain has verified.**
> The order is priced, promised and paid for before the partner store's shelf is known. When the shelf disagrees, the customer does the work: they lose the order, wait again, chase a refund, and leave.

Every number below is from the case pack or from [`EVIDENCE.md`](../EVIDENCE.md), which is generated from the engine running the prototype.

---

## 2. What the case pack shows

| Metric | 6 months ago | Today | Change |
|---|---|---|---|
| Registered users | 82,000 | 1,20,000 | +46.3% |
| Monthly active users | 39,000 | 46,000 | +17.9% |
| Monthly orders | 31,200 | 38,500 | +23.4% |
| Average order value | ₹452 | ₹486 | +7.5% |
| **Repeat purchase rate** | **41%** | **27%** | **−34.1%** |
| **Repeat buyers (absolute)** | **33,620** | **32,400** | **−1,220** |
| Average delivery time | 29 min | 37 min | +27.6% |
| Cancellation rate | 6% | 11% | +5 pts |
| Support tickets / month | 3,100 | 5,900 | +90.3% |
| Promotional spend / month | ₹9.50L | ₹17.00L | +78.9% |
| Revenue / month | ₹21.80L | ₹26.10L | +19.7% |

Derived from those disclosed figures (not disclosed directly, but arithmetic):

| | 6 months ago | Today |
|---|---|---|
| GMV at the disclosed AOV | ₹141.02L | ₹187.11L |
| Implied platform take rate | 15.46% | 13.95% |
| Promotions as a share of platform revenue | 43.6% | 65.1% |

**"Repeat buyers" — defined, because the case pack does not define it.** The pack discloses registered users, MAU, orders and a repeat purchase rate, but not the base that rate is measured on. So the count is stated on all three plausible bases, and the headline uses the most conservative one:

| Basis | 6 months ago | Today | Change |
|---|---|---|---|
| **Registered users × repeat rate** (used in the headline) | 33,620 | 32,400 | **−1,220** |
| Monthly active users × repeat rate | 15,990 | 12,420 | −3,570 |
| Orders × repeat rate | 12,792 | 10,395 | −2,397 |

Every basis falls, so the direction of the finding does not depend on which denominator the case pack had in mind — 1,220 is simply the smallest fall, quoted as a floor.
| Platform revenue per order | ₹70 | ₹68 |
| Support cost as a share of platform revenue | 10.7% | 17.0% |
| Tickets per 100 orders | 9.9 | 15.3 |
| Orders per monthly active user | 0.800 | 0.837 |

**The one number that decides the diagnosis:** in six months NOVA CART bought 7,300 extra orders a month with ₹7.50L of extra promotional spend.

- Each of those incremental orders cost **₹103** of promotions (₹7.50L ÷ 7,300) and added **₹59** of platform revenue (₹4.30L ÷ 7,300). Marginal-to-marginal: **₹59 ÷ ₹103 = 0.573×**, identical to ₹4.30L ÷ ₹7.50L.
- **One definition, used everywhere in this submission:** extra revenue ÷ extra spend = **0.57×**.
- **The alternative, stated so it can be checked.** Divide today's *average* revenue per order (₹68) by the marginal promo cost of an extra order (₹103) and you get **0.66×**. Both are legitimate *labels* for two different questions, both are below 1, and both point the same way — but they must not be mixed inside one sentence, and the app reports 0.57× as the headline with 0.66× shown beside it as the most generous reading. Blended (total revenue ÷ total spend) is 1.54×.
- Meanwhile the count of customers who come back fell by **1,220 in absolute terms** (definition and all three possible bases immediately below).

The growth is being paid for twice: once at acquisition, and again when the customer leaves.

## 3. The chain

Each arrow is supported by a disclosed figure. None of the arrows is inferred from an AI hunch.

**1 · The promise is made before the shelf is checked.**
54% of first orders even complete. Of the orders that fail, **35% of cancellations are caused by product unavailability**, and 8% of delivered orders contain a substitution. 19% of customers repeatedly search for products that turn out to be unavailable. There is no step in the journey where a store confirms it can actually supply the basket.

**2 · Cancellation and substitution are the most visible failure.**
11% of orders — 4,235 orders a month — are cancelled, at an average order value of ₹486. The remaining failure modes land on the customer's doorstep: 13% of orders arrive more than 15 minutes late, and support handles 5,900 tickets a month against a resolution time of **9.2 hours** across siloed systems.

**3 · The recovery journey is worse than the failure.**
Tickets are +90.3% while orders grew 23.4%. **29% of all tickets are refund status** — the single largest ticket category. The customer who lost an order spends the next nine hours chasing it. That is not a support problem; it is a feeling, and it is the last thing the customer remembers about NOVA CART.

**4 · Failure becomes churn, and it does so precisely among good customers.**
Repeat 41% → 27% is the outcome of the failures above. **61% of churned customers had rated NOVA CART 4★ or better** — they liked the product, the prices and the app. They were lost on the experience of an order that did not arrive as promised. The behaviour data agrees: 31% place a second order within 30 days and only **72% of customers who reach three orders come back the next month**. The first three orders are the whole ballgame, and the first three orders are where the failures concentrate.

**5 · The partner side cannot fix it alone, and is starting to leave.**
39% of partner stores say inventory upkeep costs too much effort, 28% cannot predict online sales, 23% reject orders during busy periods, and **18% are considering leaving the platform**. Their incentives point away from accuracy: they earn on the orders they fulfil, not on the catalogue they maintain.

**The loop:** an unverified promise → failure → 9.2-hour recovery journey → churn among 4★ customers → acquire replacements with discounts → 44% of coupons never redeemed → and the promotional spend that should have funded reliability is 65.1% of platform revenue.

## 4. Why the management debate is one mechanism, not six problems

The case pack shows six different readings of the same six months. They are not six problems — they are one mechanism observed from six seats.

| Seat | Their reading | What the diagnosis says |
|---|---|---|
| CEO | Retention | Right outcome, and it is not fixable with a loyalty programme while 11% of orders fail |
| Marketing | More promotions are needed | Promotions bought volume at 0.57× incremental ROAS and worsened the cohort mix — 44% of coupons are never redeemed |
| Ops | Delivery reliability | Delivery is the symptom: 27% of cancellations are delay-driven, but availability is upstream of both delay and cancellation |
| Partner Manager | Inventory accuracy and store experience | This is the root, and 18% partner attrition is the deadline on fixing it |
| Product | Local-commerce differentiation | Real — but "local" is a liability until the local shelf is verified |
| Finance | Quality and cost of growth | Agreed, and quantified: ₹10.03L/month of direct leak, ₹1.20cr a year |

That is the reason for the design constraint we imposed on ourselves: **one spine, three surfaces, no new business model.**

## 5. External validation

The diagnosis rests on three claims that are testable outside NOVA CART. All three hold, and independently:

**Claim A — retail inventory records are systematically wrong, not occasionally wrong.**
DeHoratius & Raman's audit of ~370,000 SKUs across 37 stores found **65% of inventory records inaccurate**, average absolute deviation around 35% of physical inventory, with ~20% of records off by six or more units. Negative-on-hand records ("phantom stock") suppress replenishment and cause stockouts; inventory record inaccuracy is associated with roughly **4% of annual sales lost**. Manual counting error rates alone run 8–12%, and RFID-based correction has cut stockouts by **21–36%** in published trials. *(DeHoratius & Raman, 2008; Kang & Gershwin, MIT; RFID pilot literature.)* NOVA CART's 35%-unavailable cancellation mix is not an anomaly; it is the industry default.

**Claim B — a late delivery is remembered far longer than a fast one.**
69% of consumers say they are less likely to shop a retailer again after a late delivery (Voxware); 32% stop doing business after a single bad experience (PwC); 55% switch to a competitor for more reliable delivery (Capgemini). Harter, Stich & Spann (2024) find late deliveries lengthen the customer's next interpurchase interval by **40–60%**, while early deliveries shorten it. And 71% of customers forgive a delay if they are told why and given a new ETA. Speed is not what retains; *kept* is what retains.

**Claim C — hidden cost and slow delivery are the leading fixable causes of abandonment, and the cohort decay NOVA CART shows is structural.**
Baymard's aggregate of ~50 studies puts cart abandonment near **70%**, with unexpected extra costs (39–48%) and slow/unclear delivery (21–23%) among the top preventable drivers — exactly the two things an honest promise and verified availability address. Published retention benchmarks put average repeat purchase rates at 25–30%, with **77% of repeat purchases occurring within 30 days** and a second-order rate below 15% treated as an alarm signal. Discount-acquired cohorts (over 30% off) repeat at **less than half** the rate of full-price cohorts. NOVA CART's 31% 30-day second-order rate is not a marketing failure; it is what a discount-led acquisition engine produced.

**Market context that constrains the answer.** India's quick-commerce market is around ₹11,000 crore of GMV a month on ~7.8M orders a day, growing 40–45% a year, with the leader holding roughly 45–50% of it on 1,300–2,000+ dark stores and majors charging partners 15–28% commissions. NOVA CART cannot win a dark-store capex race on ₹25 lakh, and should not try. Meanwhile ONDC's DigiDukaan crossed 10,000+ onboarded kiranas and 7.64 lakh sellers at 5–10% commissions, and HUL's Shikhar programme has onboarded ~1.3M kiranas: lightweight store digitisation is a proven, cheap wedge. **NOVA CART's differentiation is 620 stores that are actually nearby — but only if their shelves are verified.**

Sources are listed at the end of this document.

## 6. What the diagnosis rules out

| Candidate | Verdict | Why |
|---|---|---|
| "Buy growth with more discounts" | **Rejected — arithmetically** | Incremental ROAS is 0.57×. Reproducing the last six months' own numbers as a forward plan (Plan A) costs ₹67.74L over twelve months and leaves repeat rate at 27.0%. |
| "Match dark-store speed" | **Rejected — out of scope and out of budget** | Leader-scale dark-store networks cost far more than the ₹25L ceiling, and infrastructure expansion is excluded by the brief. |
| "The app is cluttered" | **Rejected as a root cause** | 14% cite clutter — real, cheap to fix, and it does not produce a single cancellation. |
| "Complaints are price complaints" | **Not the binding constraint** | 38% say prices/fees are high, but 61% of the customers who left rated NOVA CART 4★ or better. Price-sensitive customers who liked the product do not churn unless an order fails. |
| "Tracking is wrong" | **Symptom** | 11% report inaccurate tracking. Tracking accuracy is an output of a promise the system cannot currently compute. |
| "Marketing targeting is bad" | **Rejected** | Cost per newly registered user is ₹20 and cost per first-order customer is ₹288; the acquisition engine works. The product of acquisition — a second order — is what fails. |

## 7. Falsifiability — how this diagnosis could be proven wrong

We would abandon or re-scope the diagnosis if, in the first four weeks of real data:

1. **Product unavailability is not concentrated.** If cancellations coded "product unavailable" are spread evenly across stores instead of concentrating in the low-reliability, stale-catalogue tail, inventory verification is not the lever — the store-level data in the case pack (see `EVIDENCE.md` §7) says it is concentrated.
2. **Verified stores don't move.** If stores that complete the 15-second sync show no reduction in cancellations and substitutions after four weeks, the mechanic fails and the budget should move to rider capacity.
3. **Lateness is capacity, not information.** If more than half of >15-minute-late orders occur in stores whose prep and dispatch times were normal and whose distance is short — i.e. the promise's inputs were fine and the network failed elsewhere — then the promise engine needs rider supply work, not better store data.
4. **Recovery, not failure, drives churn.** If churn rates among customers who experienced a failure but were resolved within one hour are statistically indistinguishable from those who waited nine hours, then the 9.2-hour resolution time is not a driver, and the investment should shift entirely to prevention.

Week-1 instrumentation to test all four: link `order_id` to store `last_verified_at`, to the coded cancellation reason, to first-ticket resolution time, and to the customer's next order date. Every one of these fields almost certainly already exists in NOVA CART's systems, siloed.

## 8. The size of the prize

| | ₹ / month | Annualised |
|---|---|---|
| Revenue lost on cancelled orders | ₹2.87L | |
| Support cost caused by fulfilment failures | ₹3.19L | |
| Refunds and goodwill compensation | ₹0.97L | |
| Rider minutes burnt on re-tries and waits | ₹1.70L | |
| Substitution friction | ₹1.29L | |
| **Direct reliability leak** | **₹10.03L** | **₹1.20cr** |
| Lifetime revenue lost from each month's new cohort | ₹1.09L | ₹13.1L |
| **Total monthly value at stake** | **₹11.12L** | **₹1.33cr** |

Cancelling one in eleven orders costs ₹2.87L a month before anyone has answered the phone. The direct leak alone is **38% of monthly revenue**. For scale: the entire ₹25L implementation budget is recovered by roughly two and a half months of the leak.

Separately, ₹7.48L/month of coupons are issued and never redeemed — a pool that can be redeployed rather than a saving to bank.

## 9. Honest limits of this diagnosis

- Three cost lines (₹42 per refund/substitution event, ₹34 per late order, ₹75 per ticket) are **our assumptions**, not disclosed figures. Halving both soft lines still leaves ₹8.05L/month.
- The case pack does not tell us how much of the repeat-rate decline is mix (discount cohorts) versus experience. We attribute **60%** to reliability and 40% to mix, expose that parameter in the Decision Room, and the plan remains positive across the range shown in the sensitivity grid.
- Nothing here requires new data NOVA CART does not already hold — which is the point. The problem is not measurement; it is that the measurement is siloed across four systems and never reaches the moment of promise.

## References

- DeHoratius, N. & Raman, A. (2008), *Inventory Record Inaccuracy: An Empirical Analysis* — ~65% of records inaccurate across ~370,000 SKUs.
- Kang, Y. & Gershwin, S. (MIT), *Information Inaccuracy in Inventory Systems*; RFID stockout-reduction trials (21–36%).
- Baymard Institute, *Cart abandonment rate statistics* — ~70% abandonment; unexpected costs 39–48%, slow/unclear delivery 21–23%.
- Voxware (delivery experience, 69% less likely to re-shop after a late delivery); PwC (32% stop after one bad experience); Capgemini (55% switch for reliability).
- Harter, Stich & Spann (2024) — late deliveries lengthen interpurchase intervals by 40–60%; 71% forgive a delay when told why.
- Retention benchmarks: average repeat purchase rate 25–30%; 77% of repeat purchases within 30 days; discount-acquired cohorts repeat at under half the rate.
- Redseer / market coverage of India quick commerce (≈₹11,000 cr monthly GMV, ~7.8M orders/day, 40–45% CAGR, leader share 45–50%, commissions 15–28%).
- ONDC DigiDukaan and HUL Shikhar — 10,000+ kiranas and ~1.3M kiranas onboarded respectively; ONDC commissions 5–10%.
