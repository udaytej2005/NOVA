# 4 · Demo Script

## The 3-minute core path (rehearse this one)

If you only have three minutes, run **Beat 3 → Beat 2 → Beat 5** and stop:

1. **Store app (45s)** — the shopkeeper fixes the catalogue in four taps.
2. **Customer app (60s)** — the same basket, before and after: from "all four lines cannot be promised at this store" and an 18% late risk to a keepable promise with a 1.1% late risk.
3. **Decision Room (60s)** — the gap between Plan A (−₹67.74L) and Plan B (+₹10.33L).

Beats 1, 4 and 6 are the backup screens: diagnosis, the ops console, the copilot. If a question comes from finance, the console (Beat 4) is the answer; if it comes from marketing, the copilot (Beat 6).

---


**Total time: 6–7 minutes.** One narrative: *the same basket, before and after somebody verifies the shelf.*

Setup: open `index.html` in a browser. Nothing to install, nothing to log into, no network calls. Everything below is clickable; every number quoted is computed live by the running engine and matches [`EVIDENCE.md`](../EVIDENCE.md).

The demo deliberately uses **Vidya Book Depot, Nizamabad** — the worst store in the pilot cohort (reliability 38, catalogue 48 hours old, 26.4% cancellation rate). Starting at the worst place makes the mechanism visible in one minute.

---

## Beat 1 — Diagnosis (60s) · *why we are here at all*

**Click:** tab **1 · Diagnosis**.

**On screen:** the trust strip along the top (cancellations 11.0% · late >15 min 13.0% · tickets ≈5.9k/mo · leak ₹10.03L/mo · fixed volume 0%), the six-month table, the causal chain, the leak lines with an owner against each.

**Say:** *"In six months NOVA CART bought 7,300 extra orders a month and lost 1,220 repeat customers. Every extra order cost ₹103 in promotions and brought back ₹59 — 0.57× on the marginal rupee. (₹68 is today's average revenue per order; comparing an average with a marginal cost is the mistake we're careful not to make.) Cancellations doubled to 11%, 13% of deliveries are more than 15 minutes late, and 61% of the customers who left had rated us four stars or better. They didn't leave because of price. They left because the order failed and then took nine hours to fix. That is ₹10.03 lakh a month — ₹1.2 crore a year — leaking out of a business doing ₹26.1 lakh a month in revenue."*

## Beat 2 — The customer's order, at a store nobody has verified (90s) · *the problem, felt*

**Click:** tab **2 · Customer app** → **Nizamabad** → the **Vidya Book Depot** card.

**On screen (step 2):** the shelf, where every stationery item is banded **Unverified** (28, 38) or **Not sellable** (10, 16), each with its evidence line: *"catalogue 48h old · store cancels 26.4%"*. The basket panel seeds a four-line suggested basket.

**Click:** **Review the promise →**.

**On screen (step 3), the numbers to read out loud:**

| What the screen shows | Value |
|---|---|
| Basket miss risk before re-planning | **100%** — not one line can be promised here |
| After re-planning | **13.1%** (3 re-routed to a nearby store, 1 substituted) |
| Lines fixed before the customer ever saw them | 4 of 4 — three **REROUTE** to a nearby store, one **SUBSTITUTE** |
| Availability score move | 23 → 86 average |
| Promised time | old engine **56 min**, NOVA SURE **60 min** |
| Chance of arriving >15 min late | old **18.0%** → NOVA SURE **3.1%** |
| Promise kept within ±5 min | old **44%** → NOVA SURE **65%** |

**Say:** *"This is the whole problem in one screen. At a store nobody has verified, the app cannot honestly promise three of these four items — so it either fails the customer later, or it re-plans now and loses the store the order. And look at the promise: we now say 60 minutes instead of 56. We are promising **worse** on purpose, and the chance of missing by a quarter of an hour falls from 18% to 3%. Customers don't churn on speed; they churn on broken promises."*

**Click:** **Send 1,000 of these orders →** (step 4).

**On screen:** the 1,000-customer Monte Carlo — cancellations, late arrivals, unapproved substitutions and refund/support cases per 1,000, then second-order-within-30-days and lifetime orders per customer, plus a "Now the store's side →" button. Read the four rows as the cost of not fixing this store, and note the footnote: the outcome multipliers are printed on screen and normalised so today's failure mix reproduces the disclosed 31% second-order rate exactly.

## Beat 3 — The store fixes it in fifteen seconds (60s) · *the core mechanic*

**Click:** **Now the store's side →** (or tab **3 · Store app**). The store switcher strip is sorted worst-reliability-first, so Vidya is already at hand.

**On screen:** four big buttons per SKU — **✔ Plenty in stock · ⚠ Only a few left · ✖ Out of stock** — plus the store's own tiles (exposure ₹/month, risk SKUs).

**Click:** **✔ Plenty in stock** on A4 Paper Ream, **✔** on Classmate Notebook, **✔** on Fevicol, **✔** on Apsara Pencil Pack. Four taps. No counts, no scanning, no integration.

**On screen, immediately:** catalogue age collapses to **live**, the store's reliability rises (38 → 86 on this store), its cancellation rate drops (26.4% → 17.3%), and every item flips to **Verified** or **Likely** with freshness **verified now** and the driver *"Verified by the store just now"*.

**Say:** *"Everything our model needs to change costs this shopkeeper four taps. We never ask for an inventory number — we ask for a state. That is the difference between a product partners adopt and one they quietly stop using, which is where 39% of them already are."*

**Click:** back to tab **2 · Customer app** → **Review the promise** again, same basket, same store.

| | Before the four taps | After |
|---|---|---|
| Lines that can be promised at this store | 0 of 4 (3 re-routed, 1 substituted) | **4 of 4** |
| Miss risk after re-planning | 13.1% | **13.3%, nothing left to fix** |
| Old-engine late risk | 18.0% | **12.5%** |
| NOVA SURE late risk | 3.1% | **1.1%** |
| Promised time | 60 min | **54 min** |

These are the numbers `node tests/demo_path.js` asserts on every run, so the script cannot drift from the app.

**Say:** *"Fifteen seconds of the shopkeeper's day changed the promise from 'we can't do this' to a 54-minute window we miss 1% of the time — and it took four minutes **off** the promise, not added. Verification is the compounding asset: it is what lets the network be fast honestly."*

## Beat 4 — The operator's console (75s) · *where the money is*

**Click:** tab **4 · Ops Trust Console**.

**On screen:** the leak bar with its five lines and owners, the store league table ranked worst-reliability-first with monthly exposure (Vidya Book Depot at **₹32,514/month**), and the intervention queue: 32 actions ranked by ₹/month with an effort score.

Note the starting value: Beat 3 already fixed one store, so the bar reads **₹9.89L** here, not the ₹10.03L baseline (which is what a fresh session shows).

**Say, before you touch anything:** *"This number is a modelled estimate, and the app says so: every line is a disclosed order rate times one stated unit cost. Halve the assumed costs and it is still ₹8.05 lakh a month — so the decision does not hinge on our assumptions."*

**Click:** **Apply** on the first queue row (Enable NOVA SURE Sync at Prime Stationery Hub, ~₹21,000/month). **Then** click **⚡ Auto-heal top 20 interventions**.

**On screen:** the leak bar falls from **₹9.89L to ₹8.76L/month** — a top-20 queue gain of **₹1.69L/month** — and the coverage counter rises to **69.7%** of order volume on the fixed stack.

**Say:** *"This is not a dashboard. Nothing here can be applied by an analyst in a report; every row is a phone call, a nudge or a switch that a category manager can action during a shift. The top twenty actions are worth ₹1.69 lakh a month, and each store's row tells you what that store's unreliability is costing — which is also the argument you take to the store."*

*(Optional, 15s: click **Open** on the worst store in the league table — it jumps straight into that store's app, so the queue and the fix are two clicks apart.)*

## Beat 5 — The decision room (60s) · *answering the board's actual question*

**Click:** tab **5 · Decision Room**.

**On screen:** Plan C (do nothing), Plan A (+30% marketing, i.e. the last six months continued) and Plan B (NOVA SURE), side by side, with sliders for rollout coverage and marketing spend.

**Say, reading the table:** *"Start with the gap, because the gap is what we are deciding. Doing nothing ends twelve months at 36,309 orders and ₹24.62L revenue, ₹10.10 lakh down. Buying growth the way we have been buying it gets orders to 40,731 and revenue to ₹26.53L — and leaves repeat rate at exactly 27.0%, at a cumulative cost of ₹67.74 lakh. NOVA SURE reaches 40,644 orders and ₹27.85L revenue, lifts month-12 repeat to 31.6%, and ends the year **₹10.33 lakh up**: that is a **₹78.07 lakh gap** between the plan we are running and the plan we could run, while spending ₹5.1 lakh a month **less** on promotions. Payback — month 10 at today's rollout, month 5 once operations use the console — is what makes it fundable."*

**Then drag the coverage slider** to full rollout: payback moves to **month 5**, cumulative Δ to **+₹49.21L**, month-12 repeat to **35.4%**.

**Which numbers will be on screen?** The written pack quotes the 55% default: Plan B ends **+₹10.33L** and the gap is **₹78.07L**. If you ran Beat 4's auto-heal first, coverage is already ~70% and the screen shows better figures — Plan B ending **+₹37.04L** and a gap of **₹104.77L**. Quote what is on the screen and say which coverage it reflects; both are the same model.

**Say:** *"And the sensitivity grid answers the obvious challenge — at every level of coverage, spending more on marketing lowers contribution; at every level of spend, coverage raises it."*

## Beat 6 — The copilot (45s) · *what management argues about*

**Click:** tab **6 · Copilot** → preset **"Is NOVA CART getting better or just bigger?"** (all eight presets are guaranteed to reach an answer — a test asserts it)

**On screen:** *"Bigger, and worse on every quality axis that predicts repeat purchase."* — with orders +23.4%, promo +78.9% (*"spend grew 4.0× faster than revenue"*), repeat 41% → 27%, and the method and confidence label underneath.

**Then click:** **"Should we increase marketing spend by another 30%?"** → *"No. Every incremental order bought in the last six months cost more than it earned."*
**Then click:** **"Is inventory accuracy really the bottleneck, or is it delivery?"** → *"Inventory accuracy — because it is upstream of the cancellations and of the delay."*
**Then click:** **"What can we build that Blinkit cannot copy?"** → the "verified nearby" positioning.

**Say:** *"Every answer is deterministic, cites the case-pack numbers it came from, and prints its method and confidence. Ask something it doesn't have data for and it says so instead of improvising. The point of the copilot is not novelty — it is that six people in the same room stop disagreeing about what the numbers are."*

---

## Closing line (15s)

*"For ₹25 lakh — two and a half months of the leak — NOVA CART can stop promising what it hasn't verified. The mechanism is one shopkeeper's four taps, one honest delivery window, and one ranked list of actions. That is the difference between buying growth and keeping it."*

## If something goes wrong on stage

- **Wrong store selected?** Every store card is clickable, and the Store app has a *Switch store* strip sorted worst-first. The Ops league table's **Open** button jumps directly into any store.
- **Numbers differ slightly from this script?** They can — the script's figures are measured on the seeded stationery basket at Vidya Book Depot and shift with basket, store and city. Read the screen; the direction is what the demo is proving.
- **Nothing loads?** `index.html` is self-contained; it needs no server. If a browser blocks the local file for any reason, `python3 -m http.server 8080` in the project folder and open `http://localhost:8080/index.html`.
- **Want to get back to the starting state?** **Reset ops state** in the Ops console restores the baseline world (leak ₹10.03L, no applied interventions) without reloading, and **Reset to case defaults** in the Decision Room restores the model parameters.
